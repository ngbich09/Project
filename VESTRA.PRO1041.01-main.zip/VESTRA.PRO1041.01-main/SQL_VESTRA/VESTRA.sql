﻿-- =========================================
-- ========== TẠO DATABASE =================
-- =========================================
CREATE DATABASE Vestra;
GO
USE Vestra;
GO
-- CÁCH CHẠY DATABASE
-- ID không cần thêm vì là tự sinh
-- Mã thì cần

-- =========================================
-- ========== BẢNG CHỨC VỤ =================
-- =========================================
CREATE TABLE Chuc_vu (
    ID_chuc_vu INT IDENTITY(1,1) PRIMARY KEY,
    ma_chuc_vu NVARCHAR(100),
    ten_chuc_vu NVARCHAR(100) NOT NULL,
    mo_ta NVARCHAR(255),
    Trang_thai BIT DEFAULT 1
);
GO

-- =========================================
-- ========== BẢNG NHÂN VIÊN ===============
-- =========================================
CREATE TABLE Nhan_vien (
    ID_nhan_vien INT IDENTITY(1,1) PRIMARY KEY,
    ID_chuc_vu INT NOT NULL,
    ma_nhan_vien NVARCHAR(20) UNIQUE NOT NULL, 
    ten_nhan_vien NVARCHAR(150) NOT NULL,
    ten_dang_nhap NVARCHAR(50), 
    mat_khau NVARCHAR(255),
    gioi_tinh NVARCHAR(10),
    CCCD NVARCHAR(12),
    ngay_sinh DATE,
    dia_chi NVARCHAR(255),
    SDT NVARCHAR(10),
    email NVARCHAR(100),
    Trang_thai BIT DEFAULT 1, --1 là hoạt động, 0 là nghỉ làm
    Ngay_tao DATETIME DEFAULT GETDATE(),-- Không cần thêm sẽ có hàm tự thêm
    Ma_nguoi_tao NVARCHAR(50), -- chỉ truyền khi insert
    Ngay_cap_nhat DATETIME NULL, -- Không cần thêm sẽ có hàm tự thêm 
    Ma_nguoi_cap_nhat NVARCHAR(50) NULL, -- chỉ truyền khi update
    FOREIGN KEY (ID_chuc_vu) REFERENCES Chuc_vu(ID_chuc_vu)
);
GO

-- =========================================
-- ========== BẢNG KHÁCH HÀNG ==============
-- =========================================
CREATE TABLE Khach_hang (
    ID_khach_hang INT IDENTITY(1,1) PRIMARY KEY,
    ma_khach_hang NVARCHAR(100) UNIQUE NOT NULL,
    ten_khach_hang NVARCHAR(255) NOT NULL,
    SDT NVARCHAR(10),
    email NVARCHAR(100)NULL,
    dia_chi NVARCHAR(255)NULL,
    ngay_sinh DATE NULL,
    gioi_tinh NVARCHAR(10),
    Trang_thai BIT DEFAULT 1, --1 là hoạt động, 0 là nghỉ làm
    Ngay_tao DATETIME DEFAULT GETDATE() NULL,-- Không cần thêm sẽ có hàm tự thêm
    Ma_nguoi_tao NVARCHAR(50),-- chỉ truyền khi insert
    Ngay_cap_nhat DATETIME NULL,-- Không cần thêm sẽ có hàm tự thêm
    Ma_nguoi_cap_nhat NVARCHAR(50) NULL -- chỉ truyền khi update
);
GO

-- =========================================
-- ========== BẢNG VOUCHER =================
-- =========================================
CREATE TABLE Voucher (
    ID_voucher INT IDENTITY(1,1) PRIMARY KEY,
    ma_code_voucher NVARCHAR(50) NOT NULL UNIQUE,
    loai_giam_gia NVARCHAR(10) NOT NULL CHECK (loai_giam_gia IN ('%', 'Tien')),
    gia_tri_giam DECIMAL(12,2) CHECK (gia_tri_giam >= 0),
    muc_giam_toi_da DECIMAL(12,2) NULL,
    dieu_kien DECIMAL(12,2),
    so_luong INT CHECK (so_luong >= 0),
	ten_chuong_trinh_giam_gia NVARCHAR(255)NOT NULL,
    ngay_bat_dau DATE NOT NULL,
    ngay_ket_thuc DATE NOT NULL,
    Trang_thai BIT NOT NULL DEFAULT 1 -- 1 hoạt động, 0 ngừng hoạt động
);
GO

-- =========================================
-- ========== BẢNG CỔ ÁO ===================
-- =========================================
CREATE TABLE Co_ao (
    ID_co_ao INT IDENTITY(1,1) PRIMARY KEY,
    ma_co_ao NVARCHAR(100) UNIQUE NOT NULL,
    ten_co_ao NVARCHAR(200)UNIQUE NOT NULL , -- không trùng tên
    Trang_thai BIT DEFAULT 1 -- 1 hoạt động, 0 ngừng hoạt động
);
GO

-- =========================================
-- ========== BẢNG THƯƠNG HIỆU =============
-- =========================================
CREATE TABLE Thuong_hieu (
    ID_thuong_hieu INT IDENTITY(1,1) PRIMARY KEY,
    ma_thuong_hieu NVARCHAR(100) UNIQUE NOT NULL,
    ten_thuong_hieu NVARCHAR(200)UNIQUE NOT NULL , -- không trùng tên
    Trang_thai BIT DEFAULT 1 -- 1 hoạt động, 0 ngừng hoạt động
);
GO

-- =========================================
-- ========== BẢNG CHẤT LIỆU ===============
-- =========================================
CREATE TABLE Chat_lieu (
    ID_chat_lieu INT IDENTITY(1,1) PRIMARY KEY,
    ma_chat_lieu NVARCHAR(100) UNIQUE NOT NULL,
    ten_chat_lieu NVARCHAR(200) UNIQUE NOT NULL , -- không trùng tên
    Trang_thai BIT DEFAULT 1 -- 1 hoạt động, 0 ngừng hoạt động
);
GO

-- =========================================
-- ========== BẢNG SIZE ====================
-- =========================================
CREATE TABLE Size (
    ID_size INT IDENTITY(1,1) PRIMARY KEY,
    ma_size NVARCHAR(100) UNIQUE NOT NULL,
    ten_size NVARCHAR(200) UNIQUE NOT NULL , -- không trùng tên
    Trang_thai BIT DEFAULT 1 -- 1 hoạt động, 0 ngừng hoạt động
);
GO

-- =========================================
-- ========== BẢNG MÀU SẮC =================
-- =========================================
CREATE TABLE Mau_sac (
    ID_mau_sac INT IDENTITY(1,1) PRIMARY KEY,
    ma_mau_sac NVARCHAR(20) UNIQUE NOT NULL,
    ten_mau NVARCHAR(50) UNIQUE NOT NULL , -- không trùng tên
    Trang_thai BIT DEFAULT 1 -- 1 hoạt động, 0 ngừng hoạt động
);
GO

-- =========================================
-- ========== BẢNG SẢN PHẨM ================
-- =========================================
CREATE TABLE San_pham (
    ID_san_pham INT IDENTITY(1,1) PRIMARY KEY,
    ma_san_pham NVARCHAR(20) UNIQUE NOT NULL,
    ten_san_pham NVARCHAR(255) NOT NULL,
    Mo_ta_san_pham NVARCHAR(1000),
    Trang_thai BIT DEFAULT 1, -- 1 hoạt động, 0 ngừng hoạt động
    ID_co_ao INT NOT NULL,
    ID_thuong_hieu INT NOT NULL,
    ID_chat_lieu INT NOT NULL,
    FOREIGN KEY (ID_co_ao) REFERENCES Co_ao(ID_co_ao),
    FOREIGN KEY (ID_thuong_hieu) REFERENCES Thuong_hieu(ID_thuong_hieu),
    FOREIGN KEY (ID_chat_lieu) REFERENCES Chat_lieu(ID_chat_lieu)
);
GO

-- =========================================
-- ========== BẢNG SẢN PHẨM CHI TIẾT =======
-- =========================================
CREATE TABLE San_pham_chi_tiet (
    ID_san_pham_chi_tiet INT IDENTITY(1,1) PRIMARY KEY,
    ID_san_pham INT NOT NULL,
    ma_san_pham_chi_tiet NVARCHAR(100) UNIQUE NOT NULL,
    ID_size INT NOT NULL,
    ID_mau_sac INT NOT NULL,
    so_luong_ton INT CHECK (so_luong_ton >= 0),
    don_gia DECIMAL(12,2) CHECK (don_gia >= 0),
    Trang_thai BIT DEFAULT 1,-- 1 hoạt động, 0 ngừng hoạt động
    Ngay_tao DATETIME DEFAULT GETDATE(), -- Không cần thêm sẽ có hàm tự thêm
    Ma_nguoi_tao NVARCHAR(50),-- chỉ truyền khi insert
    Ngay_cap_nhat DATETIME NULL,-- Không cần thêm sẽ có hàm tự thêm
    Ma_nguoi_cap_nhat NVARCHAR(50) NULL,-- chỉ truyền khi update
    FOREIGN KEY (ID_san_pham) REFERENCES San_pham(ID_san_pham),
    FOREIGN KEY (ID_size) REFERENCES Size(ID_size),
    FOREIGN KEY (ID_mau_sac) REFERENCES Mau_sac(ID_mau_sac)
);
GO

-- =========================================
-- ========== BẢNG HÓA ĐƠN =================
-- =========================================
CREATE TABLE Hoa_don (
    ID_hoa_don INT IDENTITY(1,1) PRIMARY KEY,
    ID_khach_hang INT NULL,
    ID_nhan_vien INT NOT NULL,
    ID_voucher INT NULL,
    ten_nguoi_nhan  NVARCHAR(255)NULL,
    SDT_nguoi_nhan  NVARCHAR(10)NULL,
    ghi_chu  NVARCHAR(1000)NULL,
    tong_tien_tam_tinh DECIMAL(12,2) DEFAULT 0,
    tien_giam_voucher DECIMAL(12,2) DEFAULT 0,
    tong_tien_thanh_toan DECIMAL(12,2) DEFAULT 0 CHECK (tong_tien_thanh_toan >= 0),
    phuong_thuc_thanh_toan BIT DEFAULT 1, -- 1 = tiền mặt, 0 = chuyển khoản
    ngay_lap_hoa_don DATETIME DEFAULT GETDATE(),
    trang_thai_thanh_toan BIT DEFAULT 0, -- 0 = chưa thanh toán, 1 = đã thanh toán
    FOREIGN KEY (ID_khach_hang) REFERENCES Khach_hang(ID_khach_hang),
    FOREIGN KEY (ID_nhan_vien) REFERENCES Nhan_vien(ID_nhan_vien),
    FOREIGN KEY (ID_voucher) REFERENCES Voucher(ID_voucher)
);
GO

-- =========================================
-- ========== BẢNG HÓA ĐƠN CHI TIẾT ========
-- =========================================
CREATE TABLE Hoa_don_chi_tiet (
    ID_hdct INT IDENTITY(1,1) PRIMARY KEY,
    ID_hoa_don INT NOT NULL,
    ID_san_pham_chi_tiet INT NOT NULL,
    so_luong INT NOT NULL CHECK (so_luong > 0),
    don_gia DECIMAL(12,2) NOT NULL CHECK (don_gia >= 0),
    thanh_tien AS (so_luong * don_gia) PERSISTED,
    Trang_thai BIT DEFAULT 0, --1  là đã thanh toán, 0 là chưa 
    FOREIGN KEY (ID_hoa_don) REFERENCES Hoa_don(ID_hoa_don),
    FOREIGN KEY (ID_san_pham_chi_tiet) REFERENCES San_pham_chi_tiet(ID_san_pham_chi_tiet)
);
GO

-- Bảng Chức vụ
INSERT INTO Chuc_vu (ma_chuc_vu, ten_chuc_vu, mo_ta)
VALUES
(N'ADMIN',N'Admin',N'Quản trị hệ thống'),
(N'EMP01',N'Nhân viên bán hàng',N'Nhân viên cửa hàng'),
(N'EMP02',N'Nhân viên kho',N'Nhân viên quản lý kho'),
(N'EMP03',N'Nhân viên giao nhận',N'Nhân viên giao hàng');

-- Bảng Nhân viên
INSERT INTO Nhan_vien (ID_chuc_vu, ma_nhan_vien, ten_nhan_vien, ten_dang_nhap, mat_khau, gioi_tinh, CCCD, ngay_sinh, dia_chi, SDT, email, Trang_thai, Ngay_tao, Ma_nguoi_tao, Ngay_cap_nhat, Ma_nguoi_cap_nhat)
VALUES
(1, N'NV001', N'Bùi Mạnh Hiếu', N'hieubm001', N'hieubm001123', N'Nam', N'012345678901', '2007-05-23', N'Hà Nội', N'0973138027', N'hieubm001@gmail.com', 1, '2024-03-10 10:12:00', N'system', '2024-06-01 09:20:00', N'system'),
(2, N'NV002', N'Trịnh Minh Hiếu', N'hihemt002', N'hihemt002123', N'Nam', N'123456789012', '2005-07-03', N'Hà Nội', N'0912345678', N'hihemt002@gmail.com', 1, '2024-04-12 08:30:00', N'system', '2024-08-15 14:45:00', N'system'),
(3, N'NV003', N'Cao Thị Minh Phương', N'phuongctm003', N'phuongctm003123', N'Nữ', N'234567890123', '2006-12-22', N'Hà Nội', N'0923456789', N'phuongctm003@gmail.com', 1, '2024-05-20 12:00:00', N'system', '2024-09-18 10:10:00', N'system'),
(2, N'NV004', N'Nguyễn Thị Ngọc Bích', N'bichntn004', N'bichntn004123', N'Nữ', N'345678901234', '2006-03-15', N'Hà Nội', N'0934567890', N'bichntn004@gmail.com', 1, '2024-06-05 11:11:00', N'system', '2024-10-01 15:30:00', N'system'),
(2, N'NV005', N'Lê Văn An', N'anlva005', N'anlva005456', N'Nam', N'456789012345', '1995-02-11', N'Hà Nội', N'0945678901', N'anlva005@gmail.com', 1, '2024-01-15 09:00:00', N'system', '2024-03-10 10:00:00', N'system'),
(2, N'NV006', N'Phạm Thị Hương', N'huongpth006', N'huongpth006789', N'Nữ', N'567890123456', '1992-05-25', N'Hà Nội', N'0956789012', N'huongpth006@gmail.com', 1, '2024-02-20 10:30:00', N'system', '2024-06-01 11:45:00', N'system'),
(2, N'NV007', N'Ngô Văn Bình', N'binhngv007', N'binhngv007234', N'Nam', N'678901234567', '1988-11-05', N'Hà Nội', N'0967890123', N'binhngv007@gmail.com', 1, '2024-03-10 14:00:00', N'system', '2024-07-12 16:20:00', N'system'),
(2, N'NV008', N'Trần Thị Lan', N'lantrt008', N'lantrt008567', N'Nữ', N'789012345678', '1990-08-12', N'Hà Nội', N'0978901234', N'lantrt008@gmail.com', 1, '2024-04-05 12:15:00', N'system', '2024-08-20 13:30:00', N'system'),
(2, N'NV009', N'Đặng Minh Tuấn', N'tuandmt009', N'tuandmt009890', N'Nam', N'890123456789', '1996-01-20', N'Hà Nội', N'0989012345', N'tuandmt009@gmail.com', 1, '2024-05-15 10:10:00', N'system', '2024-09-01 09:45:00', N'system'),
(2, N'NV010', N'Vũ Thị Mai', N'maivut010', N'maivut010123', N'Nữ', N'901234567890', '1985-12-17', N'Hà Nội', N'0910123456', N'maivut010@gmail.com', 1, '2024-06-22 11:50:00', N'system', '2024-10-10 14:30:00', N'system'),
(2, N'NV011', N'Lý Văn Hoàng', N'hoanglv011', N'hoanglv011456', N'Nam', N'012345678912', '1993-09-09', N'Hà Nội', N'0921234567', N'hoanglv011@gmail.com', 1, '2024-07-11 09:40:00', N'system', '2024-11-01 10:55:00', N'system'),
(2, N'NV012', N'Bùi Thị Hồng', N'hongbth012', N'hongbth012789', N'Nữ', N'123456789123', '1994-03-28', N'Hà Nội', N'0932345678', N'hongbth012@gmail.com', 1, '2024-08-02 08:30:00', N'system', '2024-12-05 12:20:00', N'system'),
(2, N'NV013', N'Nguyễn Văn Duy', N'duyngv013', N'duyngv013234', N'Nam', N'234567891234', '1990-07-16', N'Hà Nội', N'0943456789', N'duyngv013@gmail.com', 1, '2024-09-05 10:10:00', N'system', '2025-01-15 11:15:00', N'system'),
(2, N'NV014', N'Phạm Thị Thanh', N'thanhpth014', N'thanhpth014567', N'Nữ', N'345678912345', '1991-10-08', N'Hà Nội', N'0954567890', N'thanhpth014@gmail.com', 1, '2024-10-01 09:20:00', N'system', '2025-02-10 14:30:00', N'system'),
(2, N'NV015', N'Trương Văn Long', N'longtrv015', N'longtrv015890', N'Nam', N'456789123456', '1989-11-25', N'Hà Nội', N'0965678901', N'longtrv015@gmail.com', 1, '2024-11-10 12:15:00', N'system', '2025-03-05 16:40:00', N'system'),
(2, N'NV016', N'Lê Thị Phương', N'phuongltp016', N'phuongltp016123', N'Nữ', N'567891234567', '1992-06-03', N'Hà Nội', N'0976789012', N'phuongltp016@gmail.com', 1, '2024-12-05 14:30:00', N'system', '2025-04-20 10:10:00', N'system'),
(2, N'NV017', N'Ngô Thị Mai', N'maingt017', N'maingt017456', N'Nữ', N'678912345678', '1993-01-12', N'Hà Nội', N'0987890123', N'maingt017@gmail.com', 1, '2025-01-15 09:45:00', N'system', '2025-05-15 12:50:00', N'system'),
(2, N'NV018', N'Đỗ Văn Khải', N'khaidov018', N'khaidov018789', N'Nam', N'789123456789', '1988-04-20', N'Hà Nội', N'0918901234', N'khaidov018@gmail.com', 1, '2025-02-20 11:00:00', N'system', '2025-06-10 14:20:00', N'system'),
(2, N'NV019', N'Võ Thị Linh', N'linhvt019', N'linhvt019234', N'Nữ', N'890123456789', '1994-09-30', N'Hà Nội', N'0929012345', N'linhvt019@gmail.com', 1, '2025-03-10 10:15:00', N'system', '2025-07-05 15:30:00', N'system'),
(2, N'NV020', N'Phan Văn Hoàng', N'hoangphv020', N'hoangphv020567', N'Nam', N'901234567890', '1991-08-15', N'Hà Nội', N'0930123456', N'hoangphv020@gmail.com', 1, '2025-04-01 09:25:00', N'system', '2025-08-01 12:40:00', N'system'),
(2, N'NV021', N'Trần Thị Thu', N'thutrt021', N'thutrt021890', N'Nữ', N'012345678923', '1987-12-11', N'Hà Nội', N'0941234567', N'thutrt021@gmail.com', 1, '2025-05-12 11:35:00', N'system', '2025-09-01 14:50:00', N'system'),
(2, N'NV022', N'Nguyễn Văn Quang', N'quangngv022', N'quangngv022123', N'Nam', N'123456789234', '1989-05-05', N'Hà Nội', N'0952345678', N'quangngv022@gmail.com', 1, '2025-06-20 10:50:00', N'system', '2025-10-10 11:25:00', N'system'),
(2, N'NV023', N'Lê Thị Bích', N'bichlt023', N'bichlt023456', N'Nữ', N'234567892345', '1990-03-18', N'Hà Nội', N'0963456789', N'bichlt023@gmail.com', 1, '2025-07-05 14:20:00', N'system', '2025-11-05 15:30:00', N'system'),
(2, N'NV024', N'Phạm Văn Đức', N'ducphv024', N'ducphv024789', N'Nam', N'345678923456', '1992-06-27', N'Hà Nội', N'0974567890', N'ducphv024@gmail.com', 1, '2025-08-15 09:40:00', N'system', '2025-11-20 12:10:00', N'system'),
(2, N'NV025', N'Trương Thị Mai', N'maitrt025', N'maitrt025234', N'Nữ', N'456789234567', '1993-11-22', N'Hà Nội', N'0985678901', N'maitrt025@gmail.com', 1, '2025-09-12 10:15:00', N'system', '2025-11-22 11:50:00', N'system'),
(2, N'NV026', N'Võ Văn Nam', N'namvv026', N'namvv026567', N'Nam', N'567892345678', '1988-08-08', N'Hà Nội', N'0916789012', N'namvv026@gmail.com', 1, '2025-10-01 08:30:00', N'system', '2025-11-24 09:40:00', N'system'),
(2, N'NV027', N'Ngô Thị Hạnh', N'hanhngt027', N'hanhngt027890', N'Nữ', N'678923456789', '1991-02-14', N'Hà Nội', N'0927890123', N'hanhngt027@gmail.com', 1, '2025-10-15 12:45:00', N'system', '2025-11-23 13:50:00', N'system'),
(2, N'NV028', N'Đặng Văn Tùng', N'tungdvt028', N'tungdvt028123', N'Nam', N'789234567890', '1985-07-30', N'Hà Nội', N'0938901234', N'tungdvt028@gmail.com', 1, '2025-11-01 09:00:00', N'system', '2025-11-25 10:10:00', N'system'),
(2, N'NV029', N'Phan Thị Ngọc', N'ngocpnt029', N'ngocpnt029456', N'Nữ', N'890234567891', '1990-05-05', N'Hà Nội', N'0949012345', N'ngocpnt029@gmail.com', 1, '2025-11-10 11:20:00', N'system', '2025-11-25 12:30:00', N'system'),
(2, N'NV030', N'Lý Thị Thanh', N'thanhlvt030', N'thanhlvt030789', N'Nữ', N'901345678912', '1989-09-09', N'Hà Nội', N'0950123456', N'thanhlvt030@gmail.com', 1, '2025-11-15 10:10:00', N'system', '2025-11-25 11:20:00', N'system');


-- Khách hàng
INSERT INTO Khach_hang
(ma_khach_hang, ten_khach_hang, SDT, email, dia_chi, ngay_sinh, gioi_tinh, Trang_thai, Ngay_tao, Ma_nguoi_tao, Ngay_cap_nhat, Ma_nguoi_cap_nhat)
VALUES
(N'KH001',N'Nguyễn Phương Linh',N'0989251723',N'nguyenphuonglinh001@gmail.com',N'Hà Nội','2007-08-22',N'Nữ',1,'2024-01-10 09:00:00',N'hieubm123','2024-05-12 10:20:00',N'trinhmh123'),
(N'KH002',N'Trần Duy Tuấn',N'0923456781',N'tranduytuan002@gmail.com',N'Hồ Chí Minh','1990-07-22',N'Nam',1,'2024-02-15 11:30:00',N'hieubm123','2024-06-20 12:40:00',N'caotmp123'),
(N'KH003',N'Lê Minh Phương',N'0934567892',N'leminhphuong003@gmail.com',N'Đà Nẵng','1992-01-18',N'Nữ',1,'2024-03-10 10:15:00',N'hieubm123','2024-07-25 14:10:00',N'nguyentnb123'),
(N'KH004',N'Phạm Ngọc Bích',N'0945678903',N'phamngocbich004@gmail.com',N'Hải Phòng','1985-09-30',N'Nữ',1,'2024-04-20 09:50:00',N'trinhmh123',NULL,NULL),
(N'KH005',N'Ngô Văn Duy',N'0956789014',N'ngovanduy005@gmail.com',N'Hà Nội','1988-12-05',N'Nam',1,'2024-05-05 08:30:00',N'caotmp123','2024-09-10 11:20:00',N'bichntn123'),
(N'KH006',N'Đỗ Thị Hạnh',N'0967890125',N'dothihanh006@gmail.com',N'Hà Nội','1994-11-12',N'Nữ',1,'2024-06-12 13:00:00',N'hieubm123','2024-10-20 15:30:00',N'trinhmh123'),
(N'KH007',N'Bùi Minh Quân',N'0978901236',N'buiminhquan007@gmail.com',N'Hà Nội','1991-06-25',N'Nam',1,'2024-07-18 09:45:00',N'hieubm123','2024-11-01 10:50:00',N'caotmp123'),
(N'KH008',N'Nguyễn Thị Lan',N'0989012347',N'nguyenthilan008@gmail.com',N'Hà Nội','1993-04-02',N'Nữ',1,'2024-08-05 08:15:00',N'hieubm123','2024-12-10 11:20:00',N'nguyentnb123'),
(N'KH009',N'Phan Văn Hoàng',N'0911122334',N'phanvanhoang009@gmail.com',N'Hà Nội','1990-02-20',N'Nam',1,'2024-09-12 14:10:00',N'trinhmh123',NULL,NULL),
(N'KH010',N'Trương Thị Mai',N'0922233445',N'truongthimai010@gmail.com',N'Hà Nội','1992-07-07',N'Nữ',1,'2024-10-20 09:30:00',N'caotmp123','2025-01-15 10:20:00',N'bichntn123'),
(N'KH011',N'Vũ Đức Tùng',N'0933344556',N'vuductung011@gmail.com',N'Hà Nội','1989-03-10',N'Nam',1,'2024-11-05 11:50:00',N'hieubm123','2025-02-12 12:40:00',N'trinhmh123'),
(N'KH012',N'Ngô Thị Hồng',N'0944455667',N'ngothihong012@gmail.com',N'Hà Nội','1993-12-25',N'Nữ',1,'2024-12-10 13:20:00',N'hieubm123','2025-03-20 14:30:00',N'caotmp123'),
(N'KH013',N'Lý Minh Anh',N'0955566778',N'lyminhanh013@gmail.com',N'Hà Nội','1991-05-14',N'Nam',1,'2025-01-05 09:40:00',N'hieubm123','2025-04-10 10:50:00',N'nguyentnb123'),
(N'KH014',N'Đặng Thị Thảo',N'0966677889',N'dangthithao014@gmail.com',N'Hà Nội','1992-09-18',N'Nữ',1,'2025-02-12 08:30:00',N'trinhmh123','2025-05-12 09:50:00',N'bichntn123'),
(N'KH015',N'Phạm Minh Đức',N'0977788990',N'phamminhduc015@gmail.com',N'Hà Nội','1988-11-30',N'Nam',1,'2025-03-01 10:20:00',N'hieubm123','2025-06-15 11:30:00',N'caotmp123'),
(N'KH016',N'Trần Thị Vy',N'0988899001',N'tranthivy016@gmail.com',N'Hà Nội','1994-08-22',N'Nữ',1,'2025-04-18 09:10:00',N'hieubm123','2025-07-20 10:30:00',N'trinhmh123'),
(N'KH017',N'Nguyễn Văn Khang',N'0919900112',N'nguyenvankhang017@gmail.com',N'Hà Nội','1990-06-03',N'Nam',1,'2025-05-05 08:45:00',N'caotmp123','2025-08-12 09:50:00',N'nguyentnb123'),
(N'KH018',N'Lê Thị Ngọc',N'0921011223',N'lethingoc018@gmail.com',N'Hà Nội','1992-10-15',N'Nữ',1,'2025-06-10 14:20:00',N'hieubm123','2025-09-18 15:30:00',N'bichntn123'),
(N'KH019',N'Phạm Văn Sơn',N'0932122334',N'phamvanson019@gmail.com',N'Hà Nội','1989-07-21',N'Nam',1,'2025-07-12 13:00:00',N'hieubm123','2025-10-10 14:10:00',N'trinhmh123'),
(N'KH020',N'Trịnh Thị Hương',N'0943233445',N'trinhtihuong020@gmail.com',N'Hà Nội','1991-03-28',N'Nữ',1,'2025-08-05 09:20:00',N'hieubm123','2025-11-05 10:30:00',N'caotmp123'),
(N'KH021',N'Nguyễn Văn Phúc',N'0954344556',N'nguyenvanphuc021@gmail.com',N'Hà Nội','1990-09-09',N'Nam',1,'2025-09-10 11:15:00',N'hieubm123','2025-11-12 12:20:00',N'nguyentnb123'),
(N'KH022',N'Lê Thị Thanh',N'0965455667',N'lethithanh022@gmail.com',N'Hà Nội','1993-01-05',N'Nữ',1,'2025-10-01 08:50:00',N'trinhmh123',NULL,NULL),
(N'KH023',N'Phan Minh Tuấn',N'0976566778',N'phanminhtuan023@gmail.com',N'Hà Nội','1989-05-14',N'Nam',1,'2025-11-02 09:40:00',N'caotmp123',NULL,NULL),
(N'KH024',N'Vũ Thị Lan',N'0987677889',N'vuthilan024@gmail.com',N'Hà Nội','1992-06-21',N'Nữ',1,'2025-11-05 10:30:00',N'hieubm123',NULL,NULL),
(N'KH025',N'Đỗ Văn Huy',N'0918788990',N'dovanhuy025@gmail.com',N'Hà Nội','1990-12-11',N'Nam',1,'2025-11-10 11:20:00',N'trinhmh123',NULL,NULL),
(N'KH026',N'Trần Thị Mai Anh',N'0929899001',N'tranthimaianh026@gmail.com',N'Hà Nội','1994-04-19',N'Nữ',1,'2025-11-15 08:40:00',N'caotmp123',NULL,NULL),
(N'KH027',N'Nguyễn Minh Tuấn',N'0930900112',N'nguyenminhtuan027@gmail.com',N'Hà Nội','1991-07-02',N'Nam',1,'2025-11-18 09:30:00',N'hieubm123',NULL,NULL),
(N'KH028',N'Lê Thị Bích Ngọc',N'0941011223',N'lethibichngoc028@gmail.com',N'Hà Nội','1993-02-23',N'Nữ',1,'2025-11-20 10:10:00',N'trinhmh123',NULL,NULL),
(N'KH029',N'Phạm Văn Duy',N'0952122334',N'phamvandu029@gmail.com',N'Hà Nội','1990-08-05',N'Nam',1,'2025-11-22 11:05:00',N'caotmp123',NULL,NULL),
(N'KH030',N'Đặng Thị Hồng Nhung',N'0963233445',N'dangthihongnhung030@gmail.com',N'Hà Nội','1992-11-17',N'Nữ',1,'2025-11-24 12:00:00',N'hieubm123',NULL,NULL);

-- Khách hàng
INSERT INTO Khach_hang
(ma_khach_hang, ten_khach_hang, SDT, email, dia_chi, Ma_nguoi_tao)
VALUES
(N'KH000',N'khách vãng lai',N' ',N'',N'',N'hieubm123');

-- Bảng Thương hiệu
INSERT INTO Thuong_hieu (ma_thuong_hieu, ten_thuong_hieu, Trang_thai)
VALUES
(N'TH001', N'Nike', 1),
(N'TH002', N'Adidas', 1),
(N'TH003', N'Puma', 1),
(N'TH004', N'Under Armour', 1),
(N'TH005', N'Reebok', 1),
(N'TH006', N'New Balance', 1),
(N'TH007', N'Converse', 1),
(N'TH008', N'Vans', 1),
(N'TH009', N'Fila', 1),
(N'TH010', N'Levi''s', 1),
(N'TH011', N'H&M', 1),
(N'TH012', N'Zara', 1),
(N'TH013', N'Uniqlo', 1),
(N'TH014', N'Gap', 1),
(N'TH015', N'Tommy Hilfiger', 1),
(N'TH016', N'Ralph Lauren', 1),
(N'TH017', N'Champion', 1),
(N'TH018', N'Columbia', 1),
(N'TH019', N'The North Face', 1),
(N'TH020', N'Patagonia', 1),
(N'TH021', N'Balenciaga', 1),
(N'TH022', N'Gucci', 1),
(N'TH023', N'Prada', 1),
(N'TH024', N'Louis Vuitton', 1),
(N'TH025', N'Versace', 1),
(N'TH026', N'Armani', 1),
(N'TH027', N'Burberry', 1),
(N'TH028', N'Givenchy', 1),
(N'TH029', N'Off-White', 1),
(N'TH030', N'Supreme', 1);

-- Bảng Cổ áo
INSERT INTO Co_ao (ma_co_ao, ten_co_ao, Trang_thai)
VALUES
(N'CA001', N'Cổ tròn cơ bản', 1),
(N'CA002', N'Cổ tròn rộng', 1),
(N'CA003', N'Cổ chữ V cơ bản', 1),
(N'CA004', N'Cổ chữ V sâu', 1),
(N'CA005', N'Cổ polo', 1),
(N'CA006', N'Cổ tim', 1),
(N'CA007', N'Cổ tàu', 1),
(N'CA008', N'Cổ thuyền', 1),
(N'CA009', N'Cổ áo tròn viền', 1),
(N'CA010', N'Cổ áo chữ V viền', 1),
(N'CA011', N'Cổ tròn dài tay', 1),
(N'CA012', N'Cổ chữ V dài tay', 1),
(N'CA013', N'Cổ polo viền', 1),
(N'CA014', N'Cổ tròn bo gấu', 1),
(N'CA015', N'Cổ chữ V bo gấu', 1),
(N'CA016', N'Cổ tròn rộng vai', 1),
(N'CA017', N'Cổ áo basic', 1),
(N'CA018', N'Cổ chữ U', 1),
(N'CA019', N'Cổ xẻ hai bên', 1),
(N'CA020', N'Cổ tròn cổ cao', 1),
(N'CA021', N'Cổ polo basic', 1),
(N'CA022', N'Cổ tròn cổ thấp', 1),
(N'CA023', N'Cổ chữ V bo tay', 1),
(N'CA024', N'Cổ tròn phối màu', 1),
(N'CA025', N'Cổ chữ V phối màu', 1),
(N'CA026', N'Cổ polo phối viền', 1),
(N'CA027', N'Cổ tròn basic retro', 1),
(N'CA028', N'Cổ chữ V basic retro', 1),
(N'CA029', N'Cổ áo phong cách Hàn', 1),
(N'CA030', N'Cổ tròn thể thao', 1);

-- Bảng Size 
INSERT INTO Size (ma_size, ten_size, Trang_thai)
VALUES
(N'S', N'S', 1),
(N'M', N'M', 1),
(N'L', N'L', 1),
(N'XL', N'XL', 1),
(N'XXL', N'XXL', 1),
(N'XXXL', N'XXXL', 1);

-- Bảng Màu sắc
INSERT INTO Mau_sac (ma_mau_sac, ten_mau, Trang_thai)
VALUES
(N'MS01', N'Trắng', 1),
(N'MS02', N'Đen', 1),
(N'MS03', N'Xanh dương', 1),
(N'MS04', N'Đỏ', 1),
(N'MS05', N'Vàng', 1),
(N'MS06', N'Xanh lá', 1),
(N'MS07', N'Xám', 1),
(N'MS08', N'Hồng', 1),
(N'MS09', N'Cam', 1),
(N'MS10', N'Tím', 1),
(N'MS11', N'Nâu', 1),
(N'MS12', N'Be', 1),
(N'MS13', N'Xanh nhạt', 1),
(N'MS14', N'Xanh đậm', 1),
(N'MS15', N'Đỏ đô', 1),
(N'MS16', N'Hồng nhạt', 1),
(N'MS17', N'Tím nhạt', 1),
(N'MS18', N'Xanh rêu', 1),
(N'MS19', N'Cam nhạt', 1),
(N'MS20', N'Vàng nhạt', 1),
(N'MS21', N'Trắng sữa', 1),
(N'MS22', N'Đen nhám', 1),
(N'MS23', N'Xanh biển', 1),
(N'MS24', N'Đỏ cam', 1),
(N'MS25', N'Xám nhạt', 1),
(N'MS26', N'Hồng đậm', 1),
(N'MS27', N'Tím than', 1),
(N'MS28', N'Xanh cẩm', 1),
(N'MS29', N'Vàng chanh', 1),
(N'MS30', N'Be nhạt', 1);

-- Bảng Chất liệu
INSERT INTO Chat_lieu (ma_chat_lieu, ten_chat_lieu, Trang_thai)
VALUES
(N'CL01',N'Cotton 100%',1),
(N'CL02',N'Polyester',1),
(N'CL03',N'Cotton-Poly Blend',1),
(N'CL04',N'Bamboo',1),
(N'CL05',N'Modal',1),
(N'CL06',N'Linen',1),
(N'CL07',N'Rayon',1),
(N'CL08',N'Viscose',1),
(N'CL09',N'Spandex',1),
(N'CL10',N'Nylon',1),
(N'CL11',N'Tencel',1),
(N'CL12',N'Microfiber',1),
(N'CL13',N'Silk',1),
(N'CL14',N'Wool',1),
(N'CL15',N'Cashmere',1),
(N'CL16',N'Denim',1),
(N'CL17',N'Hemp',1),
(N'CL18',N'Bamboo Cotton',1),
(N'CL19',N'Jersey Cotton',1),
(N'CL20',N'French Terry',1),
(N'CL21',N'Fleece',1),
(N'CL22',N'Poly-Cotton 65/35',1),
(N'CL23',N'Organic Cotton',1),
(N'CL24',N'Tri-Blend',1),
(N'CL25',N'Mesh',1),
(N'CL26',N'Pima Cotton',1),
(N'CL27',N'Supima Cotton',1),
(N'CL28',N'Rib Knit',1),
(N'CL29',N'Slub Cotton',1),
(N'CL30',N'Combed Cotton',1);

-- Bảng Voucher
INSERT INTO Voucher (ma_code_voucher, loai_giam_gia, gia_tri_giam, muc_giam_toi_da, dieu_kien, so_luong, ten_chuong_trinh_giam_gia, ngay_bat_dau, ngay_ket_thuc)
VALUES
(N'V001', N'%', 10, 200000, 500000, 100, N'TetSale', '2025-01-15', '2025-02-05'),
(N'V002', N'Tien', 50000, NULL, 300000, 100, N'TetSale', '2025-01-15', '2025-02-05'),
(N'V003', N'%', 15, 300000, 700000, 100, N'TetSale', '2025-01-15', '2025-02-05'),
(N'V004', N'%', 5, 100000, 200000, 100, N'HungVuongFestival', '2025-04-09', '2025-04-11'),
(N'V005', N'Tien', 20000, NULL, 100000, 100, N'HungVuongFestival', '2025-04-09', '2025-04-11'),
(N'V006', N'%', 10, 150000, 300000, 100, N'WomensDay', '2025-03-06', '2025-03-09'),
(N'V007', N'Tien', 30000, NULL, 200000, 100, N'WomensDay', '2025-03-06', '2025-03-09'),
(N'V008', N'%', 10, 200000, 400000, 100, N'HolidaySale', '2025-04-28', '2025-05-02'),
(N'V009', N'Tien', 50000, NULL, 300000, 100, N'HolidaySale', '2025-04-28', '2025-05-02'),
(N'V010', N'%', 15, 300000, 500000, 100, N'NationalDaySale', '2025-09-01', '2025-09-03'),
(N'V011', N'Tien', 70000, NULL, 400000, 100, N'NationalDaySale', '2025-09-01', '2025-09-03'),
(N'V012', N'%', 20, 500000, 1000000, 100, N'BlackFriday', '2025-11-25', '2025-11-29'),
(N'V013', N'Tien', 100000, NULL, 500000, 100, N'BlackFriday', '2025-11-25', '2025-11-29'),
(N'V014', N'%', 15, 400000, 700000, 100, N'ChristmasSale', '2025-12-20', '2025-12-25'),
(N'V015', N'Tien', 80000, NULL, 400000, 100, N'ChristmasSale', '2025-12-20', '2025-12-25'),
(N'V016', N'%', 5, 50000, 100000, 100, N'BackFinday', '2025-01-01', '2025-01-31'),
(N'V017', N'Tien', 20000, NULL, 150000, 100, N'BackFinday', '2025-02-01', '2025-02-28'),
(N'V018', N'%', 8, 80000, 200000, 100, N'BackFinday', '2025-03-01', '2025-03-31'),
(N'V019', N'Tien', 30000, NULL, 250000, 100, N'BackFinday', '2025-04-01', '2025-04-30'),
(N'V020', N'%', 10, 150000, 300000, 100, N'BackFinday', '2025-05-01', '2025-05-31'),
(N'V021', N'Tien', 40000, NULL, 350000, 100, N'BackFinday', '2025-06-01', '2025-06-30'),
(N'V022', N'%', 12, 200000, 400000, 100, N'BackFinday', '2025-07-01', '2025-07-31'),
(N'V023', N'Tien', 50000, NULL, 450000, 100, N'BackFinday', '2025-08-01', '2025-08-31'),
(N'V024', N'%', 15, 300000, 600000, 100, N'BackFinday', '2025-09-01', '2025-09-30'),
(N'V025', N'Tien', 60000, NULL, 500000, 100, N'BackFinday', '2025-10-01', '2025-10-31'),
(N'V026', N'%', 10, 200000, 400000, 100, N'BackFinday', '2025-11-01', '2025-11-30'),
(N'V027', N'Tien', 70000, NULL, 500000, 100, N'BackFinday', '2025-12-01', '2025-12-20'),
(N'V028', N'%', 20, 500000, 1000000, 100, N'BlackFriday', '2025-11-25', '2025-11-29'),
(N'V029', N'Tien', 100000, NULL, 600000, 100, N'ChristmasSale', '2025-12-20', '2025-12-25'),
(N'V030', N'%', 25, 500000, 1000000, 100, N'ChristmasSale', '2025-12-20', '2025-12-25');

-- Bảng Sản phẩm
INSERT INTO San_pham (ma_san_pham, ten_san_pham, Mo_ta_san_pham, ID_co_ao, ID_thuong_hieu, ID_chat_lieu)
VALUES
(N'SP001', N'Nike Tee Cotton Basic', N'Áo thun cổ tròn cơ bản, Cotton 100% mềm mại.', 1, 1, 1),
(N'SP002', N'Adidas Cổ V Classic', N'Áo thun dáng ôm, cổ V tôn dáng, chất Polyester cao cấp.', 3, 2, 2),
(N'SP003', N'Puma Polo Sport', N'Áo Polo thể thao, form ôm nhẹ, Cotton-Poly thoáng mát.', 5, 3, 3),
(N'SP004', N'UA Tee Bamboo Viền Cổ', N'Áo thun form rộng, Bamboo mềm, chống khuẩn, viền cổ nổi bật.', 9, 4, 4),
(N'SP005', N'Reebok Cổ V Sâu Modal', N'Áo thun co giãn, cổ V sâu, Modal siêu nhẹ.', 4, 5, 5),
(N'SP006', N'NB Polo Linen Viền', N'Áo Polo Linen mát, thiết kế viền cổ tay.', 13, 6, 6),
(N'SP007', N'Converse Cổ Tim Rayon', N'Áo thun classic, cổ tim nhẹ nhàng, chất Rayon mượt.', 6, 7, 7),
(N'SP008', N'Vans Cổ Tàu Viscose', N'Áo thun kiểu cách, cổ tàu, Viscose mỏng nhẹ.', 7, 8, 8),
(N'SP009', N'Fila Tee Tay Dài Spandex', N'Áo thun dài tay, Spandex co giãn 4 chiều.', 11, 9, 9),
(N'SP010', N'Levi''s Polo Classic Nylon', N'Áo Polo dáng suông, Nylon bền màu.', 5, 10, 10),
(N'SP011', N'H&M Tee Oversize Tencel', N'Áo thun cổ tròn rộng, Tencel thân thiện môi trường.', 2, 11, 11),
(N'SP012', N'Zara Cổ V Cropped Microfiber', N'Áo thun ngắn, cổ V bo gấu, Microfiber siêu nhẹ.', 15, 12, 12),
(N'SP013', N'Uniqlo Polo Silk Basic', N'Áo Polo dệt kim, lụa Silk mềm mịn, form suông.', 21, 13, 13),
(N'SP014', N'Gap Tee Phối Màu Wool', N'Áo thun dài tay, cổ tròn phối màu, chất Wool giữ ấm.', 24, 14, 14),
(N'SP015', N'Tommy Cổ V Cashmere Blend', N'Áo thun cao cấp, Cashmere pha, cổ V nổi bật.', 25, 15, 15),
(N'SP016', N'RL Polo Denim Viền', N'Áo Polo cá tính, Denim mỏng, phối viền cổ.', 26, 16, 16),
(N'SP017', N'Champion Tee Retro Hemp', N'Áo thun phong cách retro, Hemp/Cotton thoáng mát.', 27, 17, 17),
(N'SP018', N'Columbia Cổ V Bamboo Cotton', N'Áo thun dã ngoại, Bamboo Cotton thoáng khí.', 28, 18, 18),
(N'SP019', N'TNF Polo Style Korea', N'Áo Polo phong cách Hàn Quốc, Jersey Cotton.', 29, 19, 19),
(N'SP020', N'Patagonia Tee Gym French Terry', N'Áo thun tập gym, French Terry thấm hút tốt.', 30, 20, 20),
(N'SP021', N'Balenciaga Tee Tay Dài Fleece', N'Áo thun tay dài, chất Fleece giữ ấm nhẹ.', 11, 21, 21),
(N'SP022', N'Gucci Tee Form Rộng Poly-Cotton', N'Áo thun form rộng, Poly-Cotton 65/35.', 2, 22, 22),
(N'SP023', N'Prada Polo Organic Cotton', N'Áo Polo cao cấp, Organic Cotton.', 5, 23, 23),
(N'SP024', N'LV Tee Họa Tiết Tri-Blend', N'Áo thun họa tiết, Tri-Blend co giãn.', 1, 24, 24),
(N'SP025', N'Versace Polo Mesh', N'Áo Polo thể thao, vải Mesh thoáng khí.', 5, 25, 25),
(N'SP026', N'Armani Cổ Tim Pima Cotton', N'Áo thun cổ tim, Pima Cotton siêu mịn.', 6, 26, 26),
(N'SP027', N'Burberry Cổ Tàu Supima Cotton', N'Áo thun cổ tàu, Supima Cotton cao cấp.', 7, 27, 27),
(N'SP028', N'Givenchy Cổ Thuyền Rib Knit', N'Áo thun cổ thuyền, Rib Knit co giãn tốt.', 8, 28, 28),
(N'SP029', N'Off-White Polo Slub Cotton', N'Áo Polo kiểu mới, Slub Cotton xước độc đáo.', 5, 29, 29),
(N'SP030', N'Supreme Tee Combed Cotton', N'Áo thun cơ bản, Combed Cotton chải kỹ.', 1, 30, 30);

-- BẢNG SẢN PHẨM CHI TIẾT
INSERT INTO San_pham_chi_tiet (ID_san_pham, ma_san_pham_chi_tiet, ID_size, ID_mau_sac, so_luong_ton, don_gia, Ma_nguoi_tao)
VALUES
(1, N'SP001-M-W', 2, 1, 50, 250000, N'system'),
(2, N'SP002-S-B', 1, 2, 40, 260000, N'system'),
(3, N'SP003-L-R', 3, 3, 60, 270000, N'system'),
(4, N'SP004-M-G', 2, 4, 55, 280000, N'system'),
(5, N'SP005-S-Y', 1, 5, 45, 290000, N'system'),
(6, N'SP006-L-B', 3, 2, 50, 300000, N'system'),
(7, N'SP007-M-R', 2, 3, 60, 310000, N'system'),
(8, N'SP008-S-W', 1, 1, 40, 320000, N'system'),
(9, N'SP009-L-G', 3, 4, 55, 330000, N'system'),
(10, N'SP010-M-Y', 2, 5, 50, 340000, N'system'),
(11, N'SP011-S-B', 1, 2, 45, 350000, N'system'),
(12, N'SP012-L-R', 3, 3, 60, 360000, N'system'),
(13, N'SP013-M-W', 2, 1, 55, 370000, N'system'),
(14, N'SP014-S-G', 1, 4, 40, 380000, N'system'),
(15, N'SP015-L-Y', 3, 5, 50, 390000, N'system'),
(16, N'SP016-M-B', 2, 2, 45, 400000, N'system'),
(17, N'SP017-S-R', 1, 3, 60, 410000, N'system'),
(18, N'SP018-L-W', 3, 1, 50, 420000, N'system'),
(19, N'SP019-M-G', 2, 4, 55, 430000, N'system'),
(20, N'SP020-S-Y', 1, 5, 45, 440000, N'system'),
(21, N'SP021-L-B', 3, 2, 50, 450000, N'system'),
(22, N'SP022-M-R', 2, 3, 60, 460000, N'system'),
(23, N'SP023-S-W', 1, 1, 40, 470000, N'system'),
(24, N'SP024-L-G', 3, 4, 55, 480000, N'system'),
(25, N'SP025-M-Y', 2, 5, 50, 490000, N'system'),
(26, N'SP026-S-B', 1, 2, 45, 500000, N'system'),
(27, N'SP027-L-R', 3, 3, 60, 510000, N'system'),
(28, N'SP028-M-W', 2, 1, 55, 520000, N'system'),
(29, N'SP029-S-G', 1, 4, 40, 530000, N'system'),
(30, N'SP030-L-Y', 3, 5, 50, 540000, N'system');

--Bảng Hóa đơn
INSERT INTO Hoa_don
(ID_khach_hang, ID_nhan_vien, ID_voucher, ten_nguoi_nhan, SDT_nguoi_nhan, ghi_chu,
 tong_tien_tam_tinh, tien_giam_voucher, tong_tien_thanh_toan, phuong_thuc_thanh_toan, ngay_lap_hoa_don, trang_thai_thanh_toan)
VALUES

(1, 1, 1, N'Nguyễn Phương Linh', N'0912345670', N'Chưa thanh toán', 500000, 50000, 450000, 1, '2025-12-11', 0),
(2, 2, 2, N'Trần Duy Tuấn', N'0923456781', N'Chưa thanh toán', 700000, 100000, 600000, 0, '2025-12-11', 0),
(3, 3, NULL, N'Lê Minh Phương', N'0934567892', N'Chưa thanh toán', 300000, 0, 300000, 1, '2025-12-11', 0),
(4, 4, 3, N'Phạm Ngọc Bích', N'0945678903', N'Chưa thanh toán', 450000, 50000, 400000, 0, '2025-12-11', 0),
(5, 5, NULL, N'Ngô Văn Duy', N'0956789014', N'Chưa thanh toán', 350000, 0, 350000, 1, '2025-12-11', 0),
(6, 6, 4, N'Đỗ Thị Hạnh', N'0967890125', N'Chưa thanh toán', 800000, 100000, 700000, 0, '2025-12-11', 0),
(7, 7, NULL, N'Bùi Minh Quân', N'0978901236', N'Chưa thanh toán', 600000, 50000, 550000, 1, '2025-12-11', 0),

(8, 8, 5, N'Nguyễn Thị Lan', N'0989012347', N'Đã thanh toán', 400000, 40000, 360000, 1, '2024-01-12', 1),
(9, 9, 6, N'Phan Văn Hoàng', N'0911122334', N'Đã thanh toán', 500000, 50000, 450000, 0, '2023-03-15', 1),
(10, 10, NULL, N'Trương Thị Mai', N'0922233445', N'', 300000, 0, 300000, 1, '2022-05-20', 1),
(11, 11, 7, N'Vũ Đức Tùng', N'0933344556', N'', 700000, 70000, 630000, 0, '2021-07-22', 1),
(12, 12, NULL, N'Ngô Thị Hồng', N'0944455667', N'', 450000, 0, 450000, 1, '2020-09-18', 1),
(13, 13, 8, N'Lý Minh Anh', N'0955566778', N'', 600000, 50000, 550000, 0, '2020-11-25', 1),
(14, 14, NULL, N'Đặng Thị Thảo', N'0966677889', N'', 350000, 0, 350000, 1, '2021-01-08', 1),
(15, 15, 9, N'Phạm Minh Đức', N'0977788990', N'', 500000, 50000, 450000, 1, '2021-02-14', 1),
(16, 16, NULL, N'Trần Thị Vy', N'0988899001', N'', 400000, 0, 400000, 0, '2022-03-20', 1),
(17, 17, 10, N'Nguyễn Văn Khang', N'0919900112', N'', 550000, 50000, 500000, 1, '2022-04-25', 1),
(18, 18, NULL, N'Lê Thị Ngọc', N'0921011223', N'', 300000, 0, 300000, 1, '2023-05-12', 1),
(19, 19, 11, N'Phạm Văn Sơn', N'0932122334', N'', 600000, 60000, 540000, 0, '2023-06-08', 1),
(20, 20, NULL, N'Trịnh Thị Hương', N'0943233445', N'', 400000, 0, 400000, 1, '2023-07-20', 1),
(21, 21, 12, N'Nguyễn Văn Phúc', N'0954344556', N'', 500000, 50000, 450000, 0, '2024-08-18', 1),
(22, 22, NULL, N'Lê Thị Thanh', N'0965455667', N'', 350000, 0, 350000, 1, '2024-09-12', 1),
(23, 23, 13, N'Phan Minh Tuấn', N'0976566778', N'', 400000, 40000, 360000, 1, '2024-10-25', 1),
(24, 24, NULL, N'Vũ Thị Lan', N'0987677889', N'', 450000, 0, 450000, 0, '2024-11-15', 1),
(25, 25, 14, N'Đỗ Văn Huy', N'0918788990', N'', 500000, 50000, 450000, 1, '2025-01-10', 1),
(26, 26, NULL, N'Trần Thị Mai Anh', N'0929899001', N'', 300000, 0, 300000, 1, '2025-02-20', 1),
(27, 27, 15, N'Nguyễn Minh Tuấn', N'0930900112', N'', 550000, 50000, 500000, 0, '2025-03-01', 1),
(28, 28, NULL, N'Lê Thị Bích Ngọc', N'0941011223', N'', 400000, 0, 400000, 1, '2025-04-10', 1),
(29, 29, 16, N'Phạm Văn Duy', N'0952122334', N'', 600000, 60000, 540000, 0, '2025-05-15', 1),
(30, 30, NULL, N'Đặng Thị Hồng Nhung', N'0963233445', N'', 500000, 0, 500000, 1, '2025-06-20', 1);

-- Bảng Hóa đơn chi tiết
INSERT INTO Hoa_don_chi_tiet (ID_hoa_don, ID_san_pham_chi_tiet, so_luong, don_gia, Trang_thai)
VALUES  
(8, 8, 1, 320000, 1),  
(9, 9, 2, 330000, 1), 
(10, 10, 1, 340000, 1), 
(11, 11, 3, 350000, 1), 
(12, 12, 1, 360000, 1),
(13, 13, 2, 370000, 1),
(14, 14, 1, 380000, 1),
(15, 15, 2, 390000, 1),
(16, 16, 1, 400000, 1),
(17, 17, 3, 410000, 1),
(18, 18, 2, 420000, 1),
(19, 19, 1, 430000, 1),
(20, 20, 2, 440000, 1),
(21, 21, 1, 450000, 1),
(22, 22, 2, 460000, 1),
(23, 23, 1, 470000, 1),
(24, 24, 2, 480000, 1),
(25, 25, 1, 490000, 1),
(26, 26, 3, 500000, 1),
(27, 27, 1, 510000, 1),
(28, 28, 2, 520000, 1),
(29, 29, 1, 530000, 1),
(30, 30, 2, 540000, 1);


DECLARE @startDate DATE = '2020-01-01';
DECLARE @endDate DATE = '2025-12-07';
DECLARE @months INT = DATEDIFF(MONTH, @startDate, @endDate) + 1;

-- Lấy danh sách khách hàng, nhân viên, sản phẩm chi tiết
DECLARE @khachHang TABLE (ID_khach_hang INT, ten_khach_hang NVARCHAR(150), SDT NVARCHAR(10));
INSERT INTO @khachHang
SELECT ID_khach_hang, ten_khach_hang, SDT FROM Khach_hang;

DECLARE @nhanVien TABLE (ID_nhan_vien INT);
INSERT INTO @nhanVien
SELECT ID_nhan_vien FROM Nhan_vien;

DECLARE @sanPhamChiTiet TABLE (ID_san_pham_chi_tiet INT, don_gia DECIMAL(12,2));
INSERT INTO @sanPhamChiTiet
SELECT ID_san_pham_chi_tiet, don_gia
FROM San_pham_chi_tiet;

DECLARE @voucher TABLE (ID_voucher INT, loai_giam_gia NVARCHAR(10), gia_tri_giam DECIMAL(12,2), muc_giam_toi_da DECIMAL(12,2));
INSERT INTO @voucher
SELECT ID_voucher, loai_giam_gia, gia_tri_giam, muc_giam_toi_da
FROM Voucher;

DECLARE @i INT = 0;
WHILE @i < @months
BEGIN
    DECLARE @monthStart DATE = DATEADD(MONTH, @i, @startDate);
    DECLARE @monthEnd DATE = EOMONTH(@monthStart);

    DECLARE @invoiceCount INT = 0;
    WHILE @invoiceCount < 50
    BEGIN
        -- Chọn ngẫu nhiên khách hàng, nhân viên
        DECLARE @khID INT, @khName NVARCHAR(150), @khSDT NVARCHAR(10);
        SELECT TOP 1 @khID = ID_khach_hang, @khName = ten_khach_hang, @khSDT = SDT
        FROM @khachHang ORDER BY NEWID();

        DECLARE @nvID INT;
        SELECT TOP 1 @nvID = ID_nhan_vien FROM @nhanVien ORDER BY NEWID();

        -- Ngày lập hóa đơn ngẫu nhiên trong tháng
        DECLARE @ngayLap DATETIME =
            DATEADD(DAY, ABS(CHECKSUM(NEWID())) % (DATEDIFF(DAY, @monthStart, @monthEnd)+1), @monthStart);

        -- Chọn voucher ngẫu nhiên hoặc NULL
        DECLARE @voucherID INT = NULL;
        IF (ABS(CHECKSUM(NEWID())) % 2 = 0)
        BEGIN
            SELECT TOP 1 @voucherID = ID_voucher FROM @voucher ORDER BY NEWID();
        END

        -- Tạo hóa đơn (tiền = 0 trước)
        INSERT INTO Hoa_don
            (ID_khach_hang, ID_nhan_vien, ID_voucher,
             ten_nguoi_nhan, SDT_nguoi_nhan, ngay_lap_hoa_don,
             trang_thai_thanh_toan, tong_tien_tam_tinh, tien_giam_voucher, tong_tien_thanh_toan)
        VALUES
            (@khID, @nvID, @voucherID,
             @khName, @khSDT, @ngayLap,
             1, 0, 0, 0);

        DECLARE @lastInvoiceID INT = SCOPE_IDENTITY();

        -- Tạo 2-3 hóa đơn chi tiết ngẫu nhiên
        DECLARE @detailCount INT = 2 + (ABS(CHECKSUM(NEWID())) % 2); -- 2 hoặc 3
        DECLARE @j INT = 1;

        WHILE @j <= @detailCount
        BEGIN
            DECLARE @spID INT, @donGia DECIMAL(12,2), @soLuong INT;
            SELECT TOP 1 @spID = ID_san_pham_chi_tiet, @donGia = don_gia
            FROM @sanPhamChiTiet ORDER BY NEWID();

            SET @soLuong = 1 + (ABS(CHECKSUM(NEWID())) % 5); -- 1 -> 5

            INSERT INTO Hoa_don_chi_tiet
                (ID_hoa_don, ID_san_pham_chi_tiet, so_luong, don_gia, Trang_thai)
            VALUES
                (@lastInvoiceID, @spID, @soLuong, @donGia, 1);

            SET @j = @j + 1;
        END

        SET @invoiceCount = @invoiceCount + 1;
    END

    SET @i = @i + 1;
END


UPDATE hd
SET 
    tong_tien_tam_tinh = ISNULL(sub.tong, 0),

    tien_giam_voucher =
        CASE 
            WHEN hd.ID_voucher IS NULL THEN 0
            WHEN v.loai_giam_gia = '%' 
                THEN (ISNULL(sub.tong,0) * v.gia_tri_giam / 100)
            ELSE ISNULL(v.gia_tri_giam, 0)
        END,

    tong_tien_thanh_toan =
        CASE 
            WHEN hd.ID_voucher IS NULL THEN ISNULL(sub.tong, 0)
            ELSE 
                CASE 
                    WHEN (
                        ISNULL(sub.tong,0)
                        - CASE 
                            WHEN v.loai_giam_gia = '%' THEN ISNULL(sub.tong,0) * v.gia_tri_giam / 100
                            ELSE ISNULL(v.gia_tri_giam,0)
                          END
                    ) < 0 
                        THEN 0
                    ELSE (
                        ISNULL(sub.tong,0)
                        - CASE 
                            WHEN v.loai_giam_gia = '%' THEN ISNULL(sub.tong,0) * v.gia_tri_giam / 100
                            ELSE ISNULL(v.gia_tri_giam,0)
                          END
                    )
                END
        END
FROM Hoa_don hd
LEFT JOIN Voucher v ON hd.ID_voucher = v.ID_voucher
CROSS APPLY (
    SELECT SUM(so_luong * don_gia) AS tong
    FROM Hoa_don_chi_tiet
    WHERE ID_hoa_don = hd.ID_hoa_don
) sub;


-- Trigger tự set Ngay_tao Nhan_vien
CREATE TRIGGER trg_Nhan_vien_Insert
ON Nhan_vien
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Nhan_vien
    SET Ngay_tao = GETDATE()
    WHERE ID_nhan_vien IN (SELECT ID_nhan_vien FROM inserted);
END
GO

-- Trigger cập nhật Ngay_cap_nhat và Ma_nguoi_cap_nhat Nhan_vien
CREATE TRIGGER trg_Nhan_vien_Update
ON Nhan_vien
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE nv
    SET nv.Ngay_cap_nhat = GETDATE(),
        nv.Ma_nguoi_cap_nhat = i.Ma_nguoi_cap_nhat
    FROM Nhan_vien nv
    JOIN inserted i ON nv.ID_nhan_vien = i.ID_nhan_vien;
END
GO

-- Trigger Khach_hang Insert
CREATE TRIGGER trg_Khach_hang_Insert
ON Khach_hang
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Khach_hang
    SET Ngay_tao = GETDATE()
    WHERE ID_khach_hang IN (SELECT ID_khach_hang FROM inserted);
END
GO

-- Trigger Khach_hang Update
CREATE TRIGGER trg_Khach_hang_Update
ON Khach_hang
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE kh
    SET kh.Ngay_cap_nhat = GETDATE(),
        kh.Ma_nguoi_cap_nhat = i.Ma_nguoi_cap_nhat
    FROM Khach_hang kh
    JOIN inserted i ON kh.ID_khach_hang = i.ID_khach_hang;
END
GO

-- Trigger San_pham_chi_tiet Insert
CREATE TRIGGER trg_San_pham_chi_tiet_Insert
ON San_pham_chi_tiet
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE San_pham_chi_tiet
    SET Ngay_tao = GETDATE()
    WHERE ID_san_pham_chi_tiet IN (SELECT ID_san_pham_chi_tiet FROM inserted);
END
GO

-- Trigger San_pham_chi_tiet Update
CREATE TRIGGER trg_San_pham_chi_tiet_Update
ON San_pham_chi_tiet
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE sp
    SET sp.Ngay_cap_nhat = GETDATE(),
        sp.Ma_nguoi_cap_nhat = i.Ma_nguoi_cap_nhat
    FROM San_pham_chi_tiet sp
    JOIN inserted i ON sp.ID_san_pham_chi_tiet = i.ID_san_pham_chi_tiet;
END
GO

-- Trigger Hoa_don_chi_tiet Insert (trừ tồn kho, check đủ tồn)
CREATE OR ALTER TRIGGER trg_Hoa_don_chi_tiet_Insert
ON Hoa_don_chi_tiet
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;
    -- Kiểm tra tồn kho
    IF EXISTS (
        SELECT 1
        FROM inserted i
        JOIN San_pham_chi_tiet sp ON i.ID_san_pham_chi_tiet = sp.ID_san_pham_chi_tiet
        WHERE sp.So_luong_ton < i.so_luong
    )
    BEGIN
        RAISERROR('Số lượng tồn không đủ.',16,1);
        ROLLBACK TRANSACTION;
        RETURN;
    END
    -- Trừ tồn kho
    UPDATE sp
    SET sp.So_luong_ton = sp.So_luong_ton - i.so_luong
    FROM San_pham_chi_tiet sp
    JOIN inserted i ON sp.ID_san_pham_chi_tiet = i.ID_san_pham_chi_tiet;
END
GO

-- Trigger Hoa_don_chi_tiet Update (update tồn kho)
CREATE OR ALTER TRIGGER trg_Hoa_don_chi_tiet_Update
ON Hoa_don_chi_tiet
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1
        FROM inserted i
        JOIN deleted d ON i.ID_hdct = d.ID_hdct
        JOIN San_pham_chi_tiet sp ON i.ID_san_pham_chi_tiet = sp.ID_san_pham_chi_tiet
        WHERE sp.So_luong_ton + d.so_luong - i.so_luong < 0
    )
    BEGIN
        RAISERROR('Số lượng tồn không đủ sau khi update!',16,1);
        ROLLBACK TRANSACTION;
        RETURN;
    END
    -- Cập nhật tồn kho
    UPDATE sp
    SET sp.So_luong_ton = sp.So_luong_ton + d.so_luong - i.so_luong
    FROM San_pham_chi_tiet sp
    JOIN inserted i ON sp.ID_san_pham_chi_tiet = i.ID_san_pham_chi_tiet
    JOIN deleted d ON i.ID_hdct = d.ID_hdct;
END
GO

-- Trigger Hoa_don_chi_tiet Delete (cộng lại tồn kho)
CREATE OR ALTER TRIGGER trg_Hoa_don_chi_tiet_Delete
ON Hoa_don_chi_tiet
AFTER DELETE
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE sp
    SET sp.So_luong_ton = sp.So_luong_ton + d.so_luong
    FROM San_pham_chi_tiet sp
    JOIN deleted d ON sp.ID_san_pham_chi_tiet = d.ID_san_pham_chi_tiet;
END
GO

-- Trigger Hoa_don Delete (cộng tồn kho + xóa chi tiết)
CREATE OR ALTER TRIGGER trg_Hoa_don_Delete_Optimized
ON Hoa_don
AFTER DELETE
AS
BEGIN
    SET NOCOUNT ON;
    -- Cộng lại tồn kho từ chi tiết hóa đơn vừa bị xóa
    UPDATE sp
    SET sp.So_luong_ton = sp.So_luong_ton + hdct.so_luong
    FROM San_pham_chi_tiet sp
    JOIN Hoa_don_chi_tiet hdct
        ON sp.ID_san_pham_chi_tiet = hdct.ID_san_pham_chi_tiet
    WHERE hdct.ID_hoa_don IN (SELECT ID_hoa_don FROM deleted);
    -- Xóa chi tiết hóa đơn
    DELETE FROM Hoa_don_chi_tiet
    WHERE ID_hoa_don IN (SELECT ID_hoa_don FROM deleted);
END
GO

-- Trigger cập nhật trạng thái sản phẩm dựa vào tổng tồn
CREATE OR ALTER TRIGGER trg_SanPham_StopSelling
ON San_pham_chi_tiet
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;
    -- Cập nhật trạng thái sản phẩm
    UPDATE sp
    SET sp.Trang_thai = CASE WHEN ISNULL(spt.TongTon,0) <= 0 THEN 0 ELSE 1 END
    FROM San_pham sp
    JOIN (
        SELECT ID_san_pham, SUM(so_luong_ton) AS TongTon
        FROM San_pham_chi_tiet
        GROUP BY ID_san_pham
    ) spt ON sp.ID_san_pham = spt.ID_san_pham;
END
GO

-- Trigger Voucher khi insert hóa đơn
CREATE OR ALTER TRIGGER trg_Voucher_Use
ON Hoa_don
AFTER INSERT
AS
BEGIN
    SET NOCOUNT ON;

    -- Giảm số lượng voucher
    UPDATE Voucher
    SET So_luong = So_luong - 1
    WHERE ID_voucher IN (SELECT ID_voucher FROM inserted)
      AND ID_voucher IS NOT NULL
      AND So_luong > 0;

    -- Nếu số lượng = 0 → ngừng trạng thái
    UPDATE Voucher
    SET Trang_thai = 0
    WHERE So_luong <= 0;
END
GO
-- Trigger Voucher hết hạn (cập nhật tự động khi update/insert)
CREATE TRIGGER trg_Voucher_Expire
ON Voucher
AFTER UPDATE, INSERT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE Voucher
    SET Trang_thai = 0
    WHERE ngay_ket_thuc < CAST(GETDATE() AS DATE);
END
GO
-- Trigger cập nhật chi tiết hóa đơn khi hóa đơn được thanh toán
CREATE OR ALTER TRIGGER trg_Hoa_don_Update_Paid
ON Hoa_don
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;

    -- Chỉ update chi tiết nếu trạng thái thanh toán vừa chuyển từ 0 → 1
    UPDATE hdct
    SET hdct.Trang_thai = 1
    FROM Hoa_don_chi_tiet hdct
    JOIN inserted i ON hdct.ID_hoa_don = i.ID_hoa_don
    JOIN deleted d ON i.ID_hoa_don = d.ID_hoa_don
    WHERE d.trang_thai_thanh_toan = 0
      AND i.trang_thai_thanh_toan = 1;
END
GO
CREATE OR ALTER TRIGGER trg_Hoa_don_chi_tiet_CheckStopSelling
ON Hoa_don_chi_tiet
AFTER INSERT, UPDATE, DELETE
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE spct
    SET spct.Trang_thai = CASE  WHEN spct.So_luong_ton <= 0 THEN 0 ELSE 1 END
    FROM San_pham_chi_tiet spct
    JOIN inserted i ON spct.ID_san_pham_chi_tiet = i.ID_san_pham_chi_tiet
    WHERE i.ID_san_pham_chi_tiet IS NOT NULL;

    UPDATE spct
    SET spct.Trang_thai = CASE    WHEN spct.So_luong_ton <= 0 THEN 0 ELSE 1 END
    FROM San_pham_chi_tiet spct
    JOIN deleted d ON spct.ID_san_pham_chi_tiet = d.ID_san_pham_chi_tiet
    WHERE d.ID_san_pham_chi_tiet IS NOT NULL;
END
GO
CREATE OR ALTER TRIGGER trg_HoaDon_Update_Voucher
ON Hoa_don
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF EXISTS (
        SELECT 1 
        FROM inserted i
        JOIN Voucher v ON v.ID_voucher = i.ID_voucher
        LEFT JOIN deleted d ON d.ID_hoa_don = i.ID_hoa_don
        WHERE i.ID_voucher IS NOT NULL
          AND (d.ID_voucher IS NULL OR d.ID_voucher <> i.ID_voucher)
          AND v.So_luong <= 0
    )
    BEGIN
        RAISERROR('Voucher da het so luong', 16, 1);
        ROLLBACK TRANSACTION;
        RETURN;
    END

    UPDATE v
    SET v.So_luong = v.So_luong - 1
    FROM Voucher v
    JOIN inserted i ON i.ID_voucher = v.ID_voucher
    LEFT JOIN deleted d ON d.ID_hoa_don = i.ID_hoa_don
    WHERE i.ID_voucher IS NOT NULL
      AND (d.ID_voucher IS NULL OR d.ID_voucher <> i.ID_voucher);

    UPDATE Voucher
    SET Trang_thai = 0
    WHERE So_luong = 0;
END
GO

CREATE OR ALTER TRIGGER trg_Update_DonGia_HDCT_When_SPCT_Updated
ON San_pham_chi_tiet
AFTER UPDATE
AS
BEGIN
    SET NOCOUNT ON;
    IF NOT UPDATE(don_gia)
        RETURN;

    UPDATE hdct
    SET hdct.don_gia = i.don_gia
    FROM Hoa_don_chi_tiet hdct
    JOIN inserted i 
        ON hdct.ID_san_pham_chi_tiet = i.ID_san_pham_chi_tiet
    JOIN Hoa_don hd 
        ON hdct.ID_hoa_don = hd.ID_hoa_don
    WHERE hd.trang_thai_thanh_toan = 0;   -- chỉ hóa đơn chưa thanh toán
END
GO