/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ui;

import controller.Sanphamchitiet_CRUD;
import daoipml.Chatlieu_DAOIpml;
import daoipml.Coao_DAOIpml;
import daoipml.Mausac_DAOIpml;
import daoipml.Sanpham_DAOIpml;
import daoipml.Sanphamchitiet_DAOIpml;
import daoipml.Size_DAOIpml;
import daoipml.Thuonghieu_DAOIpml;
import entity.Chatlieu;
import entity.Coao;
import entity.Mausac;
import entity.Sanpham;
import entity.Sanphamchitiet;
import entity.Size;
import entity.Thuonghieu;
import java.awt.Cursor;
import static java.awt.Frame.ICONIFIED;
import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.NumberFormat;
import java.util.Locale;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author manhh
 */
public class FORM_QUAN_LY_SAN_PHAM_NV extends javax.swing.JFrame implements Sanphamchitiet_CRUD {

    /**
     * Creates new form FROM_THONGKE
     */
    private Sanphamchitiet_DAOIpml repoSPCT = new Sanphamchitiet_DAOIpml();
    private DefaultTableModel modeSPCT = new DefaultTableModel();
    private Sanpham_DAOIpml repoSP = new Sanpham_DAOIpml();
    private DefaultTableModel modeSP = new DefaultTableModel();
    private Chatlieu_DAOIpml repoCL = new Chatlieu_DAOIpml();
    private Coao_DAOIpml repoCA = new Coao_DAOIpml();
    private Size_DAOIpml repoSZ = new Size_DAOIpml();
    private Mausac_DAOIpml repoMS = new Mausac_DAOIpml();
    private Thuonghieu_DAOIpml repoTH = new Thuonghieu_DAOIpml();
    private DefaultTableModel modeTT = new DefaultTableModel();
    private int index = -1;
    private int lastSelectedRow = -1;

    public FORM_QUAN_LY_SAN_PHAM_NV() {
        initComponents();
        hienthilabel();  // hiển thi lable cho from (không xóa);
        this.fillToTablespchitiet();
        this.fillToTableSanpham();
        this.fillToTableMausac();
        txt_dongia.setFont(new java.awt.Font("Arial", 0, 14));

        //        cbo mau sac san pham 
        cbo_mausac_spct.removeAllItems();
        for (Mausac ms : repoMS.findAll()) {
            cbo_mausac_spct.addItem(ms.getTen_mau());
        }

//        cbo thuong hieu san pham
        cbo_thuonghieu_sp.removeAllItems();
        for (Thuonghieu th : repoTH.TENTHUONGHIEU()) {
            cbo_thuonghieu_sp.addItem(th.getTen_thuong_hieu());

        }
        //        cbo chat lieu san pham
        cbo_chatlieu_sp.removeAllItems();
        for (Chatlieu cl : repoCL.TENCHATLIEU()) {
            cbo_chatlieu_sp.addItem(cl.getTen_chat_lieu());
        }
//        cbo co ao chat lieu
        cbo_coao_spp.removeAllItems();
        for (Coao ca : repoCA.TENCOAO()) {
            cbo_coao_spp.addItem(ca.getTen_co_ao());
        }
//        cbo chat lieu san pham chieu tiet
        cbo_chatlieuspct_tim_kiem.removeAllItems();
        for (Chatlieu cl : repoCL.findAll()) {
            cbo_chatlieuspct_tim_kiem.addItem(cl.getTen_chat_lieu());
        }
        //        cbo thuong hieu san pham chieu tiet
        cbo_thuonghieuspct_tim_kiem.removeAllItems();
        for (Thuonghieu th : repoTH.findAll()) {
            cbo_thuonghieuspct_tim_kiem.addItem(th.getTen_thuong_hieu());

        }
        //        cbo co ao san pham chieu tiet
        cbo_coaospct_tim_kiem.removeAllItems();
        for (Coao ca : repoCA.findAll()) {
            cbo_coaospct_tim_kiem.addItem(ca.getTen_co_ao());
        }
        //        cbo size san pham chieu tiet
        cbo_sizespct_tim_kiem.removeAllItems();
        for (Size sz : repoSZ.findAll()) {
            cbo_sizespct_tim_kiem.addItem(sz.getTen_size());
        }
        //        cbo mau sac san pham chieu tiet
        cbo_mausacspct_tim_kiem.removeAllItems();
        for (Mausac ms : repoMS.findAll()) {
            cbo_mausacspct_tim_kiem.addItem(ms.getTen_mau());
        }

        cbo_thuonghieu_sp_timkiem.removeAllItems();
        for (Thuonghieu th : repoTH.findAll()) {
            cbo_thuonghieu_sp_timkiem.addItem(th.getTen_thuong_hieu());

        }
        cbo_size_spct.removeAllItems();
        for (Size sz : repoSZ.findAll()) {
            cbo_size_spct.addItem(sz.getTen_size());
        }
        cbo_trangthai_sp.removeAllItems();
        for (Size sz : repoSZ.findAll()) {
            cbo_size_spct.addItem(sz.getTen_size());
        }

        // Khai báo mảng trạng thái
        String[] TrangThaiSP = {"Hoạt động", "Không hoạt động"};

        // Thêm vào combobox ở phần sản phẩm và phần danh sách để cho tìm kiếm
        cbo_trangthai_sp.removeAllItems();
        for (String tt : TrangThaiSP) {
            cbo_trangthai_sp.addItem(tt);
        }

        cbo_trangthai_sp_timkiem.removeAllItems();
        for (String tt : TrangThaiSP) {
            cbo_trangthai_sp_timkiem.addItem(tt);
        }
        cbo_chatlieuspct_tim_kiem.addActionListener(e -> {
            String selected = (String) cbo_chatlieuspct_tim_kiem.getSelectedItem();
            fillToTablespchitietTCL(selected); // gọi fill dữ liệu bảng
        });
        cbo_coaospct_tim_kiem.addActionListener(e -> {
            String selected = (String) cbo_coaospct_tim_kiem.getSelectedItem();
            fillToTablespchitietTCA(selected); // gọi fill dữ liệu bảng
        });
        cbo_mausacspct_tim_kiem.addActionListener(e -> {
            String selected = (String) cbo_mausacspct_tim_kiem.getSelectedItem();
            fillToTablespchitietMS(selected); // gọi fill dữ liệu bảng
        });
        cbo_sizespct_tim_kiem.addActionListener(e -> {
            String selected = (String) cbo_sizespct_tim_kiem.getSelectedItem();
            fillToTablespchitietSZ(selected); // gọi fill dữ liệu bảng
        });
        cbo_thuonghieuspct_tim_kiem.addActionListener(e -> {
            String selected = (String) cbo_thuonghieuspct_tim_kiem.getSelectedItem();
            fillToTablespchitietTH(selected); // gọi fill dữ liệu bảng
        });
        cbo_thuonghieu_sp_timkiem.addActionListener(e -> {
            String selected = (String) cbo_thuonghieu_sp_timkiem.getSelectedItem();
            fillToTableSanphamTH(selected); // gọi fill dữ liệu bảng
        });
        cbo_trangthai_sp_timkiem.addActionListener(e -> {
            String selected = (String) cbo_trangthai_sp_timkiem.getSelectedItem();
            // gọi fill dữ liệu bảng
            if (selected.equals("Hoạt động")) {
                fillToTableSanphamTT(1);
            } else {
                fillToTableSanphamTT(0);
            }
        });
    }
// format lại tiền

    public String formatCurrency(BigDecimal amount) {
        if (amount == null) {
            return "0 ₫";
        }
        Locale vietnameseLocale = new Locale("vi", "VN");
        NumberFormat currencyFormatter = NumberFormat.getCurrencyInstance(vietnameseLocale);
        return currencyFormatter.format(amount).trim();
    }

    // format lại tiền
    public String formatMoneyVND(Object value) {
        try {
            double money = Double.parseDouble(
                    value.toString()
                            .replace(".", "")
                            .replace(",", "")
                            .replace("đ", "")
                            .trim()
            );

            DecimalFormat df = new DecimalFormat("#,###");
            return df.format(money) + " đ";   // ⭐ giữ ký tự đ
        } catch (Exception e) {
            return value.toString();
        }
    }

    public boolean checkTrong() {
        if (txt_masp.getText().isEmpty() || txt_tensp.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Bạn không được để trống SP");
            return false;
        } else {
            return true;
        }

    }

    public boolean chechTrungSP() {
        String maMoi = txt_masp.getText().trim();
        String tenMoi = txt_tensp.getText().trim();

        for (Sanpham sp : repoSP.findAll()) {
            String maHienCo = sp.getMa_san_pham().trim();
            String tenHienCo = sp.getTen_san_pham().trim();

            // Kiểm tra trùng TÊN sản phẩm
            if (tenMoi.equalsIgnoreCase(tenHienCo)) {
                JOptionPane.showMessageDialog(this, "Tên sản phẩm '" + tenMoi + "' đã tồn tại (Mã: " + maHienCo + ")! Vui lòng dùng tên khác.");
                return false;
            }

            // Kiểm tra trùng MÃ sản phẩm
            if (maMoi.equalsIgnoreCase(maHienCo)) {
                JOptionPane.showMessageDialog(this, "Mã sản phẩm '" + maMoi + "' đã tồn tại (Sản phẩm: " + tenHienCo + ")! Vui lòng dùng mã khác.");
                return false;
            }
        }
        return true;
    }
    //đoạn code mới 
    // check trống tìm kiếm sp

    public boolean checkTrongTK() {
        if (btn_ma_sp_timkiem.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Bạn không được để trống");
            return false;
        }

        return true;
    }
    //đoạn code mới 
    // check trống tìm kiếm spct

    public boolean checkTrongTKSPCT() {
        if (txt_maspcttimkiem.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Bạn không được để trống");
            return false;
        }

        return true;

    }

    public String randomCode(String prefix, int randomLength) {
        if (prefix == null) {
            prefix = "KH";
        }
        if (randomLength <= 0) {
            throw new IllegalArgumentException("Số ký tự random phải > 0");
        }
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        java.security.SecureRandom random = new java.security.SecureRandom();
        StringBuilder sb = new StringBuilder(prefix);
        for (int i = 0; i < randomLength; i++) {
            int idx = random.nextInt(chars.length());
            sb.append(chars.charAt(idx));
        }
        return sb.toString();
    }

    public boolean checkTrongSPCT() {
        // 1. Kiểm tra để trống
        if (txt_maspct.getText().trim().isEmpty() || txt_masp_spct.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Mã sản phẩm và Mã SPCT không được để trống");
            return false;
        }

        // 2. Kiểm tra Đơn giá và Số lượng
        try {
            double donGia = Double.parseDouble(txt_dongia.getText());
            int soLuong = Integer.parseInt(txt_soluong.getText());

            if (donGia <= 0) {
                JOptionPane.showMessageDialog(this, "Đơn giá  phải lớn hơn 0.");
                return false;
            } else if (soLuong <= 0) {
                JOptionPane.showMessageDialog(this, "Số lượng phải lớn hơn 0.");
                return false;
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(this, "Đơn giá và Số lượng phải là số hợp lệ.");
            return false;
        }

        return true;
    }

    public boolean checkTrongTT() {
        if (txt_ma_tc.getText().isEmpty() || txt_ten_tc.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Bạn không được để trống");
            return false;
        } else {
            return true;
        }

    }

    // check trùng spct khi thêm
    public boolean ChecktrungSPCT() {
        String maSPCTMoi = txt_maspct.getText().trim();
        String tenSPCTMoi = txt_tensp_spct.getText().trim();

        for (Sanphamchitiet spct : repoSPCT.findAll()) {
            String maHienCo = spct.getMa_san_pham_chi_tiet().trim();
            boolean maDaTrung = maSPCTMoi.equalsIgnoreCase(maHienCo);

            if (maDaTrung) {
                JOptionPane.showMessageDialog(this, "Mã sản phẩm chi tiết '" + maSPCTMoi + "' đã tồn tại! Vui lòng dùng mã khác.");
                return false;
            }
        }

        return true;
    }

    public boolean CheckupdateSP() {
        Sanpham sp = repoSP.IDSP(txt_masp.getText());
        boolean check = true;

        String masp = txt_masp.getText().trim();
        String TENsp = txt_tensp.getText().trim();

        for (Sanpham csp : repoSP.findAll()) {

            String maHienCo = csp.getMa_san_pham().trim();
            String tenHienCo = csp.getTen_san_pham().trim();
            if (TENsp.equalsIgnoreCase(tenHienCo)
                    && !masp.equalsIgnoreCase(csp.getMa_san_pham())) {

                check = false;
                break;
            }
        }

        if (!check) {
            JOptionPane.showMessageDialog(this, "Sản phẩm đã tồn tại");
            return false;
        }

        return true;
    }
public boolean checkTonTai() {
    try {
        String ma = txt_maspct.getText();

        if (ma == null || ma.trim().isEmpty()) {
            return false;
        }
        Sanphamchitiet spct = repoSPCT.IDSPCT(ma.trim());
        return spct != null;
    } catch (Exception ex) {
        ex.printStackTrace();
        return false;
    }
}
public boolean checkTonTaiSP () {
    try {
        String ma = txt_masp.getText();

        if (ma == null || ma.trim().isEmpty()) {
            return false;
        }
        Sanpham sp = repoSP.IDSP(ma.trim());
        return sp != null;
    } catch (Exception ex) {
        ex.printStackTrace();
        return false;
    }
}
public boolean checkTonTaiMS() {
    try {
        String ma = txt_ma_tc.getText();

        if (ma == null || ma.trim().isEmpty()) {
            return false;
        }
        Mausac ms = repoMS.ID(ma.trim());
        return ms != null;
    } catch (Exception ex) {
        ex.printStackTrace();
        return false;
    }
}
public boolean checkTonTaiCL () {
    try {
        String ma = txt_ma_tc.getText();

        if (ma == null || ma.trim().isEmpty()) {
            return false;
        }
        Chatlieu cl = repoCL.ID(ma.trim());
        return cl != null;
    } catch (Exception ex) {
        ex.printStackTrace();
        return false;
    }
}
public boolean checkTonTaiCA() {
    try {
        String ma = txt_ma_tc.getText();

        if (ma == null || ma.trim().isEmpty()) {
            return false;
        }
        Coao ca = repoCA.ID(ma.trim());
        return ca != null;
    } catch (Exception ex) {
        ex.printStackTrace();
        return false;
    }
}
public boolean checkTonTaiSZ () {
    try {
        String ma = txt_ma_tc.getText();

        if (ma == null || ma.trim().isEmpty()) {
            return false;
        }
        Size sz = repoSZ.ID(ma.trim());
        return sz != null;
    } catch (Exception ex) {
        ex.printStackTrace();
        return false;
    }
}
public boolean checkTonTaiTH() {
    try {
        String ma = txt_ma_tc.getText();

        if (ma == null || ma.trim().isEmpty()) {
            return false;
        }
        Thuonghieu th = repoTH.ID(ma.trim());
        return th != null;
    } catch (Exception ex) {
        ex.printStackTrace();
        return false;
    }
}

    public boolean CheckupdateSPCT() {
        Sanphamchitiet spct = repoSPCT.IDSPCTUPDATE(txt_maspct.getText());
        boolean check = true;

        String masp = txt_maspct.getText().trim();
        String TENsp = txt_tensp_spct.getText().trim();

        for (Sanphamchitiet csp : repoSPCT.findAll()) {

            String maHienCo = csp.getMa_san_pham_chi_tiet().trim();
            String tenHienCo = csp.getTen_san_pham().trim();

            // Nếu tên trùng nhưng mã không phải của sản phẩm đang update → lỗi
            if (TENsp.equalsIgnoreCase(tenHienCo)
                    && !masp.equalsIgnoreCase(csp.getMa_san_pham_chi_tiet())) {

                check = false;
                break;
            }
        }

        if (!check) {
            JOptionPane.showMessageDialog(this, "Sản phẩm chi tiết đã tồn tại");
            return false;
        }

        return true;

    }

    public boolean CheckupdateMS() {
        String maMoi = txt_ma_tc.getText().trim();
        String tenMoi = txt_ten_tc.getText().trim();
        String maMoiLower = maMoi.toLowerCase();
        String tenMoiLower = tenMoi.toLowerCase();

        for (Mausac ms : repoMS.findAll()) {

            String maDB = ms.getMa_mau_sac().trim();
            String tenDB = ms.getTen_mau().trim();

            String maDBLower = maDB.toLowerCase();
            String tenDBLower = tenDB.toLowerCase();
            if (tenMoiLower.equals(tenDBLower) && !maMoiLower.equals(maDBLower)) {
                JOptionPane.showMessageDialog(this, "Thuộc tính  đã tồn tại!");
                return false;
            }
        }

        return true; // Không trùng → hợp lệ
    }

    public boolean CheckupdateCL() {
        String maMoi = txt_ma_tc.getText().trim();
        String tenMoi = txt_ten_tc.getText().trim();

        String maMoiLower = maMoi.toLowerCase();
        String tenMoiLower = tenMoi.toLowerCase();

        for (Chatlieu csp : repoCL.findAll()) {
            String maDB = csp.getMa_chat_lieu().trim();
            String tenDB = csp.getTen_chat_lieu().trim();

            String maDBLower = maDB.toLowerCase();
            String tenDBLower = tenDB.toLowerCase();

            if (tenMoiLower.equals(tenDBLower) && !maMoiLower.equals(maDBLower)) {
                JOptionPane.showMessageDialog(this, "Thuộc tính  đã tồn tại!");
                return false;
            }
        }

        return true; // Không trùng → hợp lệ

    }

    public boolean CheckupdateCA() {
        String maMoi = txt_ma_tc.getText().trim();
        String tenMoi = txt_ten_tc.getText().trim();

        String maMoiLower = maMoi.toLowerCase();
        String tenMoiLower = tenMoi.toLowerCase();

        for (Coao csp : repoCA.findAll()) {

            String maDB = csp.getMa_co_ao().trim();
            String tenDB = csp.getTen_co_ao().trim();

            String maDBLower = maDB.toLowerCase();
            String tenDBLower = tenDB.toLowerCase();

            if (tenMoiLower.equals(tenDBLower) && !maMoiLower.equals(maDBLower)) {
                JOptionPane.showMessageDialog(this, "Thuộc tính  đã tồn tại!");
                return false;
            }
        }

        return true; // Không trùng → hợp lệ
    }

    public boolean CheckupdateSZ() {
        String maMoi = txt_ma_tc.getText().trim();
        String tenMoi = txt_ten_tc.getText().trim();

        String maMoiLower = maMoi.toLowerCase();
        String tenMoiLower = tenMoi.toLowerCase();
        for (Size csp : repoSZ.findAll()) {

            String maDB = csp.getMa_size().trim();
            String tenDB = csp.getTen_size().trim();

            String maDBLower = maDB.toLowerCase();
            String tenDBLower = tenDB.toLowerCase();

            if (tenMoiLower.equals(tenDBLower) && !maMoiLower.equals(maDBLower)) {
                JOptionPane.showMessageDialog(this, "Thuộc tính  đã tồn tại!");
                return false;
            }
        }

        return true; // Không trùng → hợp lệ

    }

    public boolean CheckupdateTH() {
        String maMoi = txt_ma_tc.getText().trim();
        String tenMoi = txt_ten_tc.getText().trim();

        // Chuyển về chữ thường để kiểm tra trùng không phân biệt hoa thường
        String maMoiLower = maMoi.toLowerCase();
        String tenMoiLower = tenMoi.toLowerCase();
        for (Thuonghieu csp : repoTH.findAll()) {

            String maDB = csp.getMa_thuong_hieu().trim();
            String tenDB = csp.getTen_thuong_hieu().trim();

            String maDBLower = maDB.toLowerCase();
            String tenDBLower = tenDB.toLowerCase();

            if (tenMoiLower.equals(tenDBLower) && !maMoiLower.equals(maDBLower)) {
                JOptionPane.showMessageDialog(this, "Thuộc tính  đã tồn tại!");
                return false;
            }
        }

        return true; // Không trùng → hợp lệ

    }

    // btn xóa SP ( CHUYỂN TRẠNG THÁI )
    public void xoaSP(String maSP) {
        try {
            Sanpham sp = repoSP.IDSP(maSP);
            if (sp == null) {
                JOptionPane.showMessageDialog(this, "Không tìm thấy Sản phẩm với Mã: " + maSP);
                return;
            }

            int IDSP = sp.getID_san_pham();
            boolean trangThaiMoi = false;
            repoSP.capNhatTrangThai(IDSP, trangThaiMoi);
            JOptionPane.showMessageDialog(this, "Sản phẩm '" + maSP + "' đã được chuyển sang trạng thái KHÔNG HOẠT ĐỘNG.");

        } catch (Exception e) {
            e.printStackTrace();
        }
        this.fillToTableSanpham();
        this.clearSP();
    }
    // btn xóa SPCT ( CHUYỂN TRẠNG THÁI )

    public void xoaSPCT(String maSPCT) {
        try {
            Sanphamchitiet spCT = repoSPCT.IDSPCTUPDATE(maSPCT);
            if (spCT == null) {
                JOptionPane.showMessageDialog(this, "Không tìm thấy Sản phẩm chi tiết với Mã: " + maSPCT);
                return;
            }
            int IDSP = spCT.getID_san_pham_chi_tiet();
            boolean trangThaiMoi = false;
            repoSPCT.capNhatTrangThaiSPCT(IDSP, trangThaiMoi);

            JOptionPane.showMessageDialog(this, "Sản phẩm chi tiết '" + maSPCT + "' đã được chuyển sang trạng thái Ngừng bán.");

        } catch (Exception e) {
            e.printStackTrace();
        }
        String maSanPham = txt_masp_spct.getText();
        this.fillToTablespchitietUDSP(maSanPham);
        this.clearSPCT();
    }
    // btn xóa TT ( CHUYỂN TRẠNG THÁI )

    public void xoaMS(String maMS) {
        try {
            Mausac ms = repoMS.ID(maMS);
            if (ms == null) {
                JOptionPane.showMessageDialog(this, "Không tìm thấy Sản phẩm với Mã: " + maMS);
                return;
            }

            String IDMS = ms.getMa_mau_sac();
            boolean trangThaiMoi = false;
            repoMS.capNhatTrangThai(IDMS, trangThaiMoi);
            JOptionPane.showMessageDialog(this, "Mã Màu Sắc '" + maMS + "' đã được chuyển sang trạng thái KHÔNG HOẠT ĐỘNG.");

        } catch (Exception e) {
            e.printStackTrace();
        }
        this.fillToTableMausac();
        this.clearTT();
    }

    public void xoaCL(String maCL) {
        try {
            Chatlieu cl = repoCL.ID(maCL);
            if (cl == null) {
                JOptionPane.showMessageDialog(this, "Không tìm thấy Sản phẩm với Mã: " + maCL);
                return;
            }

            String IDCL = cl.getMa_chat_lieu();
            boolean trangThaiMoi = false;
            repoCL.capNhatTrangThai(IDCL, trangThaiMoi);
            JOptionPane.showMessageDialog(this, "Mã Màu Sắc '" + maCL + "' đã được chuyển sang trạng thái KHÔNG HOẠT ĐỘNG.");

        } catch (Exception e) {
            e.printStackTrace();
        }
        this.fillToTableChatlieu();
        this.clearTT();
    }

    public void xoaCA(String maCA) {
        try {
            Coao CA = repoCA.ID(maCA);
            if (CA == null) {
                JOptionPane.showMessageDialog(this, "Không tìm thấy Sản phẩm với Mã: " + maCA);
                return;
            }

            String IDCA = CA.getMa_co_ao();
            boolean trangThaiMoi = false;
            repoCA.capNhatTrangThai(IDCA, trangThaiMoi);
            JOptionPane.showMessageDialog(this, "Mã Màu Sắc '" + maCA + "' đã được chuyển sang trạng thái KHÔNG HOẠT ĐỘNG.");

        } catch (Exception e) {
            e.printStackTrace();
        }
        this.fillToTableCoao();
        this.clearTT();
    }

    public void xoaSZ(String maSZ) {
        try {
            Size SZ = repoSZ.ID(maSZ);
            if (SZ == null) {
                JOptionPane.showMessageDialog(this, "Không tìm thấy Sản phẩm với Mã: " + maSZ);
                return;
            }

            String IDSZ = SZ.getMa_size();
            boolean trangThaiMoi = false;
            repoSZ.capNhatTrangThai(IDSZ, trangThaiMoi);
            JOptionPane.showMessageDialog(this, "Mã Màu Sắc '" + maSZ + "' đã được chuyển sang trạng thái KHÔNG HOẠT ĐỘNG.");

        } catch (Exception e) {
            e.printStackTrace();
        }
        this.fillToTableSize();
        this.clearTT();
    }

    public void xoaTH(String maTH) {
        try {
            Thuonghieu TH = repoTH.ID(maTH);
            if (TH == null) {
                JOptionPane.showMessageDialog(this, "Không tìm thấy Sản phẩm với Mã: " + maTH);
                return;
            }

            String IDTH = TH.getMa_thuong_hieu();
            boolean trangThaiMoi = false;
            repoTH.capNhatTrangThai(IDTH, trangThaiMoi);
            JOptionPane.showMessageDialog(this, "Mã Màu Sắc '" + maTH + "' đã được chuyển sang trạng thái KHÔNG HOẠT ĐỘNG.");

        } catch (Exception e) {
            e.printStackTrace();
        }
        this.fillToTableThuonghieu();
        this.clearTT();
    }
    //check trùng thuộc tính

    public boolean ChecktrungThuocTinhMS() {
        String maThuocTinh = txt_ma_tc.getText().trim();
        String tenThuocTinh = txt_ten_tc.getText().trim();

        String tenSP = tenThuocTinh.toLowerCase();
        for (Mausac spct : repoMS.findAll()) {
            String maHienCo = spct.getMa_mau_sac().trim();
            String tenHienCo = spct.getTen_mau().trim();
            boolean maDaTrung = maThuocTinh.equalsIgnoreCase(maHienCo);
            if (maDaTrung) {
                JOptionPane.showMessageDialog(this,
                        "Mã thuộc tính '" + maThuocTinh + "' đã tồn tại!");
                return false;
            }
            String tenHienCoDaChuanHoa = tenHienCo.toLowerCase();
            boolean tenDaTrung = tenSP.equals(tenHienCoDaChuanHoa);

            if (tenDaTrung) {
                JOptionPane.showMessageDialog(this,
                        "Tên thuộc tính '" + tenThuocTinh + "' đã tồn tại!");
                return false;
            }
        }
        return true;
    }
//check trùng thuộc tính

    public boolean ChecktrungThuocTinhTH() {
        String maThuocTinh = txt_ma_tc.getText().trim();
        String tenThuocTinh = txt_ten_tc.getText().trim();
        if (maThuocTinh.isEmpty()) {
            return false;
        }
        String tenMoiDaChuanHoa = tenThuocTinh.toLowerCase();
        for (Thuonghieu spct : repoTH.findAll()) {
            String maHienCo = spct.getMa_thuong_hieu().trim();
            String tenHienCo = spct.getTen_thuong_hieu().trim();
            boolean maDaTrung = maThuocTinh.equalsIgnoreCase(maHienCo);
            if (maDaTrung) {
                JOptionPane.showMessageDialog(this,
                        "Mã thuộc tính '" + maThuocTinh + "' đã tồn tại!");
                return false;
            }
            String tenHienCoDaChuanHoa = tenHienCo.toLowerCase();
            boolean tenDaTrung = tenMoiDaChuanHoa.equals(tenHienCoDaChuanHoa);
            if (tenDaTrung) {
                JOptionPane.showMessageDialog(this,
                        "Tên thuộc tính '" + tenThuocTinh + "' đã tồn tại!");
                return false;
            }
        }
        return true;

    }
//check trùng thuộc tính

    public boolean ChecktrungThuocTinhCA() {
        String maThuocTinh = txt_ma_tc.getText().trim();
        String tenThuocTinh = txt_ten_tc.getText().trim();
        if (maThuocTinh.isEmpty()) {
            return false;
        }
        String tenMoiDaChuanHoa = tenThuocTinh.toLowerCase();
        for (Coao spct : repoCA.findAll()) {
            String maHienCo = spct.getMa_co_ao().trim();
            String tenHienCo = spct.getTen_co_ao().trim();
            boolean maDaTrung = maThuocTinh.equalsIgnoreCase(maHienCo);

            if (maDaTrung) {
                JOptionPane.showMessageDialog(this,
                        "Mã thuộc tính '" + maThuocTinh + "' đã tồn tại!");
                return false;
            }
            String tenHienCoDaChuanHoa = tenHienCo.toLowerCase();
            boolean tenDaTrung = tenMoiDaChuanHoa.equals(tenHienCoDaChuanHoa);

            if (tenDaTrung) {
                JOptionPane.showMessageDialog(this,
                        "Tên thuộc tính '" + tenThuocTinh + "' đã tồn tại!");
                return false;
            }
        }
        return true;

    }
//check trùng thuộc tính

    public boolean ChecktrungThuocTinhSZ() {
        String maThuocTinh = txt_ma_tc.getText().trim();
        String tenThuocTinh = txt_ten_tc.getText().trim();
        if (maThuocTinh.isEmpty()) {
            return false;
        }
        String tenMoiDaChuanHoa = tenThuocTinh.toLowerCase();
        for (Size spct : repoSZ.findAll()) {
            String maHienCo = spct.getMa_size().trim();
            String tenHienCo = spct.getTen_size().trim();
            boolean maDaTrung = maThuocTinh.equalsIgnoreCase(maHienCo);
            if (maDaTrung) {
                JOptionPane.showMessageDialog(this,
                        "Mã thuộc tính '" + maThuocTinh + "' đã tồn tại!");
                return false;
            }
            String tenHienCoDaChuanHoa = tenHienCo.toLowerCase();
            boolean tenDaTrung = tenMoiDaChuanHoa.equals(tenHienCoDaChuanHoa);
            if (tenDaTrung) {
                JOptionPane.showMessageDialog(this,
                        "Tên thuộc tính '" + tenThuocTinh + "' đã tồn tại!");
                return false;
            }
        }
        return true;

    }
//check trùng thuộc tính

    public boolean ChecktrungThuocTinhCL() {
        String maThuocTinh = txt_ma_tc.getText().trim();
        String tenThuocTinh = txt_ten_tc.getText().trim();
        if (maThuocTinh.isEmpty()) {
            return false;
        }
        String tenMoiDaChuanHoa = tenThuocTinh.toLowerCase();
        for (Chatlieu spct : repoCL.findAll()) {
            String maHienCo = spct.getMa_chat_lieu().trim();
            String tenHienCo = spct.getTen_chat_lieu().trim();
            boolean maDaTrung = maThuocTinh.equalsIgnoreCase(maHienCo);
            if (maDaTrung) {
                JOptionPane.showMessageDialog(this,
                        "Mã thuộc tính '" + maThuocTinh + "' đã tồn tại!");
                return false;
            }
            String tenHienCoDaChuanHoa = tenHienCo.toLowerCase();
            boolean tenDaTrung = tenMoiDaChuanHoa.equals(tenHienCoDaChuanHoa);

            if (tenDaTrung) {
                JOptionPane.showMessageDialog(this,
                        "Tên thuộc tính '" + tenThuocTinh + "' đã tồn tại!");
                return false;
            }
        }

        return true;  // Không trùng, cho phép thêm
    }

    //check trùng thuộc tính chung 5 rdo
    public boolean ChecktrungThuocTinh() {
        if (rdo_mausac_tc.isSelected()) {
            return ChecktrungThuocTinhMS();
        } else if (rdo_chatlieu_tc.isSelected()) {
            return ChecktrungThuocTinhCL();
        } else if (rdo_size_tc.isSelected()) {
            return ChecktrungThuocTinhSZ();
        } else if (rdo_thuonghieu_tc.isSelected()) {
            return ChecktrungThuocTinhTH();
        } else if (rdo_coao_tc.isSelected()) {
            return ChecktrungThuocTinhCA();
        }
        return false;
    }
     public boolean ChecktontaiThuocTinh() {
        if (rdo_mausac_tc.isSelected()) {
            return checkTonTaiMS();
        } else if (rdo_chatlieu_tc.isSelected()) {
            return checkTonTaiCL();
        } else if (rdo_size_tc.isSelected()) {
            return checkTonTaiSZ();
        } else if (rdo_thuonghieu_tc.isSelected()) {
            return checkTonTaiTH();
        } else if (rdo_coao_tc.isSelected()) {
            return checkTonTaiCA();
        }
        return false;
    }

    public boolean ChecktrungThuocTinhUDTT() {
        if (rdo_mausac_tc.isSelected()) {
            return CheckupdateMS();
        } else if (rdo_chatlieu_tc.isSelected()) {
            return CheckupdateCL();
        } else if (rdo_size_tc.isSelected()) {
            return CheckupdateSZ();
        } else if (rdo_thuonghieu_tc.isSelected()) {
            return CheckupdateTH();
        } else if (rdo_coao_tc.isSelected()) {
            return CheckupdateCA();
        }
        return false;
    }

    public String thuoctinhxoa() {
        if (rdo_mausac_tc.isSelected()) {
            return "Mausac";
        }
        if (rdo_coao_tc.isSelected()) {
            return "Coao";
        }
        if (rdo_size_tc.isSelected()) {
            return "Size";
        }
        if (rdo_thuonghieu_tc.isSelected()) {
            return "Thuonghieu";
        }
        if (rdo_chatlieu_tc.isSelected()) {
            return "Chatlieu";
        }
        return " ";
    }

    public void hienthilabel() {
        // phần này là để làm tang defaultPadding cho lbl(Không chỉnh sửa nhé)
        // Đảm bảo label trong suốt
        lblsanpham.setBackground(null);
        lblsanpham.setOpaque(false);

        lblbanhang.setBackground(null);
        lblbanhang.setOpaque(false);

        lblgiamgia.setBackground(null);
        lblgiamgia.setOpaque(false);


        lblquanlykhachhang.setBackground(null);
        lblquanlykhachhang.setOpaque(false);

        lbldangnhap.setBackground(null);
        lbldangnhap.setOpaque(false);

        lbldangxuat.setBackground(null);
        lbldangxuat.setOpaque(false);
        // Padding Gốc (Lùi sâu vào 25px): Kích thước cố định.
        javax.swing.border.Border defaultPadding = javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10);
        lblsanpham.setBorder(defaultPadding);
        lblbanhang.setBorder(defaultPadding);
        lblgiamgia.setBorder(defaultPadding);
        lblquanlykhachhang.setBorder(defaultPadding);
        lbldangnhap.setBorder(defaultPadding);
        lbldangxuat.setBorder(defaultPadding);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rdo_gr_trangthai = new javax.swing.ButtonGroup();
        rdo_gr_trang_thai = new javax.swing.ButtonGroup();
        rdo_gr_thuoc_tinh = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        lblquanlykhachhang = new javax.swing.JLabel();
        lblsanpham = new javax.swing.JLabel();
        lbldangnhap = new javax.swing.JLabel();
        lblbanhang = new javax.swing.JLabel();
        lblgiamgia = new javax.swing.JLabel();
        lbldangxuat = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jTabbedPane1 = new javax.swing.JTabbedPane();
        jPanel6 = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jLabel19 = new javax.swing.JLabel();
        jLabel20 = new javax.swing.JLabel();
        txt_masp = new javax.swing.JTextField();
        txt_tensp = new javax.swing.JTextField();
        jLabel21 = new javax.swing.JLabel();
        jScrollPane3 = new javax.swing.JScrollPane();
        txt_motasp = new javax.swing.JTextArea();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        jLabel24 = new javax.swing.JLabel();
        jLabel25 = new javax.swing.JLabel();
        cbo_thuonghieu_sp = new javax.swing.JComboBox<>();
        cbo_chatlieu_sp = new javax.swing.JComboBox<>();
        cbo_coao_spp = new javax.swing.JComboBox<>();
        btn_them = new javax.swing.JButton();
        btn_chinhsua = new javax.swing.JButton();
        btn_lammoi = new javax.swing.JButton();
        cbo_trangthai_sp = new javax.swing.JComboBox<>();
        btn_taoma = new javax.swing.JButton();
        btn_xoa = new javax.swing.JButton();
        jPanel10 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_sanpham = new javax.swing.JTable();
        jLabel26 = new javax.swing.JLabel();
        btn_ma_sp_timkiem = new javax.swing.JTextField();
        jLabel30 = new javax.swing.JLabel();
        jLabel4 = new javax.swing.JLabel();
        cbo_thuonghieu_sp_timkiem = new javax.swing.JComboBox<>();
        cbo_trangthai_sp_timkiem = new javax.swing.JComboBox<>();
        btn_timkiem = new javax.swing.JButton();
        btn_lammoi1 = new javax.swing.JButton();
        jPanel5 = new javax.swing.JPanel();
        jPanel7 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txt_maspct = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txt_masp_spct = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        rdo_dangban_spct = new javax.swing.JRadioButton();
        rdo_ngungban_spct = new javax.swing.JRadioButton();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txt_dongia = new javax.swing.JTextField();
        txt_soluong = new javax.swing.JTextField();
        cbo_size_spct = new javax.swing.JComboBox<>();
        jLabel8 = new javax.swing.JLabel();
        jLabel9 = new javax.swing.JLabel();
        cbo_mausac_spct = new javax.swing.JComboBox<>();
        btn_themspct = new javax.swing.JButton();
        btn_chinhsuaspct = new javax.swing.JButton();
        btn_lammoispct = new javax.swing.JButton();
        btn_taomaspct = new javax.swing.JButton();
        btn_xoa_spct = new javax.swing.JButton();
        txt_tensp_spct = new javax.swing.JTextField();
        jLabel27 = new javax.swing.JLabel();
        jPanel8 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_spct = new javax.swing.JTable();
        jLabel13 = new javax.swing.JLabel();
        txt_maspcttimkiem = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        cbo_chatlieuspct_tim_kiem = new javax.swing.JComboBox<>();
        jLabel15 = new javax.swing.JLabel();
        cbo_thuonghieuspct_tim_kiem = new javax.swing.JComboBox<>();
        jLabel16 = new javax.swing.JLabel();
        cbo_coaospct_tim_kiem = new javax.swing.JComboBox<>();
        jLabel17 = new javax.swing.JLabel();
        cbo_mausacspct_tim_kiem = new javax.swing.JComboBox<>();
        jLabel18 = new javax.swing.JLabel();
        cbo_sizespct_tim_kiem = new javax.swing.JComboBox<>();
        btn_timkiem1 = new javax.swing.JButton();
        btn_lammoi2 = new javax.swing.JButton();
        btn_fullds = new javax.swing.JButton();
        jPanel11 = new javax.swing.JPanel();
        jPanel12 = new javax.swing.JPanel();
        jLabel10 = new javax.swing.JLabel();
        txt_ten_tc = new javax.swing.JTextField();
        rdo_chatlieu_tc = new javax.swing.JRadioButton();
        rdo_mausac_tc = new javax.swing.JRadioButton();
        rdo_size_tc = new javax.swing.JRadioButton();
        rdo_thuonghieu_tc = new javax.swing.JRadioButton();
        rdo_coao_tc = new javax.swing.JRadioButton();
        btn_themtc = new javax.swing.JButton();
        btn_chinhsuatc = new javax.swing.JButton();
        jLabel11 = new javax.swing.JLabel();
        txt_ma_tc = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        rdo_hoatdong_tc = new javax.swing.JRadioButton();
        rdo_khonghoatdong_tc = new javax.swing.JRadioButton();
        btn_taomatc = new javax.swing.JButton();
        btn_xoa_tc = new javax.swing.JButton();
        btn_lammoi_tc = new javax.swing.JButton();
        jPanel13 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbl_thuoctinh = new javax.swing.JTable();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(19, 0, 160));

        lblquanlykhachhang.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblquanlykhachhang.setForeground(new java.awt.Color(255, 255, 255));
        lblquanlykhachhang.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\KhachHang.png")); // NOI18N
        lblquanlykhachhang.setText("Quản lý khách hàng");
        lblquanlykhachhang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblquanlykhachhangMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblquanlykhachhangMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblquanlykhachhangMouseExited(evt);
            }
        });

        lblsanpham.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblsanpham.setForeground(new java.awt.Color(255, 255, 255));
        lblsanpham.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\quanlisanpham.png")); // NOI18N
        lblsanpham.setText("Quản lý sản phẩm");
        lblsanpham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblsanphamMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblsanphamMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblsanphamMouseExited(evt);
            }
        });

        lbldangnhap.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbldangnhap.setForeground(new java.awt.Color(255, 255, 255));
        lbldangnhap.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\dangnhap.png")); // NOI18N
        lbldangnhap.setText("Đăng nhập");
        lbldangnhap.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbldangnhapMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbldangnhapMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbldangnhapMouseExited(evt);
            }
        });

        lblbanhang.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblbanhang.setForeground(new java.awt.Color(255, 255, 255));
        lblbanhang.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\banhang.png")); // NOI18N
        lblbanhang.setText("Quản lý bán hàng");
        lblbanhang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblbanhangMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblbanhangMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblbanhangMouseExited(evt);
            }
        });

        lblgiamgia.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblgiamgia.setForeground(new java.awt.Color(255, 255, 255));
        lblgiamgia.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\giamgia.png")); // NOI18N
        lblgiamgia.setText("Giảm giá");
        lblgiamgia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblgiamgiaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblgiamgiaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblgiamgiaMouseExited(evt);
            }
        });

        lbldangxuat.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbldangxuat.setForeground(new java.awt.Color(255, 255, 255));
        lbldangxuat.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\dangxuat.png")); // NOI18N
        lbldangxuat.setText("Đăng xuất");
        lbldangxuat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbldangxuatMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbldangxuatMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbldangxuatMouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblsanpham, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblbanhang, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblgiamgia, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblquanlykhachhang, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
                    .addComponent(lbldangnhap, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbldangxuat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(48, 48, 48)
                .addComponent(lblsanpham, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblbanhang, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblgiamgia, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblquanlykhachhang, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbldangnhap, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbldangxuat, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(434, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 100, 190, 800);

        jPanel4.setBackground(new java.awt.Color(19, 0, 160));
        jPanel4.setPreferredSize(new java.awt.Dimension(1455, 143));

        jLabel1.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\LOGO(TO).png")); // NOI18N
        jLabel1.setText("jLabel1");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1511, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel4);
        jPanel4.setBounds(0, 0, 1500, 100);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setPreferredSize(new java.awt.Dimension(1300, 820));

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));
        jPanel9.setBorder(javax.swing.BorderFactory.createTitledBorder("Thêm sản phẩm"));

        jLabel19.setText("Mã sản phẩm:");

        jLabel20.setText("Tên sản phẩm:");

        jLabel21.setText("Mô tả sản phẩm:");

        txt_motasp.setColumns(20);
        txt_motasp.setRows(5);
        jScrollPane3.setViewportView(txt_motasp);

        jLabel22.setText("Thương hiệu:");

        jLabel23.setText("Chất liệu:");

        jLabel24.setText("Cổ áo:");

        jLabel25.setText("Trạng thái:");

        cbo_thuonghieu_sp.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cbo_chatlieu_sp.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cbo_coao_spp.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btn_them.setBackground(new java.awt.Color(19, 0, 194));
        btn_them.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_them.setForeground(new java.awt.Color(255, 255, 255));
        btn_them.setText("Thêm ");
        btn_them.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_themActionPerformed(evt);
            }
        });

        btn_chinhsua.setBackground(new java.awt.Color(19, 0, 194));
        btn_chinhsua.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_chinhsua.setForeground(new java.awt.Color(255, 255, 255));
        btn_chinhsua.setText("Chỉnh sửa");
        btn_chinhsua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_chinhsuaActionPerformed(evt);
            }
        });

        btn_lammoi.setBackground(new java.awt.Color(19, 0, 194));
        btn_lammoi.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_lammoi.setForeground(new java.awt.Color(255, 255, 255));
        btn_lammoi.setText("Làm mới");
        btn_lammoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_lammoiActionPerformed(evt);
            }
        });

        cbo_trangthai_sp.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btn_taoma.setBackground(new java.awt.Color(19, 0, 194));
        btn_taoma.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_taoma.setForeground(new java.awt.Color(255, 255, 255));
        btn_taoma.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\Taomoi.png")); // NOI18N
        btn_taoma.setText("TẠO MA");
        btn_taoma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_taomaActionPerformed(evt);
            }
        });

        btn_xoa.setBackground(new java.awt.Color(19, 0, 194));
        btn_xoa.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_xoa.setForeground(new java.awt.Color(255, 255, 255));
        btn_xoa.setText("Xóa");
        btn_xoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_xoaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(41, 41, 41)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                        .addGroup(jPanel9Layout.createSequentialGroup()
                            .addComponent(jLabel21)
                            .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                            .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE))
                        .addGroup(jPanel9Layout.createSequentialGroup()
                            .addComponent(jLabel19)
                            .addGap(18, 18, 18)
                            .addComponent(txt_masp, javax.swing.GroupLayout.PREFERRED_SIZE, 205, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGroup(jPanel9Layout.createSequentialGroup()
                            .addComponent(jLabel20)
                            .addGap(18, 18, 18)
                            .addComponent(txt_tensp)))
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(btn_them)
                        .addGap(18, 18, 18)
                        .addComponent(btn_chinhsua)
                        .addGap(30, 30, 30)
                        .addComponent(btn_xoa)))
                .addGap(27, 27, 27)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(btn_taoma)
                        .addGap(202, 202, 202)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel23)
                            .addComponent(jLabel22)
                            .addComponent(jLabel24)
                            .addComponent(jLabel25))
                        .addGap(35, 35, 35)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(cbo_thuonghieu_sp, 0, 212, Short.MAX_VALUE)
                            .addComponent(cbo_chatlieu_sp, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbo_coao_spp, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(cbo_trangthai_sp, 0, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
                    .addComponent(btn_lammoi))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel19)
                    .addComponent(txt_masp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel22)
                    .addComponent(cbo_thuonghieu_sp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_taoma))
                .addGap(18, 18, 18)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(txt_tensp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel23)
                    .addComponent(cbo_chatlieu_sp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jLabel21)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 59, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel24)
                            .addComponent(cbo_coao_spp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel25)
                            .addComponent(cbo_trangthai_sp, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 70, Short.MAX_VALUE)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_them)
                    .addComponent(btn_chinhsua)
                    .addComponent(btn_xoa)
                    .addComponent(btn_lammoi))
                .addGap(35, 35, 35))
        );

        jPanel10.setBackground(new java.awt.Color(255, 255, 255));
        jPanel10.setBorder(javax.swing.BorderFactory.createTitledBorder("Danh sách sản phẩm"));

        tbl_sanpham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã sản phẩm", "Tên sản phẩm", "Thương hiệu", "Chất liệu", "Cổ áo", "Số lượng", "Trạng thái"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_sanpham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_sanphamMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_sanpham);

        jLabel26.setText("Mã sản phẩm | Tên sản phẩm:");

        jLabel30.setText("Trạng thái:");

        jLabel4.setText("Thương hiệu:");

        cbo_thuonghieu_sp_timkiem.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        cbo_trangthai_sp_timkiem.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btn_timkiem.setBackground(new java.awt.Color(19, 0, 194));
        btn_timkiem.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_timkiem.setForeground(new java.awt.Color(255, 255, 255));
        btn_timkiem.setText("Tìm kiếm");
        btn_timkiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_timkiemActionPerformed(evt);
            }
        });

        btn_lammoi1.setBackground(new java.awt.Color(19, 0, 194));
        btn_lammoi1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_lammoi1.setForeground(new java.awt.Color(255, 255, 255));
        btn_lammoi1.setText("Làm mới");
        btn_lammoi1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_lammoi1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel10Layout = new javax.swing.GroupLayout(jPanel10);
        jPanel10.setLayout(jPanel10Layout);
        jPanel10Layout.setHorizontalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel10Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1182, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel10Layout.createSequentialGroup()
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel26)
                            .addComponent(jLabel30))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(btn_ma_sp_timkiem)
                            .addComponent(cbo_trangthai_sp_timkiem, 0, 160, Short.MAX_VALUE))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(jLabel4)
                                .addGap(34, 34, 34)
                                .addComponent(cbo_thuonghieu_sp_timkiem, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel10Layout.createSequentialGroup()
                                .addComponent(btn_timkiem)
                                .addGap(27, 27, 27)
                                .addComponent(btn_lammoi1)))))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel10Layout.setVerticalGroup(
            jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel10Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel26)
                    .addComponent(btn_ma_sp_timkiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_timkiem)
                    .addComponent(btn_lammoi1))
                .addGap(18, 18, 18)
                .addGroup(jPanel10Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel30)
                    .addComponent(jLabel4)
                    .addComponent(cbo_trangthai_sp_timkiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbo_thuonghieu_sp_timkiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 230, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(36, 36, 36))
        );

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel10, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 16, Short.MAX_VALUE)
                .addComponent(jPanel10, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );

        jTabbedPane1.addTab("Sản phẩm", jPanel6);

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Thêm sản phẩm chi tiết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jLabel2.setText("Mã sản phẩm CT:");

        jLabel3.setText("Mã sản phẩm:");

        txt_masp_spct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_masp_spctActionPerformed(evt);
            }
        });

        jLabel5.setText("Trạng thái:");

        rdo_gr_trangthai.add(rdo_dangban_spct);
        rdo_dangban_spct.setText("Đang bán");

        rdo_gr_trangthai.add(rdo_ngungban_spct);
        rdo_ngungban_spct.setText("Ngừng bán");
        rdo_ngungban_spct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdo_ngungban_spctActionPerformed(evt);
            }
        });

        jLabel6.setText("Đơn giá:");

        jLabel7.setText("Số lượng:");

        cbo_size_spct.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel8.setText("Size:");

        jLabel9.setText("Màu sắc:");

        cbo_mausac_spct.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btn_themspct.setBackground(new java.awt.Color(19, 0, 194));
        btn_themspct.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_themspct.setForeground(new java.awt.Color(255, 255, 255));
        btn_themspct.setText("Thêm");
        btn_themspct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_themspctActionPerformed(evt);
            }
        });

        btn_chinhsuaspct.setBackground(new java.awt.Color(19, 0, 194));
        btn_chinhsuaspct.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_chinhsuaspct.setForeground(new java.awt.Color(255, 255, 255));
        btn_chinhsuaspct.setText("Chỉnh sửa");
        btn_chinhsuaspct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_chinhsuaspctActionPerformed(evt);
            }
        });

        btn_lammoispct.setBackground(new java.awt.Color(19, 0, 194));
        btn_lammoispct.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_lammoispct.setForeground(new java.awt.Color(255, 255, 255));
        btn_lammoispct.setText("Làm mới");
        btn_lammoispct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_lammoispctActionPerformed(evt);
            }
        });

        btn_taomaspct.setBackground(new java.awt.Color(19, 0, 194));
        btn_taomaspct.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_taomaspct.setForeground(new java.awt.Color(255, 255, 255));
        btn_taomaspct.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\Taomoi.png")); // NOI18N
        btn_taomaspct.setText("TẠO MA");
        btn_taomaspct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_taomaspctActionPerformed(evt);
            }
        });

        btn_xoa_spct.setBackground(new java.awt.Color(19, 0, 194));
        btn_xoa_spct.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_xoa_spct.setForeground(new java.awt.Color(255, 255, 255));
        btn_xoa_spct.setText("Xóa");
        btn_xoa_spct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_xoa_spctActionPerformed(evt);
            }
        });

        txt_tensp_spct.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_tensp_spctActionPerformed(evt);
            }
        });

        jLabel27.setText("Tên sản phẩm:");

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(jLabel2, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                            .addComponent(jLabel3)
                            .addComponent(jLabel5, javax.swing.GroupLayout.PREFERRED_SIZE, 62, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(btn_themspct)
                            .addComponent(jLabel27, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel7Layout.createSequentialGroup()
                                        .addComponent(rdo_dangban_spct, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addGap(58, 58, 58)
                                        .addComponent(rdo_ngungban_spct, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel7Layout.createSequentialGroup()
                                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                            .addComponent(txt_maspct, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, 283, Short.MAX_VALUE)
                                            .addComponent(txt_masp_spct, javax.swing.GroupLayout.Alignment.LEADING)
                                            .addComponent(txt_tensp_spct, javax.swing.GroupLayout.Alignment.LEADING))
                                        .addGap(18, 18, 18)
                                        .addComponent(btn_taomaspct))))
                            .addGroup(jPanel7Layout.createSequentialGroup()
                                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel7Layout.createSequentialGroup()
                                        .addGap(26, 26, 26)
                                        .addComponent(btn_chinhsuaspct))
                                    .addGroup(jPanel7Layout.createSequentialGroup()
                                        .addGap(155, 155, 155)
                                        .addComponent(btn_xoa_spct)))
                                .addGap(41, 41, 41)
                                .addComponent(btn_lammoispct)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel8)
                            .addComponent(jLabel6)
                            .addComponent(jLabel9))
                        .addGap(27, 27, 27))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(616, 616, 616)
                        .addComponent(jLabel7)
                        .addGap(23, 23, 23)))
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(cbo_size_spct, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_soluong, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_dongia, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(cbo_mausac_spct, javax.swing.GroupLayout.PREFERRED_SIZE, 321, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(396, 396, 396))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(8, 8, 8)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_maspct, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_dongia, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(btn_taomaspct))
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel7)
                            .addComponent(txt_soluong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(11, 11, 11)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(cbo_size_spct, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel8)))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(32, 32, 32)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(jLabel3)
                            .addComponent(txt_masp_spct, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))))
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(jLabel9)
                            .addComponent(cbo_mausac_spct, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addGap(53, 53, 53))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addGap(7, 7, 7)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(txt_tensp_spct, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addComponent(jLabel27))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(rdo_ngungban_spct)
                            .addComponent(rdo_dangban_spct)
                            .addComponent(jLabel5))
                        .addGap(34, 34, 34)))
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_themspct)
                    .addComponent(btn_chinhsuaspct)
                    .addComponent(btn_xoa_spct)
                    .addComponent(btn_lammoispct))
                .addContainerGap(67, Short.MAX_VALUE))
        );

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Danh sách sản phẩm chi tiết", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        tbl_spct.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã sản phẩm", "Mã Sản phẩm chi tiết", "Tên sản phẩm", "Cổ áo", "Thương hiệu", "Chất liệu", "Màu sắc", "Size", "Số lượng", "Đơn giá", "Trạng thái"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_spct.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_spctMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbl_spct);

        jLabel13.setText("Mã sản phẩm CT | Tên sản phẩm :");

        jLabel14.setText("Chất liệu:");

        cbo_chatlieuspct_tim_kiem.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel15.setText("Thương hiệu:");

        cbo_thuonghieuspct_tim_kiem.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel16.setText("Cổ áo:");

        cbo_coaospct_tim_kiem.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel17.setText("Màu sắc:");

        cbo_mausacspct_tim_kiem.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel18.setText("Size");

        cbo_sizespct_tim_kiem.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        btn_timkiem1.setBackground(new java.awt.Color(19, 0, 194));
        btn_timkiem1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_timkiem1.setForeground(new java.awt.Color(255, 255, 255));
        btn_timkiem1.setText("Tìm kiếm");
        btn_timkiem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_timkiem1ActionPerformed(evt);
            }
        });

        btn_lammoi2.setBackground(new java.awt.Color(19, 0, 194));
        btn_lammoi2.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_lammoi2.setForeground(new java.awt.Color(255, 255, 255));
        btn_lammoi2.setText("Làm mới");
        btn_lammoi2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_lammoi2ActionPerformed(evt);
            }
        });

        btn_fullds.setBackground(new java.awt.Color(19, 0, 194));
        btn_fullds.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_fullds.setForeground(new java.awt.Color(255, 255, 255));
        btn_fullds.setText("Xem danh sách");
        btn_fullds.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_fulldsActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel14)
                                .addGap(47, 47, 47)
                                .addComponent(cbo_chatlieuspct_tim_kiem, javax.swing.GroupLayout.PREFERRED_SIZE, 119, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(jLabel15)
                                .addGap(18, 18, 18)
                                .addComponent(cbo_thuonghieuspct_tim_kiem, javax.swing.GroupLayout.PREFERRED_SIZE, 110, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel13)
                                .addGap(26, 26, 26)
                                .addComponent(txt_maspcttimkiem, javax.swing.GroupLayout.PREFERRED_SIZE, 225, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(jLabel16)
                                .addGap(18, 18, 18)
                                .addComponent(cbo_coaospct_tim_kiem, javax.swing.GroupLayout.PREFERRED_SIZE, 111, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addComponent(btn_timkiem1)
                                .addGap(18, 18, 18)
                                .addComponent(btn_fullds)))
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGap(37, 37, 37)
                                .addComponent(cbo_mausacspct_tim_kiem, javax.swing.GroupLayout.PREFERRED_SIZE, 112, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(jLabel18, javax.swing.GroupLayout.PREFERRED_SIZE, 54, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(cbo_sizespct_tim_kiem, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGap(29, 29, 29)
                                .addComponent(btn_lammoi2)))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel8Layout.createSequentialGroup()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(txt_maspcttimkiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_timkiem1)
                    .addComponent(btn_lammoi2)
                    .addComponent(btn_fullds))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(jLabel14)
                        .addComponent(jLabel15)
                        .addComponent(cbo_thuonghieuspct_tim_kiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel16)
                        .addComponent(cbo_coaospct_tim_kiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel17)
                        .addComponent(cbo_mausacspct_tim_kiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel18)
                        .addComponent(cbo_sizespct_tim_kiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(cbo_chatlieuspct_tim_kiem, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 220, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(54, 54, 54))
        );

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, 1211, Short.MAX_VALUE)
                    .addComponent(jPanel8, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(9, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, 330, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(27, Short.MAX_VALUE))
        );

        jPanel7.getAccessibleContext().setAccessibleName("Thêm sản phẩm chi tiết ");

        jTabbedPane1.addTab("Sản phẩm chi tiết", jPanel5);

        jPanel11.setBackground(new java.awt.Color(255, 255, 255));

        jPanel12.setBackground(new java.awt.Color(255, 255, 255));
        jPanel12.setBorder(javax.swing.BorderFactory.createTitledBorder("Thêm thuộc tính"));

        jLabel10.setText("Tên thuộc tính:");

        rdo_gr_thuoc_tinh.add(rdo_chatlieu_tc);
        rdo_chatlieu_tc.setText("Chất liệu");
        rdo_chatlieu_tc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rdo_chatlieu_tcMouseClicked(evt);
            }
        });

        rdo_gr_thuoc_tinh.add(rdo_mausac_tc);
        rdo_mausac_tc.setText("Màu sắc");
        rdo_mausac_tc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rdo_mausac_tcMouseClicked(evt);
            }
        });

        rdo_gr_thuoc_tinh.add(rdo_size_tc);
        rdo_size_tc.setText("size");
        rdo_size_tc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rdo_size_tcMouseClicked(evt);
            }
        });

        rdo_gr_thuoc_tinh.add(rdo_thuonghieu_tc);
        rdo_thuonghieu_tc.setText("Thương hiệu");
        rdo_thuonghieu_tc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rdo_thuonghieu_tcMouseClicked(evt);
            }
        });
        rdo_thuonghieu_tc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdo_thuonghieu_tcActionPerformed(evt);
            }
        });

        rdo_gr_thuoc_tinh.add(rdo_coao_tc);
        rdo_coao_tc.setText("Cổ áo");
        rdo_coao_tc.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rdo_coao_tcMouseClicked(evt);
            }
        });

        btn_themtc.setBackground(new java.awt.Color(19, 0, 194));
        btn_themtc.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_themtc.setForeground(new java.awt.Color(255, 255, 255));
        btn_themtc.setText("Thêm");
        btn_themtc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_themtcActionPerformed(evt);
            }
        });

        btn_chinhsuatc.setBackground(new java.awt.Color(19, 0, 194));
        btn_chinhsuatc.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_chinhsuatc.setForeground(new java.awt.Color(255, 255, 255));
        btn_chinhsuatc.setText("Chỉnh sửa");
        btn_chinhsuatc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_chinhsuatcActionPerformed(evt);
            }
        });

        jLabel11.setText("Mã thuộc tính:");

        jLabel12.setText("Trạng thái:");

        rdo_gr_trang_thai.add(rdo_hoatdong_tc);
        rdo_hoatdong_tc.setText("Hoạt động");

        rdo_gr_trang_thai.add(rdo_khonghoatdong_tc);
        rdo_khonghoatdong_tc.setText("Không hoạt động");

        btn_taomatc.setBackground(new java.awt.Color(19, 0, 194));
        btn_taomatc.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_taomatc.setForeground(new java.awt.Color(255, 255, 255));
        btn_taomatc.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\Taomoi.png")); // NOI18N
        btn_taomatc.setText("TẠO MA");
        btn_taomatc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_taomatcActionPerformed(evt);
            }
        });

        btn_xoa_tc.setBackground(new java.awt.Color(19, 0, 194));
        btn_xoa_tc.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_xoa_tc.setForeground(new java.awt.Color(255, 255, 255));
        btn_xoa_tc.setText("Xóa");
        btn_xoa_tc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_xoa_tcActionPerformed(evt);
            }
        });

        btn_lammoi_tc.setBackground(new java.awt.Color(19, 0, 194));
        btn_lammoi_tc.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_lammoi_tc.setForeground(new java.awt.Color(255, 255, 255));
        btn_lammoi_tc.setText("Làm mới");
        btn_lammoi_tc.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_lammoi_tcActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(25, 25, 25)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(btn_themtc)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel10)
                            .addComponent(jLabel11)
                            .addComponent(jLabel12, javax.swing.GroupLayout.Alignment.TRAILING))
                        .addGap(40, 40, 40)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txt_ten_tc, javax.swing.GroupLayout.DEFAULT_SIZE, 348, Short.MAX_VALUE)
                            .addComponent(txt_ma_tc, javax.swing.GroupLayout.DEFAULT_SIZE, 348, Short.MAX_VALUE)
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addComponent(rdo_hoatdong_tc, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(50, 50, 50)
                                .addComponent(rdo_khonghoatdong_tc)))))
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(18, 18, 18)
                        .addComponent(btn_taomatc)
                        .addGap(14, 14, 14)
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addComponent(rdo_mausac_tc, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(18, 18, 18)
                                .addComponent(rdo_thuonghieu_tc, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(btn_chinhsuatc)
                                    .addComponent(rdo_chatlieu_tc, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(jPanel12Layout.createSequentialGroup()
                                        .addGap(18, 18, 18)
                                        .addComponent(rdo_size_tc, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                        .addComponent(rdo_coao_tc, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addGroup(jPanel12Layout.createSequentialGroup()
                                        .addGap(37, 37, 37)
                                        .addComponent(btn_lammoi_tc))))))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(38, 38, 38)
                        .addComponent(btn_xoa_tc)))
                .addContainerGap(264, Short.MAX_VALUE))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(14, 14, 14)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txt_ma_tc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rdo_mausac_tc)
                    .addComponent(rdo_thuonghieu_tc)
                    .addComponent(btn_taomatc, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txt_ten_tc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(rdo_chatlieu_tc)
                    .addComponent(rdo_size_tc)
                    .addComponent(rdo_coao_tc))
                .addGap(19, 19, 19)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(rdo_hoatdong_tc)
                    .addComponent(rdo_khonghoatdong_tc))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 32, Short.MAX_VALUE)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_chinhsuatc)
                    .addComponent(btn_themtc)
                    .addComponent(btn_xoa_tc)
                    .addComponent(btn_lammoi_tc))
                .addGap(48, 48, 48))
        );

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));
        jPanel13.setBorder(javax.swing.BorderFactory.createTitledBorder("Danh sách thuộc tính"));

        tbl_thuoctinh.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null},
                {null, null, null},
                {null, null, null},
                {null, null, null}
            },
            new String [] {
                "Mã thuộc tính", "Tên thuộc tính", "Trạng thái"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_thuoctinh.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_thuoctinhMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tbl_thuoctinh);

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 1194, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(21, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(18, 18, 18)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 295, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(19, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel12, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel13, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(24, 24, 24)
                .addComponent(jPanel12, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(43, 43, 43)
                .addComponent(jPanel13, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(44, Short.MAX_VALUE))
        );

        jTabbedPane1.addTab("Thuộc tính", jPanel11);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(194, Short.MAX_VALUE)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1243, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(63, 63, 63))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel3Layout.createSequentialGroup()
                .addContainerGap(121, Short.MAX_VALUE)
                .addComponent(jTabbedPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 750, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(29, 29, 29))
        );

        jPanel1.add(jPanel3);
        jPanel3.setBounds(0, 0, 1500, 900);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1455, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 875, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblsanphamMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblsanphamMouseEntered
        // TODO add your handling code here:
        lblsanpham.setBackground(new java.awt.Color(70, 130, 180));
        lblsanpham.setOpaque(true);
        lblsanpham.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblsanphamMouseEntered

    private void lblsanphamMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblsanphamMouseExited
        // TODO add your handling code here:
        lblsanpham.setBackground(null);
        lblsanpham.setOpaque(false);
    }//GEN-LAST:event_lblsanphamMouseExited

    private void lblbanhangMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblbanhangMouseEntered
        // TODO add your handling code here:
        lblbanhang.setBackground(new java.awt.Color(70, 130, 180));
        lblbanhang.setOpaque(true);
        lblbanhang.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblbanhangMouseEntered

    private void lblbanhangMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblbanhangMouseExited
        // TODO add your handling code here:
        lblbanhang.setBackground(null);
        lblbanhang.setOpaque(false);
    }//GEN-LAST:event_lblbanhangMouseExited

    private void lblgiamgiaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblgiamgiaMouseEntered
        // TODO add your handling code here:
        lblgiamgia.setBackground(new java.awt.Color(70, 130, 180));
        lblgiamgia.setOpaque(true);
        lblgiamgia.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblgiamgiaMouseEntered

    private void lblgiamgiaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblgiamgiaMouseExited
        // TODO add your handling code here:
        lblgiamgia.setBackground(null);
        lblgiamgia.setOpaque(false);
    }//GEN-LAST:event_lblgiamgiaMouseExited

    private void lblquanlykhachhangMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblquanlykhachhangMouseEntered
        // TODO add your handling code here:
        lblquanlykhachhang.setBackground(new java.awt.Color(70, 130, 180));
        lblquanlykhachhang.setOpaque(true);
        lblquanlykhachhang.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblquanlykhachhangMouseEntered

    private void lblquanlykhachhangMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblquanlykhachhangMouseExited
        // TODO add your handling code here:
        lblquanlykhachhang.setBackground(null);
        lblquanlykhachhang.setOpaque(false);
    }//GEN-LAST:event_lblquanlykhachhangMouseExited

    private void lbldangnhapMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangnhapMouseEntered
        // TODO add your handling code here:
        lbldangnhap.setBackground(new java.awt.Color(70, 130, 180));
        lbldangnhap.setOpaque(true);
        lbldangnhap.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lbldangnhapMouseEntered

    private void lbldangnhapMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangnhapMouseExited
        // TODO add your handling code here:
        lbldangnhap.setBackground(null);
        lbldangnhap.setOpaque(false);
    }//GEN-LAST:event_lbldangnhapMouseExited

    private void lbldangxuatMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangxuatMouseEntered
        // TODO add your handling code here:
        lbldangxuat.setBackground(new java.awt.Color(70, 130, 180));
        lbldangxuat.setOpaque(true);
        lbldangxuat.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lbldangxuatMouseEntered

    private void lbldangxuatMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangxuatMouseExited
        // TODO add your handling code here:
        lbldangxuat.setBackground(null);
        lbldangxuat.setOpaque(false);
    }//GEN-LAST:event_lbldangxuatMouseExited

    private void rdo_ngungban_spctActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdo_ngungban_spctActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdo_ngungban_spctActionPerformed

    private void btn_lammoi2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_lammoi2ActionPerformed
        // TODO add your handling code here:
        this.clearDSPCT();
        fillToTablespchitiet();
    }//GEN-LAST:event_btn_lammoi2ActionPerformed

    private void btn_timkiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_timkiemActionPerformed
        // TODO add your handling code here:
        if (!checkTrongTK()) {
            return;
        }
        fillToTableSanphamTimkiemSP();
    }//GEN-LAST:event_btn_timkiemActionPerformed

    private void btn_lammoi1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_lammoi1ActionPerformed
        // TODO add your handling code here:
        this.clearDSSP();
        fillToTableSanpham();
    }//GEN-LAST:event_btn_lammoi1ActionPerformed

    private void rdo_thuonghieu_tcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdo_thuonghieu_tcActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_rdo_thuonghieu_tcActionPerformed

    private void lblsanphamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblsanphamMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_SAN_PHAM_NV form = new FORM_QUAN_LY_SAN_PHAM_NV();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblsanphamMouseClicked

    private void lblbanhangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblbanhangMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_BAN_HANG_NV form = new FORM_QUAN_LY_BAN_HANG_NV();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblbanhangMouseClicked

    private void lblgiamgiaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblgiamgiaMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_GIAM_GIA_NV form = new FORM_QUAN_LY_GIAM_GIA_NV();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblgiamgiaMouseClicked

    private void lblquanlykhachhangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblquanlykhachhangMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_KHACH_HANG_NV form = new FORM_QUAN_LY_KHACH_HANG_NV();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblquanlykhachhangMouseClicked

    private void lbldangnhapMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangnhapMouseClicked
        // TODO add your handling code here:
        FORM_DANG_NHAP form = new FORM_DANG_NHAP();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lbldangnhapMouseClicked

    private void txt_masp_spctActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_masp_spctActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_masp_spctActionPerformed

    private void tbl_sanphamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_sanphamMouseClicked
        // TODO add your handling code here:
        // TODO add your handling code here:
        index = tbl_sanpham.getSelectedRow();

        String maSP = tbl_sanpham.getValueAt(index, 0).toString();
        String tenSP = tbl_sanpham.getValueAt(index, 1).toString();
        if (index == lastSelectedRow) {
            txt_masp_spct.setText(maSP);
            txt_tensp_spct.setText(tenSP);

            jTabbedPane1.setSelectedIndex(1);
            this.fillToTablespchitiettimSP(maSP);
            try {
                int rowSPCT = tbl_spct.getRowCount();

                if (rowSPCT > 0) {
                    // Lấy đơn giá từ SPCT, cột 9 (đơn giá)
                    String dg = tbl_spct.getValueAt(0, 9).toString();

                    double gia = Double.parseDouble(
                            dg.replace(".", "")
                                    .replace(",", "")
                                    .replace("đ", "")
                                    .trim());

                    txt_dongia.setText(formatMoneyVND(gia));
                }
            } catch (Exception ex) {
                System.out.println("Không thể format đơn giá");
            }
            lastSelectedRow = -1;
        } else {
            this.EditSP();
            lastSelectedRow = index;
        }
        this.clearSPCTCT();
    }//GEN-LAST:event_tbl_sanphamMouseClicked

    private void tbl_thuoctinhMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_thuoctinhMouseClicked
        // TODO add your handling code here:
        index = tbl_thuoctinh.getSelectedRow();
        this.EditTC();
    }//GEN-LAST:event_tbl_thuoctinhMouseClicked

    private void tbl_spctMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_spctMouseClicked
        // TODO add your handling code here:
        index = tbl_spct.getSelectedRow();
        this.EditSPCT();

    }//GEN-LAST:event_tbl_spctMouseClicked

    private void btn_themActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_themActionPerformed
        // TODO add your handling code here:
        if (!checkTrong()) {
            return;
        }
        if (!chechTrungSP()) {
            return;
        }
        int yes = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn thêm hay không?");
        if (yes == JOptionPane.YES_OPTION) {
            this.createSP();
            JOptionPane.showMessageDialog(this, "Bạn đã thêm thành công");
            //làm mới ô txt và cbo
            this.clearSP();
        }
    }//GEN-LAST:event_btn_themActionPerformed

    private void btn_themspctActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_themspctActionPerformed
        // TODO add your handling code here:
        if (!checkTrongSPCT()) {
            return;
        }
        if (ChecktrungSPCT()) {

            int yes = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn thêm hay không?");
            if (yes == JOptionPane.YES_OPTION) {
                this.createSPCT();
                JOptionPane.showMessageDialog(this, "Bạn đã thêm thành công");
                //làm mới ô txt và cbo
                this.clearSPCT();
            }
        }
    }//GEN-LAST:event_btn_themspctActionPerformed

    private void btn_chinhsuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_chinhsuaActionPerformed
       // TODO add your handling code here:
        if (!checkTrong()) {
            return;
        }
        if(!checkTonTaiSP()){
         JOptionPane.showMessageDialog(this, "Mã sản phẩm: "+txt_masp.getText()+" Không tồn tại trong hệ thống!");
         return;
         }
        if (!CheckupdateSP()) {
            return;
        }

        int yes = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn sửa hay không?");
        if (yes == JOptionPane.YES_OPTION) {
            this.updateSP();
            JOptionPane.showMessageDialog(this, "Bạn đã sửa thành công");
             //làm mới ô txt và cbo
            this.clearSP();
        }
    }//GEN-LAST:event_btn_chinhsuaActionPerformed

    private void btn_lammoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_lammoiActionPerformed
        // TODO add your handling code here:
        this.clearSP();
    }//GEN-LAST:event_btn_lammoiActionPerformed

    private void btn_chinhsuaspctActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_chinhsuaspctActionPerformed
        // TODO add your handling code here:
         if (!checkTrongSPCT()) {
            return;
        }
         if(!checkTonTai()){
         JOptionPane.showMessageDialog(this, "Mã sản phẩm chi tiết: "+txt_maspct.getText()+" Không tồn tại trong hệ thống!");
         return;
         }
//        if (!CheckupdateSPCT()) {
//            return;
//        }
        
        int yes = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn sửa hay không?");
        if (yes == JOptionPane.YES_OPTION) {
            this.updateSPCT();

            JOptionPane.showMessageDialog(this, "Bạn đã sửa thành công sản phẩm chi tiết");
             //làm mới ô txt và cbo
            this.clearSPCT();
        }
    }//GEN-LAST:event_btn_chinhsuaspctActionPerformed

    private void btn_lammoispctActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_lammoispctActionPerformed
        // TODO add your handling code here:
        this.clearSPCT();
        fillToTablespchitiet();

    }//GEN-LAST:event_btn_lammoispctActionPerformed

    private void btn_timkiem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_timkiem1ActionPerformed
        // TODO add your handling code here:
        if (!checkTrongTKSPCT()) {
            return;
        }
        fillToTablespchitietTKSPCT();


    }//GEN-LAST:event_btn_timkiem1ActionPerformed

    private void btn_themtcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_themtcActionPerformed
        // TODO add your handling code here:

        if (!checkData()) {
            return; // nếu sai dữ liệu thì dừng
        }
        if (!checkTrongTT()) {
            return;
        }
        if (!ChecktrungThuocTinh()) {
            return;
        }

        if (rdo_mausac_tc.isSelected()) {

            createMSTC();
            JOptionPane.showMessageDialog(this, "Bạn đã thêm thành công");
            fillToTableMausac();
            this.clearTT();
        } else if (rdo_chatlieu_tc.isSelected()) {
            createCLTC();
            JOptionPane.showMessageDialog(this, "Bạn đã thêm thành công");
            fillToTableChatlieu();
            this.clearTT();
        } else if (rdo_size_tc.isSelected()) {
            createSZTC();
            JOptionPane.showMessageDialog(this, "Bạn đã thêm thành công");
            fillToTableSize();
            this.clearTT();

        } else if (rdo_thuonghieu_tc.isSelected()) {
            createTHTC();
            JOptionPane.showMessageDialog(this, "Bạn đã thêm thành công");
            fillToTableThuonghieu();
            this.clearTT();
        } else if (rdo_coao_tc.isSelected()) {
            createCATC();
            fillToTableCoao();
            this.clearTT();
        }
    }//GEN-LAST:event_btn_themtcActionPerformed

    private void btn_chinhsuatcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_chinhsuatcActionPerformed
        // TODO add your handling code here:
   if (!checkData()) {
            return; // nếu sai dữ liệu thì dừng
        }
        if (!checkTrongTT()) {
            return;
        }
         if(!ChecktontaiThuocTinh()){
         JOptionPane.showMessageDialog(this, "Thuộc tính: "+txt_ma_tc.getText()+" Không tồn tại trong hệ thống!");
         return;
         }
        if (!ChecktrungThuocTinhUDTT()) {
            return;
        }
        if (rdo_gr_thuoc_tinh.getSelection() == null) {
            JOptionPane.showMessageDialog(this, "Ban phai chon it nhat 1 rdo");

        } else if (rdo_chatlieu_tc.isSelected()) {
            int yes = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn sửa hay không?");
            if (yes == JOptionPane.YES_OPTION) {
                this.updateCLTC();

                JOptionPane.showMessageDialog(this, "Bạn đã sửa thành công");
                fillToTableChatlieu();

            }

        } else if (rdo_coao_tc.isSelected()) {
            int yes = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn sửa hay không?");
            if (yes == JOptionPane.YES_OPTION) {
                this.updateCATC();

                JOptionPane.showMessageDialog(this, "Bạn đã sửa thành công");

                fillToTableChatlieu();
            }
        } else if (rdo_mausac_tc.isSelected()) {
            int yes = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn sửa hay không?");
            if (yes == JOptionPane.YES_OPTION) {
                this.updateMSTC();
                JOptionPane.showMessageDialog(this, "Bạn đã chỉnh sửa thành công");

                fillToTableMausac();
            }
        } else if (rdo_size_tc.isSelected()) {
            int yes = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn sửa hay không?");
            if (yes == JOptionPane.YES_OPTION) {
                this.updateSZTC();
                JOptionPane.showMessageDialog(this, "Bạn đã chỉnh sửa thành công");

                fillToTableSize();
            }

        } else if (rdo_thuonghieu_tc.isSelected()) {
            int yes = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn sửa hay không?");
            if (yes == JOptionPane.YES_OPTION) {
                this.updateTHTC();
                JOptionPane.showMessageDialog(this, "Bạn đã chỉnh sửa thành công");

                fillToTableThuonghieu();
            }

        }
    }//GEN-LAST:event_btn_chinhsuatcActionPerformed

    private void rdo_mausac_tcMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rdo_mausac_tcMouseClicked
        // TODO add your handling code here:
        if (rdo_mausac_tc.isSelected()) {
            this.fillToTableMausac();
        }
        // phần code mới
        //  làm mới xóa các ô txt và rdo
        this.clearTTCC();
    }//GEN-LAST:event_rdo_mausac_tcMouseClicked

    private void rdo_thuonghieu_tcMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rdo_thuonghieu_tcMouseClicked
        // TODO add your handling code here:
        if (rdo_thuonghieu_tc.isSelected()) {
            this.fillToTableThuonghieu();
        }        // phần code mới
//  hàm làm mới xóa các ô txt và rdo
        this.clearTTCC();
    }//GEN-LAST:event_rdo_thuonghieu_tcMouseClicked

    private void rdo_chatlieu_tcMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rdo_chatlieu_tcMouseClicked
        // TODO add your handling code here:
        if (rdo_chatlieu_tc.isSelected()) {
            this.fillToTableChatlieu();
        }
        this.clearTTCC();
    }//GEN-LAST:event_rdo_chatlieu_tcMouseClicked

    private void rdo_size_tcMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rdo_size_tcMouseClicked
        // TODO add your handling code here:
        if (rdo_size_tc.isSelected()) {
            this.fillToTableSize();
        }
        this.clearTTCC();
    }//GEN-LAST:event_rdo_size_tcMouseClicked

    private void rdo_coao_tcMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rdo_coao_tcMouseClicked
        // TODO add your handling code here:
        if (rdo_coao_tc.isSelected()) {
            this.fillToTableCoao();
        }
        this.clearTTCC();
    }//GEN-LAST:event_rdo_coao_tcMouseClicked

    private void btn_taomaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_taomaActionPerformed
        // TODO add your handling code here:
        txt_masp.setText(randomCode("SP00", 3));
    }//GEN-LAST:event_btn_taomaActionPerformed

    private void btn_taomaspctActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_taomaspctActionPerformed
        // TODO add your handling code here:
        txt_maspct.setText(randomCode("SPCT00", 3));
    }//GEN-LAST:event_btn_taomaspctActionPerformed

    private void btn_taomatcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_taomatcActionPerformed
        // TODO add your handling code here:
        txt_ma_tc.setText(randomCode("TC00", 3));
    }//GEN-LAST:event_btn_taomatcActionPerformed

    private void btn_xoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_xoaActionPerformed
        // TODO add your handling code here:
        index = tbl_sanpham.getSelectedRow();
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "Bạn hãy chọn sản phẩm để xóa");
            return;
        }
        String maSP = tbl_sanpham.getValueAt(index, 0).toString();
        int confirm = JOptionPane.showConfirmDialog(
                this, "Bạn có chắc chắn muốn chuyển Sản phẩm '" + maSP + "' sang trạng thái KHÔNG HOẠT ĐỘNG ?"
        );
        if (confirm == JOptionPane.YES_OPTION) {

            this.xoaSP(maSP);
        }
        this.clearSP();
    }//GEN-LAST:event_btn_xoaActionPerformed

    private void btn_xoa_spctActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_xoa_spctActionPerformed
        // TODO add your handling code here:
        index = tbl_spct.getSelectedRow();
        // xóa chuyển sang k hoạt động
        if (index == -1) {
            JOptionPane.showMessageDialog(this, "Bạn hãy chọn sản phẩm để xóa");
            return;
        }
        String maSP = tbl_spct.getValueAt(index, 1).toString();
        int confirm = JOptionPane.showConfirmDialog(
                this,
                "Bạn có chắc chắn muốn chuyển Sản phẩm '" + maSP + "' sang trạng thái Ngừng bán ?",
                "Xác nhận Xóa mềm",
                JOptionPane.YES_NO_OPTION
        );
        if (confirm == JOptionPane.YES_OPTION) {

            this.xoaSPCT(maSP);
        }
    }//GEN-LAST:event_btn_xoa_spctActionPerformed

    private void btn_fulldsActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_fulldsActionPerformed
        // TODO add your handling code here:
        fillToTablespchitiet();
    }//GEN-LAST:event_btn_fulldsActionPerformed

    private void txt_tensp_spctActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_tensp_spctActionPerformed
        // TODO add your handling code here:
        jTabbedPane1.setSelectedIndex(1);
        this.fillToTablespchitiet();
    }//GEN-LAST:event_txt_tensp_spctActionPerformed

    private void btn_xoa_tcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_xoa_tcActionPerformed
        // TODO add your handling code here:
        if (!checkData()) {
            return; // nếu sai dữ liệu thì dừng
        }

        if (thuoctinhxoa().equalsIgnoreCase("Mausac")) {
            this.xoaMS(txt_ma_tc.getText());
        } else if (thuoctinhxoa().equalsIgnoreCase("Chatlieu")) {
            this.xoaCL(txt_ma_tc.getText());
        } else if (thuoctinhxoa().equalsIgnoreCase("Coao")) {
            this.xoaCA(txt_ma_tc.getText());
        } else if (thuoctinhxoa().equalsIgnoreCase("Size")) {
            this.xoaSZ(txt_ma_tc.getText());
        } else if (thuoctinhxoa().equalsIgnoreCase("Thuonghieu")) {
            this.xoaTH(txt_ma_tc.getText());
        }
    }//GEN-LAST:event_btn_xoa_tcActionPerformed

    private void btn_lammoi_tcActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_lammoi_tcActionPerformed
        // TODO add your handling code here:
        // làm mới 
        this.clearTT();
        this.fillToTableMausac();
    }//GEN-LAST:event_btn_lammoi_tcActionPerformed

    private void lbldangxuatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangxuatMouseClicked
        // TODO add your handling code here:
                int yes = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn thoát hay không?");
        if(yes == JOptionPane.YES_OPTION){
        System.exit(0);
        }
    }//GEN-LAST:event_lbldangxuatMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FORM_QUAN_LY_SAN_PHAM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FORM_QUAN_LY_SAN_PHAM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FORM_QUAN_LY_SAN_PHAM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FORM_QUAN_LY_SAN_PHAM.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FORM_QUAN_LY_SAN_PHAM().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_chinhsua;
    private javax.swing.JButton btn_chinhsuaspct;
    private javax.swing.JButton btn_chinhsuatc;
    private javax.swing.JButton btn_fullds;
    private javax.swing.JButton btn_lammoi;
    private javax.swing.JButton btn_lammoi1;
    private javax.swing.JButton btn_lammoi2;
    private javax.swing.JButton btn_lammoi_tc;
    private javax.swing.JButton btn_lammoispct;
    private javax.swing.JTextField btn_ma_sp_timkiem;
    private javax.swing.JButton btn_taoma;
    private javax.swing.JButton btn_taomaspct;
    private javax.swing.JButton btn_taomatc;
    private javax.swing.JButton btn_them;
    private javax.swing.JButton btn_themspct;
    private javax.swing.JButton btn_themtc;
    private javax.swing.JButton btn_timkiem;
    private javax.swing.JButton btn_timkiem1;
    private javax.swing.JButton btn_xoa;
    private javax.swing.JButton btn_xoa_spct;
    private javax.swing.JButton btn_xoa_tc;
    private javax.swing.JComboBox<String> cbo_chatlieu_sp;
    private javax.swing.JComboBox<String> cbo_chatlieuspct_tim_kiem;
    private javax.swing.JComboBox<String> cbo_coao_spp;
    private javax.swing.JComboBox<String> cbo_coaospct_tim_kiem;
    private javax.swing.JComboBox<String> cbo_mausac_spct;
    private javax.swing.JComboBox<String> cbo_mausacspct_tim_kiem;
    private javax.swing.JComboBox<String> cbo_size_spct;
    private javax.swing.JComboBox<String> cbo_sizespct_tim_kiem;
    private javax.swing.JComboBox<String> cbo_thuonghieu_sp;
    private javax.swing.JComboBox<String> cbo_thuonghieu_sp_timkiem;
    private javax.swing.JComboBox<String> cbo_thuonghieuspct_tim_kiem;
    private javax.swing.JComboBox<String> cbo_trangthai_sp;
    private javax.swing.JComboBox<String> cbo_trangthai_sp_timkiem;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel24;
    private javax.swing.JLabel jLabel25;
    private javax.swing.JLabel jLabel26;
    private javax.swing.JLabel jLabel27;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel30;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel10;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JTabbedPane jTabbedPane1;
    private javax.swing.JLabel lblbanhang;
    private javax.swing.JLabel lbldangnhap;
    private javax.swing.JLabel lbldangxuat;
    private javax.swing.JLabel lblgiamgia;
    private javax.swing.JLabel lblquanlykhachhang;
    private javax.swing.JLabel lblsanpham;
    private javax.swing.JRadioButton rdo_chatlieu_tc;
    private javax.swing.JRadioButton rdo_coao_tc;
    private javax.swing.JRadioButton rdo_dangban_spct;
    private javax.swing.ButtonGroup rdo_gr_thuoc_tinh;
    private javax.swing.ButtonGroup rdo_gr_trang_thai;
    private javax.swing.ButtonGroup rdo_gr_trangthai;
    private javax.swing.JRadioButton rdo_hoatdong_tc;
    private javax.swing.JRadioButton rdo_khonghoatdong_tc;
    private javax.swing.JRadioButton rdo_mausac_tc;
    private javax.swing.JRadioButton rdo_ngungban_spct;
    private javax.swing.JRadioButton rdo_size_tc;
    private javax.swing.JRadioButton rdo_thuonghieu_tc;
    private javax.swing.JTable tbl_sanpham;
    private javax.swing.JTable tbl_spct;
    private javax.swing.JTable tbl_thuoctinh;
    private javax.swing.JTextField txt_dongia;
    private javax.swing.JTextField txt_ma_tc;
    private javax.swing.JTextField txt_masp;
    private javax.swing.JTextField txt_masp_spct;
    private javax.swing.JTextField txt_maspct;
    private javax.swing.JTextField txt_maspcttimkiem;
    private javax.swing.JTextArea txt_motasp;
    private javax.swing.JTextField txt_soluong;
    private javax.swing.JTextField txt_ten_tc;
    private javax.swing.JTextField txt_tensp;
    private javax.swing.JTextField txt_tensp_spct;
    // End of variables declaration//GEN-END:variables

    @Override
    public void open() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void setForm(Sanphamchitiet entity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Sanphamchitiet getForm() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Sanphamchitiet SPCT = new Sanphamchitiet();

        Sanpham SP = repoSP.IDSP(txt_masp.getText());
        if (SP == null) {
            JOptionPane.showMessageDialog(null, "Mã sản phẩm không tồn tại!");
            return null;
        }
        int IDSP = SP.getID_san_pham();

        Size SZ = repoSZ.IDSize(cbo_size_spct.getSelectedItem().toString());
        int IDSZ = SZ.getID_size();
        Mausac MS = repoMS.IDMau(cbo_mausac_spct.getSelectedItem().toString());
        int IDMS = MS.getID_mau_sac();
        String ma_nguoi_tao = Session.getMaNhanVien();
        String txt = txt_dongia.getText();
        BigDecimal gia = new BigDecimal(txt);

        SPCT.setID_san_pham(IDSP);
        SPCT.setMa_san_pham_chi_tiet(txt_maspct.getText());
        SPCT.setSo_luong_ton(Integer.parseInt(txt_soluong.getText()));
        SPCT.setDon_gia(gia);
        SPCT.setMa_nguoi_tao(ma_nguoi_tao);
        SPCT.setID_size(IDSZ);
        SPCT.setID_mau_sac(IDMS);

        return SPCT;
    }

    public Sanphamchitiet getFormUPDATESPCT() {

        Sanphamchitiet SPCT = new Sanphamchitiet();
        Sanpham SP = repoSP.IDSP(txt_masp.getText());
        int IDSP = SP.getID_san_pham();

        Sanphamchitiet SPCTUD = repoSPCT.IDSPCT(txt_maspct.getText());
        int IDSPCTUD = SPCTUD.getID_san_pham_chi_tiet();
        Size SZ = repoSZ.IDSize(cbo_size_spct.getSelectedItem().toString());
        int IDSZ = SZ.getID_size();
        Mausac MS = repoMS.IDMau(cbo_mausac_spct.getSelectedItem().toString());
        int IDMS = MS.getID_mau_sac();
        String ma_nguoi_cap_nhat = Session.getMaNhanVien();
        String txt = txt_dongia.getText();
        BigDecimal gia = new BigDecimal(txt);

        SPCT.setID_san_pham(IDSP);
        SPCT.setMa_san_pham_chi_tiet(txt_maspct.getText());
        SPCT.setID_san_pham_chi_tiet(IDSPCTUD);
        SPCT.setSo_luong_ton(Integer.parseInt(txt_soluong.getText()));
        SPCT.setDon_gia(gia);
        SPCT.setMa_nguoi_cap_nhat(ma_nguoi_cap_nhat);
        SPCT.setID_size(IDSZ);
        SPCT.setID_mau_sac(IDMS);

        if (rdo_dangban_spct.isSelected()) {
            SPCT.setTrang_thai(true);
        } else {
            SPCT.setTrang_thai(false);
        }
        return SPCT;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Sanpham getFormSP() {

        Sanpham SP = new Sanpham();

//        hàm lấy id của cổ áo
        Coao CA = repoCA.IDCOAO(cbo_coao_spp.getSelectedItem().toString());
        int IDCA = CA.getID_co_ao();
        //        hàm lấy id của thương hiệu
        Thuonghieu TH = repoTH.IDTH(cbo_thuonghieu_sp.getSelectedItem().toString());
        int IDTH = TH.getID_thuong_hieu();
        //        hàm lấy id của chất liệu
        Chatlieu CL = repoCL.IDCHATLIEU(cbo_chatlieu_sp.getSelectedItem().toString());
        int IDCL = CL.getID_chat_lieu();

        SP.setMa_san_pham(txt_masp.getText());
        SP.setTen_san_pham(txt_tensp.getText());
        SP.setMo_ta_san_pham(txt_motasp.getText());
        SP.setID_co_ao(IDCA);
        SP.setID_thuong_hieu(IDTH);
        SP.setID_chat_lieu(IDCL);

        return SP;

    }

    public Sanpham getFormSPUPDATE() {

        Sanpham SP = new Sanpham();
        Sanpham ID = repoSP.IDSP(txt_masp.getText());
        int IDSP = ID.getID_san_pham();
        SP.setID_chat_lieu(ICONIFIED);
//        hàm lấy id của cổ áo
        Coao CA = repoCA.IDCOAO(cbo_coao_spp.getSelectedItem().toString());
        int IDCA = CA.getID_co_ao();
        //        hàm lấy id của thương hiệu
        Thuonghieu TH = repoTH.IDTH(cbo_thuonghieu_sp.getSelectedItem().toString());
        int IDTH = TH.getID_thuong_hieu();
        //        hàm lấy id của chất liệu
        Chatlieu CL = repoCL.IDCHATLIEU(cbo_chatlieu_sp.getSelectedItem().toString());
        int IDCL = CL.getID_chat_lieu();

        SP.setID_san_pham(IDSP);
        SP.setMa_san_pham(txt_masp.getText());
        SP.setTen_san_pham(txt_tensp.getText());
        SP.setMo_ta_san_pham(txt_motasp.getText());
        SP.setID_co_ao(IDCA);
        SP.setID_thuong_hieu(IDTH);
        SP.setID_chat_lieu(IDCL);
        if (cbo_trangthai_sp.getSelectedItem().equals("Hoạt động")) {
            SP.setTrang_thai(true);
        } else {
            SP.setTrang_thai(false);
        }
        return SP;

    }

    public Mausac getFormMS() {
        Mausac MS = new Mausac();

        MS.setMa_mau_sac(txt_ma_tc.getText());
        MS.setTen_mau(txt_ten_tc.getText());
        return MS;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Mausac getFormMSUD() {
        Mausac MS = new Mausac();
        Mausac MSGF = repoMS.ID(txt_ma_tc.getText());
        int IDMS = MSGF.getID_mau_sac();

        MS.setID_mau_sac(IDMS);

        MS.setMa_mau_sac(txt_ma_tc.getText());
        MS.setTen_mau(txt_ten_tc.getText());
        if (rdo_hoatdong_tc.isSelected()) {
            MS.setTrang_thai(true);
        } else {
            MS.setTrang_thai(false);
        }
        return MS;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Chatlieu getFormCL() {
        Chatlieu CL = new Chatlieu();
        CL.setMa_chat_lieu(txt_ma_tc.getText());
        CL.setTen_chat_lieu(txt_ten_tc.getText());
        return CL;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Chatlieu getFormCLUD() {
        Chatlieu CL = new Chatlieu();
        Chatlieu CLTC = repoCL.ID(txt_ma_tc.getText());
        int IDCL = CLTC.getID_chat_lieu();

        CL.setID_chat_lieu(IDCL);
        CL.setMa_chat_lieu(txt_ma_tc.getText());
        CL.setTen_chat_lieu(txt_ten_tc.getText());
        if (rdo_hoatdong_tc.isSelected()) {
            CL.setTrang_thai(true);
        } else {
            CL.setTrang_thai(false);
        }
        return CL;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Thuonghieu getFormTH() {
        Thuonghieu TH = new Thuonghieu();
        TH.setMa_thuong_hieu(txt_ma_tc.getText());
        TH.setTen_thuong_hieu(txt_ten_tc.getText());
        return TH;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Thuonghieu getFormTHUD() {
        Thuonghieu TH = new Thuonghieu();
        Thuonghieu THTC = repoTH.ID(txt_ma_tc.getText());
        int IDTH = THTC.getID_thuong_hieu();
        TH.setID_thuong_hieu(IDTH);
        TH.setMa_thuong_hieu(txt_ma_tc.getText());
        TH.setTen_thuong_hieu(txt_ten_tc.getText());
        if (rdo_hoatdong_tc.isSelected()) {
            TH.setTrang_thai(true);
        } else {
            TH.setTrang_thai(false);
        }
        return TH;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Size getFormSZ() {
        Size SZ = new Size();
        SZ.setMa_size(txt_ma_tc.getText());
        SZ.setTen_size(txt_ten_tc.getText());
        return SZ;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Size getFormSZUD() {
        Size SZ = new Size();
        Size SZTC = repoSZ.ID(txt_ma_tc.getText());
        int IDSZ = SZTC.getID_size();
        SZ.setID_size(IDSZ);
        SZ.setMa_size(txt_ma_tc.getText());
        SZ.setTen_size(txt_ten_tc.getText());
        if (rdo_hoatdong_tc.isSelected()) {
            SZ.setTrang_thai(true);
        } else {
            SZ.setTrang_thai(false);
        }
        return SZ;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Coao getFormCA() {
        Coao CA = new Coao();
        CA.setMa_co_ao(txt_ma_tc.getText());
        CA.setTen_co_ao(txt_ten_tc.getText());
        return CA;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Coao getFormCAUD() {
        Coao CA = new Coao();
        Coao CATC = repoCA.ID(txt_ma_tc.getText());
        int IDCA = CATC.getID_co_ao();
        CA.setID_co_ao(IDCA);
        CA.setMa_co_ao(txt_ma_tc.getText());
        CA.setTen_co_ao(txt_ten_tc.getText());
        if (rdo_hoatdong_tc.isSelected()) {
            CA.setTrang_thai(true);
        } else {
            CA.setTrang_thai(false);
        }
        return CA;
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Sanpham getFormTT() {

        Sanpham SP = new Sanpham();
        Sanpham ID = repoSP.IDSP(txt_masp.getText());
        int IDSP = ID.getID_san_pham();
        SP.setID_chat_lieu(ICONIFIED);
//        hàm lấy id của cổ áo
        Coao CA = repoCA.IDCOAO(cbo_coao_spp.getSelectedItem().toString());
        int IDCA = CA.getID_co_ao();
        //        hàm lấy id của thương hiệu
        Thuonghieu TH = repoTH.IDTH(cbo_thuonghieu_sp.getSelectedItem().toString());
        int IDTH = TH.getID_thuong_hieu();
        //        hàm lấy id của chất liệu
        Chatlieu CL = repoCL.IDCHATLIEU(cbo_chatlieu_sp.getSelectedItem().toString());
        int IDCL = CL.getID_chat_lieu();

        SP.setID_san_pham(IDSP);
        SP.setMa_san_pham(txt_masp.getText());
        SP.setTen_san_pham(txt_tensp.getText());
        SP.setMo_ta_san_pham(txt_motasp.getText());
        SP.setID_co_ao(IDCA);
        SP.setID_thuong_hieu(IDTH);
        SP.setID_chat_lieu(IDCL);
        if (cbo_trangthai_sp.getSelectedItem().equals("Hoạt động")) {
            SP.setTrang_thai(true);
        } else {
            SP.setTrang_thai(false);
        }
        return SP;

        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void fillToTable() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
// cbbo phần thuộc 

    public void fillToTableChatlieu() {
        modeTT = (DefaultTableModel) tbl_thuoctinh.getModel();
        modeTT.setRowCount(0);
        for (Chatlieu CL : repoCL.findAll()) {
            Object[] data = new Object[]{
                CL.getMa_chat_lieu(), CL.getTen_chat_lieu(), CL.hoatdong(CL.isTrang_thai())
            };
            modeTT.addRow(data);
        }
    }
// cbbo phần thuộc tính

    public void fillToTableCoao() {
        modeTT = (DefaultTableModel) tbl_thuoctinh.getModel();
        modeTT.setRowCount(0);
        for (Coao CA : repoCA.findAll()) {
            Object[] data = new Object[]{
                CA.getMa_co_ao(), CA.getTen_co_ao(), CA.hoatdong(CA.isTrang_thai())
            };
            modeTT.addRow(data);
        }
    }
// cbbo phần thuộc tính

    public void fillToTableMausac() {
        modeTT = (DefaultTableModel) tbl_thuoctinh.getModel();
        modeTT.setRowCount(0);
        for (Mausac MS : repoMS.findAll()) {
            Object[] data = new Object[]{
                MS.getMa_mau_sac(), MS.getTen_mau(), MS.hoatdong(MS.isTrang_thai())
            };
            modeTT.addRow(data);
        }
    }// cbbo phần thuộc tính

    public void fillToTableSize() {
        modeTT = (DefaultTableModel) tbl_thuoctinh.getModel();
        modeTT.setRowCount(0);
        for (Size SZ : repoSZ.findAll()) {
            Object[] data = new Object[]{
                SZ.getMa_size(), SZ.getTen_size(), SZ.hoatdong(SZ.isTrang_thai())
            };
            modeTT.addRow(data);
        }
    }
// cbbo phần thuộc tính

    public void fillToTableThuonghieu() {
        modeTT = (DefaultTableModel) tbl_thuoctinh.getModel();
        modeTT.setRowCount(0);
        for (Thuonghieu TH : repoTH.findAll()) {
            Object[] data = new Object[]{
                TH.getMa_thuong_hieu(), TH.getTen_thuong_hieu(), TH.hoatdong(TH.isTrang_thai())
            };
            modeTT.addRow(data);
        }
    }

    public void fillToTablespchitiet() {
        modeSPCT = (DefaultTableModel) tbl_spct.getModel();
        modeSPCT.setRowCount(0);

        for (Sanphamchitiet SPCT : repoSPCT.findAll()) {
            // format lại đơn giá ở hàm fill
            BigDecimal donGia = SPCT.getDon_gia();
            String donGiaFormatted = formatCurrency(donGia);
            Object[] data = new Object[]{
                SPCT.getMa_san_pham(), SPCT.getMa_san_pham_chi_tiet(), SPCT.getTen_san_pham(), SPCT.getTen_co_ao(), SPCT.getTen_thuong_hieu(), SPCT.getTen_chat_lieu(), SPCT.getTen_mau(), SPCT.getTen_size(),
                SPCT.getSo_luong_ton(), donGiaFormatted, SPCT.hoatdong(SPCT.isTrang_thai())

            };
            modeSPCT.addRow(data);
        }
    }
    // khi click vào sủa chỉ fill lên sp click vào sửa k hiện findall

    public void fillToTablespchitietUDSP(String SP) {
        modeSPCT = (DefaultTableModel) tbl_spct.getModel();
        modeSPCT.setRowCount(0);

        for (Sanphamchitiet SPCT : repoSPCT.timSP(SP)) {
           BigDecimal donGia = SPCT.getDon_gia();
            String donGiaFormatted = formatCurrency(donGia);
            Object[] data = new Object[]{
                SPCT.getMa_san_pham(), SPCT.getMa_san_pham_chi_tiet(), SPCT.getTen_san_pham(), SPCT.getTen_co_ao(), SPCT.getTen_thuong_hieu(), SPCT.getTen_chat_lieu(), SPCT.getTen_mau(), SPCT.getTen_size(),
                SPCT.getSo_luong_ton(), donGiaFormatted, SPCT.hoatdong(SPCT.isTrang_thai())

            };
            modeSPCT.addRow(data);
        }
    }
// tìm kiếm nhiều trường

    public void fillToTablespchitietTKSPCT() {
        modeSPCT = (DefaultTableModel) tbl_spct.getModel();
        modeSPCT.setRowCount(0);
        for (Sanphamchitiet SPCT : repoSPCT.TimkiemSPCT(txt_maspcttimkiem.getText())) {
           BigDecimal donGia = SPCT.getDon_gia();
            String donGiaFormatted = formatCurrency(donGia);
            Object[] data = new Object[]{
                SPCT.getMa_san_pham(), SPCT.getMa_san_pham_chi_tiet(), SPCT.getTen_san_pham(), SPCT.getTen_co_ao(), SPCT.getTen_thuong_hieu(), SPCT.getTen_chat_lieu(), SPCT.getTen_mau(), SPCT.getTen_size(),
                SPCT.getSo_luong_ton(), donGiaFormatted, SPCT.hoatdong(SPCT.isTrang_thai())

            };
            modeSPCT.addRow(data);
        }
    }
// cbbo  phần tìm kiếm spct

    public void fillToTablespchitietTCL(String ChatLieu) {
        modeSPCT = (DefaultTableModel) tbl_spct.getModel();
        modeSPCT.setRowCount(0);

        for (Sanphamchitiet SPCT : repoSPCT.TimCL(ChatLieu)) {
            BigDecimal donGia = SPCT.getDon_gia();
            String donGiaFormatted = formatCurrency(donGia);
            Object[] data = new Object[]{
                SPCT.getMa_san_pham(), SPCT.getMa_san_pham_chi_tiet(), SPCT.getTen_san_pham(), SPCT.getTen_co_ao(), SPCT.getTen_thuong_hieu(), SPCT.getTen_chat_lieu(), SPCT.getTen_mau(), SPCT.getTen_size(),
                SPCT.getSo_luong_ton(), donGiaFormatted, SPCT.hoatdong(SPCT.isTrang_thai())

            };
            modeSPCT.addRow(data);
        }
    }
// cbbo  phần tìm kiếm spct

    public void fillToTablespchitietTCA(String Coao) {
        modeSPCT = (DefaultTableModel) tbl_spct.getModel();
        modeSPCT.setRowCount(0);

        for (Sanphamchitiet SPCT : repoSPCT.TimCA(Coao)) {
           BigDecimal donGia = SPCT.getDon_gia();
            String donGiaFormatted = formatCurrency(donGia);
            Object[] data = new Object[]{
                SPCT.getMa_san_pham(), SPCT.getMa_san_pham_chi_tiet(), SPCT.getTen_san_pham(), SPCT.getTen_co_ao(), SPCT.getTen_thuong_hieu(), SPCT.getTen_chat_lieu(), SPCT.getTen_mau(), SPCT.getTen_size(),
                SPCT.getSo_luong_ton(), donGiaFormatted, SPCT.hoatdong(SPCT.isTrang_thai())

            };
            modeSPCT.addRow(data);
        }
    }
// cbbo  phần tìm kiếm spct

    public void fillToTablespchitietMS(String Mausac) {
        modeSPCT = (DefaultTableModel) tbl_spct.getModel();
        modeSPCT.setRowCount(0);

        for (Sanphamchitiet SPCT : repoSPCT.TimMS(Mausac)) {
           BigDecimal donGia = SPCT.getDon_gia();
            String donGiaFormatted = formatCurrency(donGia);
            Object[] data = new Object[]{
                SPCT.getMa_san_pham(), SPCT.getMa_san_pham_chi_tiet(), SPCT.getTen_san_pham(), SPCT.getTen_co_ao(), SPCT.getTen_thuong_hieu(), SPCT.getTen_chat_lieu(), SPCT.getTen_mau(), SPCT.getTen_size(),
                SPCT.getSo_luong_ton(), donGiaFormatted, SPCT.hoatdong(SPCT.isTrang_thai())

            };
            modeSPCT.addRow(data);
        }
    }
// cbbo  phần tìm kiếm spct

    public void fillToTablespchitietSZ(String Size) {
        modeSPCT = (DefaultTableModel) tbl_spct.getModel();
        modeSPCT.setRowCount(0);

        for (Sanphamchitiet SPCT : repoSPCT.TimSZ(Size)) {
           BigDecimal donGia = SPCT.getDon_gia();
            String donGiaFormatted = formatCurrency(donGia);
            Object[] data = new Object[]{
                SPCT.getMa_san_pham(), SPCT.getMa_san_pham_chi_tiet(), SPCT.getTen_san_pham(), SPCT.getTen_co_ao(), SPCT.getTen_thuong_hieu(), SPCT.getTen_chat_lieu(), SPCT.getTen_mau(), SPCT.getTen_size(),
                SPCT.getSo_luong_ton(), donGiaFormatted, SPCT.hoatdong(SPCT.isTrang_thai())

            };
            modeSPCT.addRow(data);
        }
    }
// cbbo  phần tìm kiếm spct

    public void fillToTablespchitietTH(String Thuonghieu) {
        modeSPCT = (DefaultTableModel) tbl_spct.getModel();
        modeSPCT.setRowCount(0);

        for (Sanphamchitiet SPCT : repoSPCT.TimTH(Thuonghieu)) {
           BigDecimal donGia = SPCT.getDon_gia();
            String donGiaFormatted = formatCurrency(donGia);
            Object[] data = new Object[]{
                SPCT.getMa_san_pham(), SPCT.getMa_san_pham_chi_tiet(), SPCT.getTen_san_pham(), SPCT.getTen_co_ao(), SPCT.getTen_thuong_hieu(), SPCT.getTen_chat_lieu(), SPCT.getTen_mau(), SPCT.getTen_size(),
                SPCT.getSo_luong_ton(), donGiaFormatted, SPCT.hoatdong(SPCT.isTrang_thai())

            };
            modeSPCT.addRow(data);
        }
    }

    public void fillToTableSanpham() {
        modeSP = (DefaultTableModel) tbl_sanpham.getModel();
        modeSP.setRowCount(0);
        for (Sanpham SP : repoSP.findAll()) {
            Object[] data = new Object[]{
                SP.getMa_san_pham(), SP.getTen_san_pham(), SP.getTen_thuong_hieu(), SP.getTen_chat_lieu(), SP.getTen_co_ao(), SP.getSo_luong(), SP.hoatdong(SP.isTrang_thai())
            };
            modeSP.addRow(data);
        }
    }
    // update trạng thái ( xóa )

    public void fillToTableIDSanpham(String masp) {
        modeSP = (DefaultTableModel) tbl_sanpham.getModel();
        modeSP.setRowCount(0);
        for (Sanpham SP : repoSP.UDSP(masp)) {
            Object[] data = new Object[]{
                SP.getMa_san_pham(), SP.getTen_san_pham(), SP.getTen_thuong_hieu(), SP.getTen_chat_lieu(), SP.getTen_co_ao(), SP.getSo_luong(), SP.hoatdong(SP.isTrang_thai())
            };
            modeSP.addRow(data);
        }
    }
// giống bên dưới

    public void fillToTableSanphamTH(String thuonghieu) {
        modeSP = (DefaultTableModel) tbl_sanpham.getModel();
        modeSP.setRowCount(0);
        for (Sanpham SP : repoSP.CBOSP(thuonghieu)) {
            Object[] data = new Object[]{
                SP.getMa_san_pham(), SP.getTen_san_pham(), SP.getTen_thuong_hieu(), SP.getTen_chat_lieu(), SP.getTen_co_ao(), SP.getSo_luong(), SP.hoatdong(SP.isTrang_thai())
            };
            modeSP.addRow(data);
        }
    }
// cbo hoạt đông k hoạt động phần tìm kiếm sp

    public void fillToTableSanphamTT(int HD) {
        modeSP = (DefaultTableModel) tbl_sanpham.getModel();
        modeSP.setRowCount(0);
        for (Sanpham SP : repoSP.CBOHD(HD)) {
            Object[] data = new Object[]{
                SP.getMa_san_pham(), SP.getTen_san_pham(), SP.getTen_thuong_hieu(), SP.getTen_chat_lieu(), SP.getTen_co_ao(), SP.getSo_luong(), SP.hoatdong(SP.isTrang_thai())
            };
            modeSP.addRow(data);
        }
    }
// tìm kiếm nhiều trường

    public void fillToTableSanphamTimkiemSP() {
        modeSP = (DefaultTableModel) tbl_sanpham.getModel();
        modeSP.setRowCount(0);
        for (Sanpham SP : repoSP.TimkiemSP(btn_ma_sp_timkiem.getText())) {
            Object[] data = new Object[]{
                SP.getMa_san_pham(), SP.getTen_san_pham(), SP.getTen_thuong_hieu(), SP.getTen_chat_lieu(), SP.getTen_co_ao(), SP.getSo_luong(), SP.hoatdong(SP.isTrang_thai())
            };
            modeSP.addRow(data);
        }
    }

    // lấy tên từ bảng sp sang spct
    public void fillToTablespchitietTENSPCT(String maSP) {
        modeSPCT = (DefaultTableModel) tbl_spct.getModel();
        modeSPCT.setRowCount(0);
        for (Sanphamchitiet SPCT : repoSPCT.theoSP(maSP)) {
           BigDecimal donGia = SPCT.getDon_gia();
            String donGiaFormatted = formatCurrency(donGia);
            Object[] data = new Object[]{
                SPCT.getMa_san_pham(), SPCT.getMa_san_pham_chi_tiet(), SPCT.getTen_san_pham(), SPCT.getTen_co_ao(), SPCT.getTen_thuong_hieu(), SPCT.getTen_chat_lieu(), SPCT.getTen_mau(), SPCT.getTen_size(),
                SPCT.getSo_luong_ton(), donGiaFormatted, SPCT.hoatdong(SPCT.isTrang_thai())

            };
            modeSPCT.addRow(data);
        }
    }
// phần click 2 lần chuyển tab

    public void fillToTablespchitiettimSP(String SP) {
        modeSPCT = (DefaultTableModel) tbl_spct.getModel();
        modeSPCT.setRowCount(0);

        for (Sanphamchitiet SPCT : repoSPCT.timSP(SP)) {
           BigDecimal donGia = SPCT.getDon_gia();
            String donGiaFormatted = formatCurrency(donGia);
            Object[] data = new Object[]{
                SPCT.getMa_san_pham(), SPCT.getMa_san_pham_chi_tiet(), SPCT.getTen_san_pham(), SPCT.getTen_co_ao(), SPCT.getTen_thuong_hieu(), SPCT.getTen_chat_lieu(), SPCT.getTen_mau(), SPCT.getTen_size(),
                SPCT.getSo_luong_ton(), donGiaFormatted, SPCT.hoatdong(SPCT.isTrang_thai())

            };
            modeSPCT.addRow(data);
        }
    }

    private boolean checkData() {

        // Trường hợp không chọn gì
        if (!rdo_mausac_tc.isSelected()
                && !rdo_chatlieu_tc.isSelected()
                && !rdo_size_tc.isSelected()
                && !rdo_thuonghieu_tc.isSelected()
                && !rdo_coao_tc.isSelected()) {

            JOptionPane.showMessageDialog(this, "Bạn phải chọn 1 loại thuộc tính!");
            return false;
        }

        // Khi chọn màu sắc ⇒ tắt 4 cái còn lại
        if (rdo_mausac_tc.isSelected()) {
            rdo_chatlieu_tc.setSelected(false);
            rdo_size_tc.setSelected(false);
            rdo_thuonghieu_tc.setSelected(false);
            rdo_coao_tc.setSelected(false);
            return true;
        }

        // Khi chọn chất liệu ⇒ tắt 4 cái còn lại
        if (rdo_chatlieu_tc.isSelected()) {
            rdo_mausac_tc.setSelected(false);
            rdo_size_tc.setSelected(false);
            rdo_thuonghieu_tc.setSelected(false);
            rdo_coao_tc.setSelected(false);
            return true;
        }

        // Khi chọn size ⇒ tắt 4 cái còn lại
        if (rdo_size_tc.isSelected()) {
            rdo_mausac_tc.setSelected(false);
            rdo_chatlieu_tc.setSelected(false);
            rdo_thuonghieu_tc.setSelected(false);
            rdo_coao_tc.setSelected(false);
            return true;
        }

        // Khi chọn thương hiệu ⇒ tắt 4 cái còn lại
        if (rdo_thuonghieu_tc.isSelected()) {
            rdo_mausac_tc.setSelected(false);
            rdo_chatlieu_tc.setSelected(false);
            rdo_size_tc.setSelected(false);
            rdo_coao_tc.setSelected(false);
            return true;
        }

        // Khi chọn cổ áo ⇒ tắt 4 cái còn lại
        if (rdo_coao_tc.isSelected()) {
            rdo_mausac_tc.setSelected(false);
            rdo_chatlieu_tc.setSelected(false);
            rdo_size_tc.setSelected(false);
            rdo_thuonghieu_tc.setSelected(false);
            return true;
        }

        return false;
    }

    @Override
    public void edit() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
// click sản phẩm

    public void EditSP() {

        txt_masp.setText(tbl_sanpham.getValueAt(index, 0).toString());
        txt_tensp.setText(tbl_sanpham.getValueAt(index, 1).toString());
        cbo_thuonghieu_sp.setSelectedItem(tbl_sanpham.getValueAt(index, 2).toString());
        cbo_chatlieu_sp.setSelectedItem(tbl_sanpham.getValueAt(index, 3).toString());
        cbo_coao_spp.setSelectedItem(tbl_sanpham.getValueAt(index, 4).toString());
        cbo_trangthai_sp.setSelectedItem(tbl_sanpham.getValueAt(index, 6).toString());
//        txt_masp_spct.setText(tbl_sanpham.getValueAt(index, 0).toString());
//        txt_tensp_spct.setText(tbl_sanpham.getValueAt(index, 1).toString());

        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
// click sản phẩm chi tiết

    public void EditSPCT() {
        txt_masp_spct.setText(tbl_spct.getValueAt(index, 0).toString());
        txt_maspct.setText(tbl_spct.getValueAt(index, 1).toString());
        txt_tensp_spct.setText(tbl_spct.getValueAt(index, 2).toString());
        String formattedDonGia = tbl_spct.getValueAt(index, 9).toString();
        String rawDonGia = formattedDonGia.replaceAll("[^\\d\\.,]", ""); 
        rawDonGia = rawDonGia.replace(".", ""); 
        rawDonGia = rawDonGia.replace(",", "."); 
        if (rawDonGia.contains(".")) {
            rawDonGia = rawDonGia.substring(0, rawDonGia.indexOf(".")); // Lấy phần nguyên nếu cần
        }
        txt_dongia.setText(rawDonGia);
        txt_soluong.setText(tbl_spct.getValueAt(index, 8).toString());
        cbo_size_spct.setSelectedItem(tbl_spct.getValueAt(index, 7).toString().trim());
        cbo_mausac_spct.setSelectedItem(tbl_spct.getValueAt(index, 6).toString().trim());
        if (tbl_spct.getValueAt(index, 10).toString().trim().equalsIgnoreCase("Đang bán")) {
            rdo_dangban_spct.setSelected(true);
        } else {
            rdo_ngungban_spct.setSelected(true);
        }
//        phần click cho các cbo ở phần tìm kiếm

        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void EditTC() {
        txt_ma_tc.setText(tbl_thuoctinh.getValueAt(index, 0).toString());
        txt_ten_tc.setText(tbl_thuoctinh.getValueAt(index, 1).toString());
        if (tbl_thuoctinh.getValueAt(index, 2).toString().equalsIgnoreCase("Hoạt động")) {
            rdo_hoatdong_tc.setSelected(true);
        } else {
            rdo_khonghoatdong_tc.setSelected(true);
        }
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void create() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//     hàm thêm của sản phẩm chi tiết
    }

    public void createSP() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Sanpham SP = this.getFormSP();
        repoSP.create(SP);
        this.fillToTableSanpham();
    }

    public void createSPCT() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Sanphamchitiet SPCT = this.getForm();
        repoSPCT.create(SPCT);
        // lọc theo spct khi thêm chỉ fill ra sản phẩm đc chọn
        String maSanPham = txt_masp_spct.getText();

        this.fillToTablespchitietUDSP(maSanPham);
    }

    public void createMSTC() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Mausac MS = this.getFormMS();
        repoMS.create(MS);
        this.fillToTableMausac();
    }

    public void createCLTC() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Chatlieu CL = this.getFormCL();
        repoCL.create(CL);
        this.fillToTableChatlieu();
    }

    public void createSZTC() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Size SZ = this.getFormSZ();
        repoSZ.create(SZ);
        this.fillToTableSize();
    }

    public void createTHTC() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Thuonghieu TH = this.getFormTH();
        repoTH.create(TH);
        this.fillToTableThuonghieu();
    }

    public void createCATC() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Coao CA = this.getFormCA();
        repoCA.create(CA);
        this.fillToTableCoao();
    }

    @Override
    public void update() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody

    }

    public void updateSPCT() {
        Sanphamchitiet SPCT = this.getFormUPDATESPCT();
        repoSPCT.update(SPCT);
        String maSanPham = txt_masp_spct.getText();
        this.fillToTablespchitietUDSP(maSanPham);
        // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void updateSP() {

        Sanpham SP = this.getFormSPUPDATE();
        repoSP.update(SP);
        this.fillToTableSanpham();
    }

    public void updateMSTC() {

        Mausac MS = this.getFormMSUD();

        repoMS.update(MS);
        this.fillToTableMausac();
        // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void updateCATC() {
        Coao CA = this.getFormCAUD();
        repoCA.update(CA);
        this.fillToTableCoao();
        // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void updateCLTC() {
        Chatlieu CL = this.getFormCLUD();
        repoCL.update(CL);
        this.fillToTableChatlieu();
        // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void updateSZTC() {
        Size SZ = this.getFormSZUD();
        repoSZ.update(SZ);
        this.fillToTableSize();
        // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void updateTHTC() {
        Thuonghieu TH = this.getFormTHUD();
        repoTH.update(TH);
        this.fillToTableThuonghieu();
        // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void updateTTSP() {
        Sanpham SP = this.getFormSPUPDATE();
        repoSP.update(SP);
        this.fillToTableSanpham();
        // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void clear() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // đã sửa làm mới
    public void clearSP() {
        txt_masp.setText("");
        txt_tensp.setText("");
        txt_motasp.setText("");
        cbo_chatlieu_sp.setSelectedIndex(0);
        cbo_coao_spp.setSelectedIndex(0);
        cbo_thuonghieu_sp.setSelectedIndex(0);
        cbo_trangthai_sp.setSelectedIndex(0);

        // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void clearDSSP() {
        btn_ma_sp_timkiem.setText("");
        cbo_trangthai_sp_timkiem.setSelectedIndex(0);
        cbo_thuonghieu_sp_timkiem.setSelectedIndex(0);

        // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    // Trong phần khai báo fields của lớp
    public void clearSPCT() {
        txt_masp_spct.setText("");
        txt_maspct.setText("");
        txt_tensp_spct.setText("");
        txt_dongia.setText("");
        txt_soluong.setText("");
        rdo_gr_trangthai.clearSelection();
        if (cbo_size_spct.getItemCount() > 0) {
            cbo_size_spct.setSelectedIndex(0);
        }
        if (cbo_mausac_spct.getItemCount() > 0);
    }
// đã sửa làm mới trạng thái

    public void clearTT() {
        txt_ma_tc.setText("");
        txt_ten_tc.setText("");

        rdo_gr_trangthai.clearSelection();

        rdo_gr_trang_thai.clearSelection();
        rdo_gr_thuoc_tinh.clearSelection();

    }

    public void clearTTCC() {
        txt_ma_tc.setText("");
        txt_ten_tc.setText("");

        rdo_gr_trangthai.clearSelection();

        rdo_gr_trang_thai.clearSelection();

    }

    // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    public void clearSPCTCT() {
        txt_maspct.setText("");
        txt_dongia.setText("");
        txt_soluong.setText("");
        cbo_size_spct.setSelectedIndex(0);
        cbo_mausac_spct.setSelectedIndex(0);

        rdo_gr_trangthai.clearSelection();

        // Reset về giá trị mặc định cho combobox (nếu cần)
        if (cbo_size_spct.getItemCount() > 0) {
            cbo_size_spct.setSelectedIndex(0);
        }
        if (cbo_mausac_spct.getItemCount() > 0);

        // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void clearDSPCT() {
        txt_maspcttimkiem.setText("");
        cbo_chatlieuspct_tim_kiem.setSelectedIndex(0);
        cbo_coaospct_tim_kiem.setSelectedIndex(0);
        cbo_mausacspct_tim_kiem.setSelectedIndex(0);
        cbo_thuonghieuspct_tim_kiem.setSelectedIndex(0);
        cbo_sizespct_tim_kiem.setSelectedIndex(0);

        // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void setEditable(boolean editable) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void checkAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void uncheckAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deleteCheckedItems() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void moveFirst() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void movePrevious() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void moveNext() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void moveLast() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void moveTo(int rowIndex) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}