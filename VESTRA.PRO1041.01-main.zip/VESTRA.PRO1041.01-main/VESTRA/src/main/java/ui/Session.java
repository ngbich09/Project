/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui;

/**
 *
 * @author manhh
 */
public class Session{

    private static String maTaiKhoan;
    private static String maNhanVien;

    public static void setUser(String taiKhoan, String nhanVien) {
        maTaiKhoan = taiKhoan;
        maNhanVien = nhanVien;
    }

    public static String getMaTaiKhoan() {
        return maTaiKhoan;
    }

    public static String getMaNhanVien() {
        return maNhanVien;
    }

    public static void clear() {
        maTaiKhoan = null;
        maNhanVien = null;
    }
}
