package ui;

import java.awt.*;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

import com.google.zxing.qrcode.QRCodeWriter;
import com.google.zxing.common.BitMatrix;
import com.google.zxing.BarcodeFormat;
import com.google.zxing.client.j2se.MatrixToImageWriter;

public class QRHELPME {

    public static void QRTAO(String maSanPham, String folder, String chu) {

        try {
            int qrSize = 600;           // QR to
            int topMargin = 15;         // khoảng cách tên mã đến QR
            int textHeightBlack = 48;   // font tên mã
            int textHeightBlue = 36;    // font chữ xanh

            int totalHeight = qrSize + topMargin + textHeightBlack;


            QRCodeWriter writer = new QRCodeWriter();
            BitMatrix bitMatrix = writer.encode(maSanPham, BarcodeFormat.QR_CODE, qrSize, qrSize);
            BufferedImage qrImage = MatrixToImageWriter.toBufferedImage(bitMatrix);


            BufferedImage finalImage = new BufferedImage(qrSize, totalHeight, BufferedImage.TYPE_INT_RGB);
            Graphics2D g = finalImage.createGraphics();

 
            g.setColor(Color.WHITE);
            g.fillRect(0, 0, qrSize, totalHeight);


            g.drawImage(qrImage, 0, topMargin + textHeightBlack, null);

            g.setColor(Color.BLACK);
            g.setFont(new Font("Arial", Font.BOLD, textHeightBlack));
            FontMetrics fm = g.getFontMetrics();
            int textWidth = fm.stringWidth(maSanPham);
            int x = (qrSize - textWidth) / 2;
            int y = topMargin + fm.getAscent(); 
            g.drawString(maSanPham, x, y);

            g.setColor(new Color(19, 0, 160)); 
            g.setFont(new Font("Arial", Font.BOLD, textHeightBlue));
            fm = g.getFontMetrics();
            textWidth = fm.stringWidth(chu);
            x = (qrSize - textWidth) / 2;
            y = topMargin + textHeightBlack + (qrSize / 2) + (fm.getAscent() / 2);
            g.drawString(chu, x, y);
            g.dispose();

            File out = new File(folder + "\\" + maSanPham + "_QR.png");
            ImageIO.write(finalImage, "PNG", out);
            System.out.println("QR đã tạo: " + out.getAbsolutePath());

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public static void main(String[] args) {
        QRTAO("SP001-S-TR", "J:\\Vestra_HN2025\\QR", "VESTRA");
    }
}
