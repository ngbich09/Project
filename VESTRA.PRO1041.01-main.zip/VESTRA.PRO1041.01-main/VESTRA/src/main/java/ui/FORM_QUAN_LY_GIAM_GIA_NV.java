/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ui;

import com.toedter.calendar.JCalendar;
import controller.Voucher_CRUD;
import daoipml.Voucher_DAOIpml;
import entity.Voucher;
import java.awt.Cursor;
import java.math.BigDecimal;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import javax.swing.BorderFactory;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;
import com.toedter.calendar.JDateChooser;
import entity.Sanphamchitiet;
import javax.swing.*;
import java.awt.*;
import java.math.BigInteger;
import java.sql.Date;
import java.text.NumberFormat;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.Calendar;
import java.util.Locale;

/**
 *
 * @author manhh
 */
public class FORM_QUAN_LY_GIAM_GIA_NV extends javax.swing.JFrame implements Voucher_CRUD {

    private DefaultTableModel Modelvoucher = new DefaultTableModel();
    private Voucher_DAOIpml repoVoucher = new Voucher_DAOIpml();
    private int index = -1;

    /**
     * Creates new form FROM_THONGKE
     */
    public FORM_QUAN_LY_GIAM_GIA_NV() {
        initComponents();
        hienthilabel();  // hiển thi lable cho from (không xóa);
        this.fillToTable();
//        cbo loại giảm
        cbo_loaigiam.removeAllItems();
        for (Voucher V : repoVoucher.ListLoaiGiam()) {
            cbo_loaigiam.addItem(V.getLoai_giam_gia());
        }
        if (cbo_loaigiam.getSelectedItem().equals("Tien")) {
            txt_mucgiam.setEditable(false);
        }
        cbo_loaigiam.addActionListener(e -> {
            if (cbo_loaigiam.getSelectedItem().equals("Tien")) {
                txt_mucgiam.setEditable(false);
                txt_mucgiam.setText("");
            } else {
                txt_mucgiam.setEditable(true);
            }
        });
    }

    public boolean checkNgay() {
        String ngayBatDauStr = txt_batdau.getText().trim();
        String ngayKetThucStr = txt_ketthuc.getText().trim();

        DateTimeFormatter fmt = DateTimeFormatter.ofPattern("dd-MM-yyyy");

        try {

            LocalDate ngayBatDau = LocalDate.parse(ngayBatDauStr, fmt);
            LocalDate ngayKetThuc = LocalDate.parse(ngayKetThucStr, fmt);

            if (!ngayBatDau.equals(LocalDate.now())) {
                JOptionPane.showMessageDialog(this, "Ngày bắt đầu phải là ngày hôm nay!");
                return false;
            }

            if (!ngayKetThuc.isAfter(ngayBatDau)) {
                JOptionPane.showMessageDialog(this, "Ngày kết thúc phải lớn hơn ngày bắt đầu!");
                return false;
            }

            // Hợp lệ
            return true;

        } catch (Exception e) {
            JOptionPane.showMessageDialog(this,
                    "Vui lòng nhập ngày hợp lệ (Ngày-tháng-năm)!");
            return false;
        }
    }

    public boolean checkTonTai() {
        try {
            String ma = txt_ma.getText();

            if (ma == null || ma.trim().isEmpty()) {
                return false;
            }
            Voucher vc = repoVoucher.IDvoucher(ma);
            return vc != null;
        } catch (Exception ex) {
            ex.printStackTrace();
            return false;
        }
    }

    public boolean checktrong() {
        if (txt_tenchuuongtrinh.getText().isEmpty() || txt_batdau.getText().isEmpty() || txt_dieukien.getText().isEmpty() || txt_giatri.getText().isEmpty() || txt_ketthuc.getText().isEmpty() || txt_ma.getText().isBlank() || txt_soluong.getText().isEmpty() || rdo_gr_giamgia == null) {
            JOptionPane.showMessageDialog(this, "Không được để trống dữ liệu");
            return false;
        } else if (cbo_loaigiam.getSelectedItem().equals("%")) {
            if (txt_mucgiam.getText().isEmpty()) {
                JOptionPane.showMessageDialog(this, "Loại giảm % phải mức giảm tối đa, không được để trống");
                return false;
            }
        }
        return true;
    }

    public String randomCode(String prefix, int randomLength) {
        if (prefix == null) {
            prefix = "KH";
        }
        if (randomLength <= 0) {
            throw new IllegalArgumentException("Số ký tự random phải > 0");
        }
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        java.security.SecureRandom random = new java.security.SecureRandom();
        StringBuilder sb = new StringBuilder(prefix);
        for (int i = 0; i < randomLength; i++) {
            int idx = random.nextInt(chars.length());
            sb.append(chars.charAt(idx));
        }
        return sb.toString();
    }

    public boolean chechTrung() {
        for (Voucher V : repoVoucher.findAll()) {
            if (txt_ma.getText().equalsIgnoreCase(V.getMa_code_voucher())) {
                JOptionPane.showMessageDialog(this, "Mã đã tồn tại vui lòng tạo mã khác");
                return false;
            }
        }
        return true;
    }

    public void Lammoi() {
        txt_tenchuuongtrinh.setText("");
        txt_batdau.setText("");
        txt_dieukien.setText("");
        txt_giatri.setText("");
        txt_ketthuc.setText("");
        txt_ma.setText("");
        txt_mucgiam.setText("");
        txt_soluong.setText("");
        rdo_gr_giamgia.clearSelection();
    }

    public void hienthilabel() {
        // phần này là để làm tang defaultPadding cho lbl(Không chỉnh sửa nhé)
        // Đảm bảo label trong suốt

        lblsanpham.setBackground(null);
        lblsanpham.setOpaque(false);

        lblbanhang.setBackground(null);
        lblbanhang.setOpaque(false);

        lblgiamgia.setBackground(null);
        lblgiamgia.setOpaque(false);


        lblquanlykhachhang.setBackground(null);
        lblquanlykhachhang.setOpaque(false);

        lbldangnhap.setBackground(null);
        lbldangnhap.setOpaque(false);

        lbldangxuat.setBackground(null);
        lbldangxuat.setOpaque(false);
        // Padding Gốc (Lùi sâu vào 25px): Kích thước cố định.
        javax.swing.border.Border defaultPadding = javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10);
        lblsanpham.setBorder(defaultPadding);
        lblbanhang.setBorder(defaultPadding);
        lblgiamgia.setBorder(defaultPadding);
        lblquanlykhachhang.setBorder(defaultPadding);
        lbldangnhap.setBorder(defaultPadding);
        lbldangxuat.setBorder(defaultPadding);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rdo_gr_giamgia = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        lblquanlykhachhang = new javax.swing.JLabel();
        lblsanpham = new javax.swing.JLabel();
        lbldangnhap = new javax.swing.JLabel();
        lblbanhang = new javax.swing.JLabel();
        lblgiamgia = new javax.swing.JLabel();
        lbldangxuat = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txt_ma = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txt_mucgiam = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txt_dieukien = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txt_soluong = new javax.swing.JTextField();
        cbo_loaigiam = new javax.swing.JComboBox<>();
        jLabel7 = new javax.swing.JLabel();
        txt_giatri = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        rdo_hoatdong = new javax.swing.JRadioButton();
        rdo_ngung = new javax.swing.JRadioButton();
        btn_them = new javax.swing.JButton();
        btn_chinhsua = new javax.swing.JButton();
        btn_lammoi = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        txt_batdau = new javax.swing.JTextField();
        txt_ketthuc = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        btn_taoma = new javax.swing.JButton();
        btn_ngay = new javax.swing.JButton();
        btn_ngay1 = new javax.swing.JButton();
        jLabel12 = new javax.swing.JLabel();
        txt_tenchuuongtrinh = new javax.swing.JTextField();
        btn_xoa = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_giamgia = new javax.swing.JTable();
        btn_timkiem = new javax.swing.JButton();
        txt_timkiem = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        btn_lammoi_giam_gia = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(19, 0, 160));

        lblquanlykhachhang.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblquanlykhachhang.setForeground(new java.awt.Color(255, 255, 255));
        lblquanlykhachhang.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\KhachHang.png")); // NOI18N
        lblquanlykhachhang.setText("Quản lý khách hàng");
        lblquanlykhachhang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblquanlykhachhangMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblquanlykhachhangMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblquanlykhachhangMouseExited(evt);
            }
        });

        lblsanpham.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblsanpham.setForeground(new java.awt.Color(255, 255, 255));
        lblsanpham.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\quanlisanpham.png")); // NOI18N
        lblsanpham.setText("Quản lý sản phẩm");
        lblsanpham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblsanphamMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblsanphamMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblsanphamMouseExited(evt);
            }
        });

        lbldangnhap.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbldangnhap.setForeground(new java.awt.Color(255, 255, 255));
        lbldangnhap.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\dangnhap.png")); // NOI18N
        lbldangnhap.setText("Đăng nhập");
        lbldangnhap.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbldangnhapMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbldangnhapMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbldangnhapMouseExited(evt);
            }
        });

        lblbanhang.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblbanhang.setForeground(new java.awt.Color(255, 255, 255));
        lblbanhang.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\banhang.png")); // NOI18N
        lblbanhang.setText("Quản lý bán hàng");
        lblbanhang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblbanhangMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblbanhangMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblbanhangMouseExited(evt);
            }
        });

        lblgiamgia.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblgiamgia.setForeground(new java.awt.Color(255, 255, 255));
        lblgiamgia.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\giamgia.png")); // NOI18N
        lblgiamgia.setText("Giảm giá");
        lblgiamgia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblgiamgiaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblgiamgiaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblgiamgiaMouseExited(evt);
            }
        });

        lbldangxuat.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbldangxuat.setForeground(new java.awt.Color(255, 255, 255));
        lbldangxuat.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\dangxuat.png")); // NOI18N
        lbldangxuat.setText("Đăng xuất");
        lbldangxuat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbldangxuatMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbldangxuatMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbldangxuatMouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblsanpham, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblbanhang, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblgiamgia, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblquanlykhachhang, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
                    .addComponent(lbldangnhap, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbldangxuat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(42, 42, 42)
                .addComponent(lblsanpham, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblbanhang, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblgiamgia, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblquanlykhachhang, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbldangnhap, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbldangxuat, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(440, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 100, 190, 800);

        jPanel4.setBackground(new java.awt.Color(19, 0, 160));
        jPanel4.setPreferredSize(new java.awt.Dimension(1455, 143));

        jLabel1.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\LOGO(TO).png")); // NOI18N
        jLabel1.setText("jLabel1");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1511, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel4);
        jPanel4.setBounds(0, 0, 1500, 100);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setPreferredSize(new java.awt.Dimension(1300, 820));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Thêm phiếu giảm giá", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jLabel2.setText("Mã giảm giá:");

        jLabel3.setText("Mức giảm tối đa:");

        jLabel4.setText("Điều kiện giảm giá:");

        jLabel5.setText("Số lượng:");

        jLabel6.setText("Loại giảm giá:");

        cbo_loaigiam.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));

        jLabel7.setText("Giá trị giảm:");

        jLabel8.setText("Trạng thái:");

        rdo_gr_giamgia.add(rdo_hoatdong);
        rdo_hoatdong.setText("Hoạt động");

        rdo_gr_giamgia.add(rdo_ngung);
        rdo_ngung.setText("Ngừng hoạt động");

        btn_them.setBackground(new java.awt.Color(19, 0, 194));
        btn_them.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_them.setForeground(new java.awt.Color(255, 255, 255));
        btn_them.setText("Thêm");
        btn_them.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_themActionPerformed(evt);
            }
        });

        btn_chinhsua.setBackground(new java.awt.Color(19, 0, 194));
        btn_chinhsua.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_chinhsua.setForeground(new java.awt.Color(255, 255, 255));
        btn_chinhsua.setText("Chỉnh sửa");
        btn_chinhsua.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_chinhsuaActionPerformed(evt);
            }
        });

        btn_lammoi.setBackground(new java.awt.Color(19, 0, 194));
        btn_lammoi.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_lammoi.setForeground(new java.awt.Color(255, 255, 255));
        btn_lammoi.setText("Làm mới");
        btn_lammoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_lammoiActionPerformed(evt);
            }
        });

        jLabel9.setText("Ngày bắt đầu:");

        jLabel10.setText("Ngày kết thúc:");

        btn_taoma.setBackground(new java.awt.Color(19, 0, 194));
        btn_taoma.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_taoma.setForeground(new java.awt.Color(255, 255, 255));
        btn_taoma.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\Taomoi.png")); // NOI18N
        btn_taoma.setText("TẠO MA");
        btn_taoma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_taomaActionPerformed(evt);
            }
        });

        btn_ngay.setBackground(new java.awt.Color(19, 0, 194));
        btn_ngay.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_ngay.setForeground(new java.awt.Color(255, 255, 255));
        btn_ngay.setText("Lịch");
        btn_ngay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ngayActionPerformed(evt);
            }
        });

        btn_ngay1.setBackground(new java.awt.Color(19, 0, 194));
        btn_ngay1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_ngay1.setForeground(new java.awt.Color(255, 255, 255));
        btn_ngay1.setText("Lịch");
        btn_ngay1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ngay1ActionPerformed(evt);
            }
        });

        jLabel12.setText("Tên chương trình:");

        btn_xoa.setBackground(new java.awt.Color(19, 0, 194));
        btn_xoa.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_xoa.setForeground(new java.awt.Color(255, 255, 255));
        btn_xoa.setText("Xóa");
        btn_xoa.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_xoaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addContainerGap()
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3)
                            .addComponent(jLabel4)
                            .addComponent(jLabel8)
                            .addComponent(jLabel12))
                        .addGap(33, 33, 33)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                            .addComponent(txt_tenchuuongtrinh, javax.swing.GroupLayout.Alignment.TRAILING)
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                                .addComponent(rdo_hoatdong, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 34, Short.MAX_VALUE)
                                .addComponent(rdo_ngung))
                            .addComponent(txt_dieukien)
                            .addComponent(txt_mucgiam)
                            .addComponent(txt_ma))
                        .addGap(18, 18, 18)
                        .addComponent(btn_taoma)
                        .addGap(136, 136, 136)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel10))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txt_ketthuc, javax.swing.GroupLayout.DEFAULT_SIZE, 250, Short.MAX_VALUE)
                                    .addComponent(txt_batdau))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(btn_ngay, javax.swing.GroupLayout.PREFERRED_SIZE, 57, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(btn_ngay1, javax.swing.GroupLayout.PREFERRED_SIZE, 1, Short.MAX_VALUE)))
                            .addGroup(jPanel5Layout.createSequentialGroup()
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 79, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(jLabel7))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(txt_soluong)
                                    .addComponent(cbo_loaigiam, 0, 250, Short.MAX_VALUE)
                                    .addComponent(txt_giatri)))))
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(20, 20, 20)
                        .addComponent(btn_them)
                        .addGap(36, 36, 36)
                        .addComponent(btn_chinhsua)
                        .addGap(21, 21, 21)
                        .addComponent(btn_xoa)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_lammoi)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(4, 4, 4)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_ma, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(txt_soluong, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_taoma))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel12)
                    .addComponent(txt_tenchuuongtrinh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(cbo_loaigiam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_mucgiam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel7)
                        .addComponent(txt_giatri, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_dieukien, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel4)
                    .addComponent(jLabel9)
                    .addComponent(txt_batdau, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_ngay, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(21, 21, 21)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txt_ketthuc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(jLabel10)
                        .addComponent(btn_ngay1, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(rdo_hoatdong)
                        .addComponent(jLabel8)
                        .addComponent(rdo_ngung)))
                .addGap(46, 46, 46)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_them)
                    .addComponent(btn_chinhsua)
                    .addComponent(btn_lammoi)
                    .addComponent(btn_xoa))
                .addContainerGap(64, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Danh sách giảm giá", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        tbl_giamgia.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Tên chương trình", "Mã giảm giá", "Điều kiện giảm giá", "Số lượng", "Loại giảm giá", "Giá trị giảm", "Mức giảm tối đa", "Ngày bắt đầu", "Ngày kết thúc", "Trạng thái"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_giamgia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_giamgiaMouseClicked(evt);
            }
        });
        jScrollPane1.setViewportView(tbl_giamgia);

        btn_timkiem.setBackground(new java.awt.Color(19, 0, 194));
        btn_timkiem.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_timkiem.setForeground(new java.awt.Color(255, 255, 255));
        btn_timkiem.setText("Tìm kiếm");
        btn_timkiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_timkiemActionPerformed(evt);
            }
        });

        jLabel11.setText("Mã giảm giá | Tên chương trình giảm giá");

        btn_lammoi_giam_gia.setBackground(new java.awt.Color(19, 0, 194));
        btn_lammoi_giam_gia.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_lammoi_giam_gia.setForeground(new java.awt.Color(255, 255, 255));
        btn_lammoi_giam_gia.setText("Làm mới");
        btn_lammoi_giam_gia.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_lammoi_giam_giaActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(23, 23, 23)
                .addComponent(jLabel11)
                .addGap(29, 29, 29)
                .addComponent(txt_timkiem, javax.swing.GroupLayout.PREFERRED_SIZE, 250, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(btn_timkiem)
                .addGap(33, 33, 33)
                .addComponent(btn_lammoi_giam_gia)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addContainerGap(8, Short.MAX_VALUE)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1208, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel6Layout.createSequentialGroup()
                .addGap(11, 11, 11)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel11)
                    .addComponent(txt_timkiem, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_timkiem)
                    .addComponent(btn_lammoi_giam_gia))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 290, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(203, 203, 203)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(65, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(113, 113, 113)
                .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(66, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3);
        jPanel3.setBounds(0, 0, 1500, 900);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1455, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 875, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblsanphamMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblsanphamMouseEntered
        // TODO add your handling code here:
        lblsanpham.setBackground(new java.awt.Color(70, 130, 180));
        lblsanpham.setOpaque(true);
        lblsanpham.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblsanphamMouseEntered

    private void lblsanphamMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblsanphamMouseExited
        // TODO add your handling code here:
        lblsanpham.setBackground(null);
        lblsanpham.setOpaque(false);
    }//GEN-LAST:event_lblsanphamMouseExited

    private void lblbanhangMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblbanhangMouseEntered
        // TODO add your handling code here:
        lblbanhang.setBackground(new java.awt.Color(70, 130, 180));
        lblbanhang.setOpaque(true);
        lblbanhang.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblbanhangMouseEntered

    private void lblbanhangMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblbanhangMouseExited
        // TODO add your handling code here:
        lblbanhang.setBackground(null);
        lblbanhang.setOpaque(false);
    }//GEN-LAST:event_lblbanhangMouseExited

    private void lblgiamgiaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblgiamgiaMouseEntered
        // TODO add your handling code here:
        lblgiamgia.setBackground(new java.awt.Color(70, 130, 180));
        lblgiamgia.setOpaque(true);
        lblgiamgia.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblgiamgiaMouseEntered

    private void lblgiamgiaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblgiamgiaMouseExited
        // TODO add your handling code here:
        lblgiamgia.setBackground(null);
        lblgiamgia.setOpaque(false);
    }//GEN-LAST:event_lblgiamgiaMouseExited

    private void lblquanlykhachhangMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblquanlykhachhangMouseEntered
        // TODO add your handling code here:
        lblquanlykhachhang.setBackground(new java.awt.Color(70, 130, 180));
        lblquanlykhachhang.setOpaque(true);
        lblquanlykhachhang.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblquanlykhachhangMouseEntered

    private void lblquanlykhachhangMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblquanlykhachhangMouseExited
        // TODO add your handling code here:
        lblquanlykhachhang.setBackground(null);
        lblquanlykhachhang.setOpaque(false);
    }//GEN-LAST:event_lblquanlykhachhangMouseExited

    private void lbldangnhapMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangnhapMouseEntered
        // TODO add your handling code here:
        lbldangnhap.setBackground(new java.awt.Color(70, 130, 180));
        lbldangnhap.setOpaque(true);
        lbldangnhap.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lbldangnhapMouseEntered

    private void lbldangnhapMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangnhapMouseExited
        // TODO add your handling code here:
        lbldangnhap.setBackground(null);
        lbldangnhap.setOpaque(false);
    }//GEN-LAST:event_lbldangnhapMouseExited

    private void lbldangxuatMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangxuatMouseEntered
        // TODO add your handling code here:
        lbldangxuat.setBackground(new java.awt.Color(70, 130, 180));
        lbldangxuat.setOpaque(true);
        lbldangxuat.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lbldangxuatMouseEntered

    private void lbldangxuatMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangxuatMouseExited
        // TODO add your handling code here:
        lbldangxuat.setBackground(null);
        lbldangxuat.setOpaque(false);
    }//GEN-LAST:event_lbldangxuatMouseExited

    private void btn_chinhsuaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_chinhsuaActionPerformed
        // TODO add your handling code here:
        if (!checkTonTai()) {
            JOptionPane.showMessageDialog(this, "Mã Voucher: " + txt_ma.getText() + " Trong hệ thống!");
            return;
        }
        int yes = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn sửa hay không?");
        if (yes == JOptionPane.YES_OPTION) {
            if (checktrong()) {
                if (checkNgay()) {
                    this.update();
                    JOptionPane.showMessageDialog(this, "Đã sửa thành công");
                    Lammoi();
                }
            }
        }
    }//GEN-LAST:event_btn_chinhsuaActionPerformed

    private void btn_lammoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_lammoiActionPerformed
        // TODO add your handling code here:
        Lammoi();
    }//GEN-LAST:event_btn_lammoiActionPerformed

    private void lblsanphamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblsanphamMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_SAN_PHAM_NV form = new FORM_QUAN_LY_SAN_PHAM_NV();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblsanphamMouseClicked

    private void lblbanhangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblbanhangMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_BAN_HANG_NV form = new FORM_QUAN_LY_BAN_HANG_NV();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblbanhangMouseClicked

    private void lblgiamgiaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblgiamgiaMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_GIAM_GIA_NV form = new FORM_QUAN_LY_GIAM_GIA_NV();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblgiamgiaMouseClicked

    private void lblquanlykhachhangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblquanlykhachhangMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_KHACH_HANG_NV form = new FORM_QUAN_LY_KHACH_HANG_NV();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblquanlykhachhangMouseClicked

    private void lbldangnhapMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangnhapMouseClicked
        // TODO add your handling code here:
        FORM_DANG_NHAP form = new FORM_DANG_NHAP();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lbldangnhapMouseClicked

    private void tbl_giamgiaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_giamgiaMouseClicked
        // TODO add your handling code here:
        index = tbl_giamgia.getSelectedRow();
        this.edit();
    }//GEN-LAST:event_tbl_giamgiaMouseClicked

    private void btn_themActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_themActionPerformed
        // TODO add your handling code here:
        if (checktrong()) {
            if (checkNgay()) {
                if (chechTrung()) {
                    this.create();
                    JOptionPane.showMessageDialog(this, "Thêm thành công");
                    Lammoi();
                }
            }
        }
    }//GEN-LAST:event_btn_themActionPerformed

    private void btn_taomaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_taomaActionPerformed
        // TODO add your handling code here:
        txt_ma.setText(randomCode("VH00", 3));
    }//GEN-LAST:event_btn_taomaActionPerformed

    private void btn_timkiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_timkiemActionPerformed
        // TODO add your handling code here:
        fillToTable_timkiem();
    }//GEN-LAST:event_btn_timkiemActionPerformed

    private void btn_lammoi_giam_giaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_lammoi_giam_giaActionPerformed
        // TODO add your handling code here:
        txt_timkiem.setText("");
        fillToTable();
    }//GEN-LAST:event_btn_lammoi_giam_giaActionPerformed

    private void btn_ngayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ngayActionPerformed
        // TODO add your handling code here:
        // Tạo JCalendar
        JCalendar calendar = new JCalendar();
        calendar.setLocale(new Locale("vi", "VN"));
        // Nếu txt_batdau có giá trị cũ, set lại
        try {
            String text = txt_batdau.getText().trim();
            if (!text.isEmpty()) {
                java.util.Date d = new SimpleDateFormat("dd/MM/yyyy").parse(text);
                calendar.setDate(d);
            } else {
                // Mặc định tháng 1 năm hiện tại
                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.MONTH, 0);
                cal.set(Calendar.DAY_OF_MONTH, 1);
                calendar.setDate(cal.getTime());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        // Khi chọn ngày → set vào txt_batdau và đóng popup
        calendar.getDayChooser().addPropertyChangeListener("day", evt2 -> {
            java.util.Date utilDate = calendar.getDate();
            if (utilDate != null) {
                java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
                txt_batdau.setText(new SimpleDateFormat("dd-MM-yyyy").format(sqlDate));
                Window w = SwingUtilities.getWindowAncestor(calendar);
                if (w != null) {
                    w.dispose();
                }
            }
        });
        // Tạo popup dialog chỉ chứa JCalendar
        JDialog dialog = new JDialog((Frame) null, "Chọn ngày", true);
        dialog.setLayout(new BorderLayout());
        dialog.add(calendar, BorderLayout.CENTER);
        dialog.pack();
        // Căn giữa popup theo nút btn_ngay
        Point p = btn_ngay.getLocationOnScreen();
        int popupWidth = dialog.getWidth();
        int btnWidth = btn_ngay.getWidth();
        int x = p.x + (btnWidth / 2) - (popupWidth / 2); // căn giữa theo nút
        int y = p.y + btn_ngay.getHeight();               // ngay dưới nút
        dialog.setLocation(x, y);
        dialog.setVisible(true);
    }//GEN-LAST:event_btn_ngayActionPerformed

    private void btn_ngay1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ngay1ActionPerformed
        // TODO add your handling code here:
        // Tạo JCalendar
        JCalendar calendar = new JCalendar();
        calendar.setLocale(new Locale("vi", "VN"));
        // Nếu txt_batdau có giá trị cũ, set lại
        try {
            String text = txt_ketthuc.getText().trim();
            if (!text.isEmpty()) {
                java.util.Date d = new SimpleDateFormat("dd/MM/yyyy").parse(text);
                calendar.setDate(d);
            } else {
                // Mặc định tháng 1 năm hiện tại
                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.MONTH, 0);
                cal.set(Calendar.DAY_OF_MONTH, 1);
                calendar.setDate(cal.getTime());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        // Khi chọn ngày → set vào txt_batdau và đóng popup
        calendar.getDayChooser().addPropertyChangeListener("day", evt2 -> {
            java.util.Date utilDate = calendar.getDate();
            if (utilDate != null) {
                java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
                txt_ketthuc.setText(new SimpleDateFormat("dd-MM-yyyy").format(sqlDate));
                Window w = SwingUtilities.getWindowAncestor(calendar);
                if (w != null) {
                    w.dispose();
                }
            }
        });
        // Tạo popup dialog chỉ chứa JCalendar
        JDialog dialog = new JDialog((Frame) null, "Chọn ngày", true);
        dialog.setLayout(new BorderLayout());
        dialog.add(calendar, BorderLayout.CENTER);
        dialog.pack();
        // Căn giữa popup theo nút btn_ngay
        Point p = btn_ngay1.getLocationOnScreen();
        int popupWidth = dialog.getWidth();
        int btnWidth = btn_ngay1.getWidth();
        int x = p.x + (btnWidth / 2) - (popupWidth / 2); // căn giữa theo nút
        int y = p.y + btn_ngay1.getHeight();               // ngay dưới nút
        dialog.setLocation(x, y);
        dialog.setVisible(true);
    }//GEN-LAST:event_btn_ngay1ActionPerformed

    private void btn_xoaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_xoaActionPerformed
        // TODO add your handling code here:
        int yes = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn xóa voucher " + txt_ma.getText() + " Hay không");
        if (yes == JOptionPane.YES_OPTION) {
            Xoa();
            rdo_ngung.setSelected(true);
            JOptionPane.showMessageDialog(this, "Đã xóa thành công");
            Lammoi();
        }
    }//GEN-LAST:event_btn_xoaActionPerformed

    private void lbldangxuatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangxuatMouseClicked
        // TODO add your handling code here:
                int yes = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn thoát hay không?");
        if(yes == JOptionPane.YES_OPTION){
        System.exit(0);
        }
    }//GEN-LAST:event_lbldangxuatMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FORM_QUAN_LY_GIAM_GIA.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FORM_QUAN_LY_GIAM_GIA.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FORM_QUAN_LY_GIAM_GIA.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FORM_QUAN_LY_GIAM_GIA.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FORM_QUAN_LY_GIAM_GIA().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_chinhsua;
    private javax.swing.JButton btn_lammoi;
    private javax.swing.JButton btn_lammoi_giam_gia;
    private javax.swing.JButton btn_ngay;
    private javax.swing.JButton btn_ngay1;
    private javax.swing.JButton btn_taoma;
    private javax.swing.JButton btn_them;
    private javax.swing.JButton btn_timkiem;
    private javax.swing.JButton btn_xoa;
    private javax.swing.JComboBox<String> cbo_loaigiam;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JLabel lblbanhang;
    private javax.swing.JLabel lbldangnhap;
    private javax.swing.JLabel lbldangxuat;
    private javax.swing.JLabel lblgiamgia;
    private javax.swing.JLabel lblquanlykhachhang;
    private javax.swing.JLabel lblsanpham;
    private javax.swing.ButtonGroup rdo_gr_giamgia;
    private javax.swing.JRadioButton rdo_hoatdong;
    private javax.swing.JRadioButton rdo_ngung;
    private javax.swing.JTable tbl_giamgia;
    private javax.swing.JTextField txt_batdau;
    private javax.swing.JTextField txt_dieukien;
    private javax.swing.JTextField txt_giatri;
    private javax.swing.JTextField txt_ketthuc;
    private javax.swing.JTextField txt_ma;
    private javax.swing.JTextField txt_mucgiam;
    private javax.swing.JTextField txt_soluong;
    private javax.swing.JTextField txt_tenchuuongtrinh;
    private javax.swing.JTextField txt_timkiem;
    // End of variables declaration//GEN-END:variables

    @Override
    public void open() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void setForm(Voucher entity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Voucher getForm() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Voucher v = new Voucher();
        v.setTen_chuong_trinh_giam_gia(txt_tenchuuongtrinh.getText());
        v.setMa_code_voucher(txt_ma.getText());
        BigDecimal dieukien = fromVietnameseMoney(txt_dieukien.getText());
        BigDecimal giatri = fromVietnameseMoney(txt_giatri.getText());
        if (cbo_loaigiam.getSelectedItem().equals("Tien")) {

            v.setMuc_giam_toi_da(null);
        } else {
            BigDecimal mucgiam = fromVietnameseMoney(txt_mucgiam.getText());
            v.setMuc_giam_toi_da(mucgiam);
        }
        v.setDieu_kien(dieukien);
        v.setSo_luong(Integer.parseInt(txt_soluong.getText()));
        v.setLoai_giam_gia(cbo_loaigiam.getSelectedItem().toString());
        v.setGia_tri_giam(giatri);

        try {
            DateTimeFormatter inFmt = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            LocalDate DATENOWW = LocalDate.parse(txt_batdau.getText(), inFmt);
            Date DATENOW = java.sql.Date.valueOf(DATENOWW);
            v.setNgay_bat_dau(DATENOW);

            LocalDate DATEENDD = LocalDate.parse(txt_ketthuc.getText(), inFmt);
            Date DATEEND = java.sql.Date.valueOf(DATEENDD);
            v.setNgay_ket_thuc(DATEEND);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Ngày không hợp lệ! Vui lòng nhập theo định dạng: dd-MM-yyyy");
            return null;
        }

        return v;
    }

    public Voucher XOAVC() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Voucher v = new Voucher();
        v.setMa_code_voucher(txt_ma.getText());
        return v;

    }

    public String toVietnameseMoney(BigDecimal value) {
        if (value == null) {
            return "0";
        }
        Locale locale = new Locale("vi", "VN");
        NumberFormat formatter = NumberFormat.getCurrencyInstance(locale);
        return formatter.format(value);
    }

    public BigDecimal fromVietnameseMoney(String text) {
        if (text == null || text.trim().isEmpty()) {
            return BigDecimal.ZERO;
        }

        String cleaned = text.replaceAll("[^0-9-]", "");

        if (cleaned.isEmpty()) {
            return BigDecimal.ZERO;
        }

        return new BigDecimal(cleaned);
    }

    public Voucher getForm_update() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Voucher v = new Voucher();
        Voucher id = repoVoucher.IDvoucher(txt_ma.getText());
        v.setTen_chuong_trinh_giam_gia(txt_tenchuuongtrinh.getText());
        v.setID_voucher(id.getID_voucher());
        v.setMa_code_voucher(txt_ma.getText());
        BigDecimal dieukien = fromVietnameseMoney(txt_dieukien.getText());
        BigDecimal giatri = fromVietnameseMoney(txt_giatri.getText());
        if (cbo_loaigiam.getSelectedItem().equals("Tien")) {

            v.setMuc_giam_toi_da(null);
        } else {
            BigDecimal mucgiam = fromVietnameseMoney(txt_mucgiam.getText());
            v.setMuc_giam_toi_da(mucgiam);
        }
        v.setDieu_kien(dieukien);
        v.setSo_luong(Integer.parseInt(txt_soluong.getText()));
        v.setLoai_giam_gia(cbo_loaigiam.getSelectedItem().toString());
        v.setGia_tri_giam(giatri);
        try {
            DateTimeFormatter inFmt = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            LocalDate DATENOWW = LocalDate.parse(txt_batdau.getText(), inFmt);
            Date DATENOW = java.sql.Date.valueOf(DATENOWW);
            v.setNgay_bat_dau(DATENOW);

            LocalDate DATEENDD = LocalDate.parse(txt_ketthuc.getText(), inFmt);
            Date DATEEND = java.sql.Date.valueOf(DATEENDD);
            v.setNgay_ket_thuc(DATEEND);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Ngày không hợp lệ! Vui lòng nhập theo định dạng: dd-MM-yyyy");
            return null;
        }
        v.setTrang_thai(rdo_hoatdong.isSelected());
        return v;
    }

    @Override
    public void fillToTable() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        SimpleDateFormat fm = new SimpleDateFormat("dd-MM-yyyy");

        Modelvoucher = (DefaultTableModel) tbl_giamgia.getModel();
        Modelvoucher.setRowCount(0);
        for (Voucher v : repoVoucher.findAll()) {
            Object[] Data = new Object[]{
                v.getTen_chuong_trinh_giam_gia(), v.getMa_code_voucher(), toVietnameseMoney(v.getDieu_kien()), v.getSo_luong(), v.getLoai_giam_gia(), toVietnameseMoney(v.getGia_tri_giam()), toVietnameseMoney(v.getMuc_giam_toi_da()), fm.format(v.getNgay_bat_dau()), fm.format(v.getNgay_ket_thuc()), v.hoatdong(v.isTrang_thai())
            };
            Modelvoucher.addRow(Data);
        }
    }
    public void fillToTable_timkiem() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        SimpleDateFormat fm = new SimpleDateFormat("dd-MM-yyyy");

        Modelvoucher = (DefaultTableModel) tbl_giamgia.getModel();
        Modelvoucher.setRowCount(0);
        for (Voucher v : repoVoucher.Tim(txt_timkiem.getText())) {
            Object[] Data = new Object[]{
                v.getTen_chuong_trinh_giam_gia(), v.getMa_code_voucher(), toVietnameseMoney(v.getDieu_kien()), v.getSo_luong(), v.getLoai_giam_gia(), toVietnameseMoney(v.getGia_tri_giam()), toVietnameseMoney(v.getMuc_giam_toi_da()), fm.format(v.getNgay_bat_dau()), fm.format(v.getNgay_ket_thuc()), v.hoatdong(v.isTrang_thai())
            };
            Modelvoucher.addRow(Data);
        }
    }
    @Override
    public void edit() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        txt_tenchuuongtrinh.setText(tbl_giamgia.getValueAt(index, 0).toString());
        txt_ma.setText(tbl_giamgia.getValueAt(index, 1).toString());
        txt_dieukien.setText(tbl_giamgia.getValueAt(index, 2).toString());
        txt_soluong.setText(tbl_giamgia.getValueAt(index, 3).toString());
        cbo_loaigiam.setSelectedItem(tbl_giamgia.getValueAt(index, 4));
        txt_giatri.setText(tbl_giamgia.getValueAt(index, 5).toString());
        if (tbl_giamgia.getValueAt(index, 6) == null) {
            txt_mucgiam.setText("");
        } else {
            txt_mucgiam.setText(String.valueOf(tbl_giamgia.getValueAt(index, 6)));
        }
        txt_batdau.setText(tbl_giamgia.getValueAt(index, 7).toString());
        txt_ketthuc.setText(tbl_giamgia.getValueAt(index, 8).toString());
        if (tbl_giamgia.getValueAt(index, 9).toString().equalsIgnoreCase("Hoạt động")) {
            rdo_hoatdong.setSelected(true);
        } else {
            rdo_ngung.setSelected(true);
        }
    }

    @Override
    public void create() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Voucher v = this.getForm();
        repoVoucher.create(v);
        this.fillToTable();
    }

    @Override
    public void update() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Voucher v = this.getForm_update();
        repoVoucher.update(v);
        this.fillToTable();
    }

    public void Xoa() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Voucher v = XOAVC();
        repoVoucher.Xoa(v);
        this.fillToTable();
    }

    @Override
    public void delete() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void clear() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void setEditable(boolean editable) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void checkAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void uncheckAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deleteCheckedItems() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void moveFirst() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void movePrevious() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void moveNext() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void moveLast() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void moveTo(int rowIndex) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
