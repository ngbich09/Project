/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ui;

import com.toedter.calendar.JCalendar;
import controller.Khachhang_CRUD;
import daoipml.Khachhang_DAOIpml;
import entity.Khachhang;
import java.awt.BorderLayout;
import java.awt.Frame;
import java.awt.Point;
import java.awt.Window;
import java.text.SimpleDateFormat;
import javax.swing.JOptionPane;
import java.sql.Date;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Calendar;
import java.util.Locale;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.SwingUtilities;

/**
 *
 * @author manhh
 */
public class FORM_THEM_KHACH_BAN_HANG extends javax.swing.JFrame implements Khachhang_CRUD {

    private Khachhang_DAOIpml RepoKH = new Khachhang_DAOIpml();

    /**
     * Creates new form Form_THEM_KHACH_BAN_HANG
     */
    public FORM_THEM_KHACH_BAN_HANG() {
        initComponents();
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
    }

    public boolean checkValidateForm() {
        // 1. Kiểm tra Mã khách hàng
        if (txt_maKH.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập mã khách hàng!");
            txt_maKH.requestFocus();
            return false;
        }

        // 2. Kiểm tra Tên khách hàng
        String tenKH = txt_hoten.getText().trim();
        if (txt_hoten.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập họ tên khách hàng!");
            txt_hoten.requestFocus();
            return false;
        }
//        giới hạn tên khách hàng không quá 255 ký tự
        if (tenKH.length() > 255) {
            JOptionPane.showMessageDialog(this, "Tên khách hàng không được quá 255 ký tự!");
            txt_hoten.requestFocus();
            return false;
        }

        // 3. Kiểm tra Email (Định dạng)
        String email = txt_email.getText().trim();
        if (email.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập Email!");
            txt_email.requestFocus();
            return false;
        }
//         Dạng chuỗi@chuỗi.chuỗi(quy tắc đẻ định dạng 1 hàm email đúng)
        String emailRegex = "\\S+@\\S+\\.\\S+";
        // kiểm tra nếu email không khớp với quy tắc ở trên
        if (!email.matches(emailRegex)) {
            JOptionPane.showMessageDialog(this, "Email không hợp lệ (VD:abc@abc.vn)!");
            txt_email.requestFocus();
            return false;
        }
        // Danh sách các đuôi email hợp lệ mà bạn chấp nhận
        boolean emailHopLe = false;
        // Kiểm tra xem email có kết thúc bằng 1 trong các đuôi chuẩn không
        if (email.endsWith("@gmail.com")
                || email.endsWith("@fpt.edu.vn")
                || email.endsWith("@outlook.com")
                || email.endsWith("@icloud.com")
                || email.endsWith("@edu.vn")
                || email.endsWith("@hotmail.com")) {
            emailHopLe = true;
        }

// Nếu không khớp với bất kỳ đuôi nào ở trên -> Báo lỗi
        if (!emailHopLe) {
            JOptionPane.showMessageDialog(this,
                    "Email sai định dạng hoặc thiếu ký tự!");
            txt_email.requestFocus();
            return false;
        }

// Kiểm tra kỹ hơn: Không được phép gõ 2 lần @ (VD: abc@gmail.com@fpt.edu.vn)
        int countAt = email.length() - email.replace("@", "").length();
        if (countAt > 1) {
            JOptionPane.showMessageDialog(this, "Email không được chứa nhiều hơn 1 ký tự @");
            txt_email.requestFocus();
            return false;
        }

// 4. Kiểm tra SĐT (Định dạng)
        String sdt = txt_sdt.getText();
        if (sdt.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập số điện thoại!");
            txt_sdt.requestFocus();
            return false;
        }
//         số điện thoại phải đúng định dạng là số và đủ 10 số
        if (!sdt.matches("\\d{10}")) {
            JOptionPane.showMessageDialog(this, "Số điện thoại phải là số và có 10 số ");
            txt_sdt.requestFocus();
            return false;
        }
//        số điện thoại phải bắt đầu bằng số 0
        if (!sdt.startsWith("0")) {
            JOptionPane.showMessageDialog(this, " số điện thoại bắt đầu bằng số 0");
            txt_sdt.requestFocus();
            return false;
        }

        // 5. Kiểm tra Giới tính
        if (!rdo_nam.isSelected() && !rdo_nu.isSelected()) {
            JOptionPane.showMessageDialog(this, "Vui lòng chọn giới tính!");
            return false;
        }

        // 6. Kiểm tra Địa chỉ
        String diaChi = txt_diachi.getText().trim();
        if (txt_diachi.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập địa chỉ!");
            txt_diachi.requestFocus();
            return false;
        }
//        giới hạn ký tự địa chỉ không quá 255 ký tự
        if (diaChi.length() > 255) {
            JOptionPane.showMessageDialog(this, "Địa chỉ không được quá 255 ký tự!");
            txt_diachi.requestFocus();
            return false;
        }
        // 7. Kiểm tra Ngày sinh
        if (txt_ngaysinh.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập ngày sinh!");
            txt_ngaysinh.requestFocus();
            return false;
        }
        try {
            // khuôn mẫu kiểu ngày tháng năm dd-MM-yyyy(01-01-2000)
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            // lấy dữ liệu từ ô ngày sinh và ép kiểu đúng khuôn mẫu
            LocalDate ngaySinh = LocalDate.parse(txt_ngaysinh.getText().trim(), formatter);
            // lấy ngày tháng năm của hiện tại(bao gồm cả thời gian)
            LocalDate homNay = LocalDate.now();

            if (ngaySinh.isAfter(homNay)) { // ngày sinh có nằm sau ngày hôm nay không
                JOptionPane.showMessageDialog(this, "Ngày,tháng,năm không được ở tương lai!");
                txt_ngaysinh.requestFocus();
                return false;
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Sai định dạng ngày sinh (dd-MM-yyyy)!");
            txt_ngaysinh.requestFocus();
            return false;
        }

        return true; // Tất cả định dạng đều OK
    }

    public boolean checkTrungCreate() {
        String email = txt_email.getText();
        String sdt = txt_sdt.getText();
        for (Khachhang KH : RepoKH.findAll()) {
            if (KH.getEmail().equalsIgnoreCase(email)) {
                JOptionPane.showMessageDialog(this, "Eamil đã tồn tại, vui lòng thay đổi email!");
                return false;
            } else if (KH.getSDT().equalsIgnoreCase(sdt)) {
                JOptionPane.showMessageDialog(this, "Số điện thoại đã tồn tại, vui lòng thay đổi Số điện thoại!");
                return false;
            }
        }
        return true;
    }

    public String randomCode(String prefix, int randomLength) {
        if (prefix == null) {
            prefix = "KH";
        }
        if (randomLength <= 0) {
            throw new IllegalArgumentException("Số ký tự random phải > 0");
        }
        String chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
        java.security.SecureRandom random = new java.security.SecureRandom();
        StringBuilder sb = new StringBuilder(prefix);
        for (int i = 0; i < randomLength; i++) {
            int idx = random.nextInt(chars.length());
            sb.append(chars.charAt(idx));
        }
        return sb.toString();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rdo_gr = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        txt_maKH = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        txt_hoten = new javax.swing.JTextField();
        jLabel3 = new javax.swing.JLabel();
        txt_email = new javax.swing.JTextField();
        txt_diachi = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        txt_ngaysinh = new javax.swing.JTextField();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txt_sdt = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        rdo_nam = new javax.swing.JRadioButton();
        rdo_nu = new javax.swing.JRadioButton();
        btn_them = new javax.swing.JButton();
        btn_huy = new javax.swing.JButton();
        btn_taoma = new javax.swing.JButton();
        btn_ngay = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Thêm khách hàng", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jLabel1.setText("Mã khách hàng:");

        jLabel2.setText("Họ tên khách hàng:");

        jLabel3.setText("Email:");

        jLabel4.setText("Địa chỉ:");

        jLabel5.setText("Ngày sinh:");

        jLabel6.setText("Số điện thoại:");

        jLabel7.setText("Giới Tính");

        rdo_gr.add(rdo_nam);
        rdo_nam.setText("Nam");

        rdo_gr.add(rdo_nu);
        rdo_nu.setText("Nữ");

        btn_them.setBackground(new java.awt.Color(19, 0, 194));
        btn_them.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_them.setForeground(new java.awt.Color(255, 255, 255));
        btn_them.setText("THÊM KHÁCH HÀNG");
        btn_them.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_themActionPerformed(evt);
            }
        });

        btn_huy.setBackground(new java.awt.Color(19, 0, 194));
        btn_huy.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_huy.setForeground(new java.awt.Color(255, 255, 255));
        btn_huy.setText("HỦY");
        btn_huy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_huyActionPerformed(evt);
            }
        });

        btn_taoma.setBackground(new java.awt.Color(19, 0, 194));
        btn_taoma.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_taoma.setForeground(new java.awt.Color(255, 255, 255));
        btn_taoma.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\Taomoi.png")); // NOI18N
        btn_taoma.setText("TẠO MÃ");
        btn_taoma.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_taomaActionPerformed(evt);
            }
        });

        btn_ngay.setBackground(new java.awt.Color(19, 0, 194));
        btn_ngay.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_ngay.setForeground(new java.awt.Color(255, 255, 255));
        btn_ngay.setText("LỊCH");
        btn_ngay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ngayActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(29, 29, 29)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel1)
                    .addComponent(jLabel2)
                    .addComponent(jLabel3)
                    .addComponent(jLabel4))
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txt_maKH, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                        .addComponent(btn_taoma))
                    .addComponent(txt_diachi, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_email, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_hoten, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel6)
                    .addComponent(jLabel7)
                    .addComponent(jLabel5))
                .addGap(28, 28, 28)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(rdo_nam, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(rdo_nu, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(txt_sdt, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(txt_ngaysinh, javax.swing.GroupLayout.PREFERRED_SIZE, 190, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_ngay)))
                .addGap(30, 30, 30))
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(236, 236, 236)
                .addComponent(btn_them)
                .addGap(18, 18, 18)
                .addComponent(btn_huy, javax.swing.GroupLayout.PREFERRED_SIZE, 174, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(35, 35, 35)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txt_maKH, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel5)
                    .addComponent(txt_ngaysinh, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_taoma, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_ngay))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_hoten, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel6)
                    .addComponent(txt_sdt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel3)
                    .addComponent(txt_email, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7)
                    .addComponent(rdo_nam)
                    .addComponent(rdo_nu))
                .addGap(20, 20, 20)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jLabel4)
                    .addComponent(txt_diachi, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(50, 50, 50)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btn_them)
                    .addComponent(btn_huy))
                .addContainerGap(184, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(20, 20, 20)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(22, Short.MAX_VALUE))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void btn_themActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_themActionPerformed
        // TODO add your handling code here:
        if (!checkValidateForm()) {
            return; // Dừng lại nếu from sai
        }
        if (!checkTrungCreate()) {
            return;// dừng lại nếu bị trùng
        }
        // 2. Thực hiện thêm mới
        try {
            this.create();
            javax.swing.JOptionPane.showMessageDialog(this, "Thêm khách hàng thành công!");
            this.dispose();
        } catch (Exception e) {
            e.printStackTrace();
            JOptionPane.showMessageDialog(this, "Lỗi thêm dữ liệu: ");
        }
    }//GEN-LAST:event_btn_themActionPerformed

    private void btn_huyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_huyActionPerformed
        // TODO add your handling code here:
        System.exit(0);
    }//GEN-LAST:event_btn_huyActionPerformed

    private void btn_ngayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ngayActionPerformed
        // TODO add your handling code here:
        // TODO add your handling code here:
        // Tạo JCalendar
        JCalendar calendar = new JCalendar();
        calendar.setLocale(new Locale("vi", "VN"));
        // Nếu txt_batdau có giá trị cũ, set lại
        try {
            String text = txt_ngaysinh.getText().trim();
            if (!text.isEmpty()) {
                java.util.Date d = new SimpleDateFormat("dd-MM-yyyy").parse(text);
                calendar.setDate(d);
            } else {
                // Mặc định tháng 1 năm hiện tại
                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.MONTH, 0);
                cal.set(Calendar.DAY_OF_MONTH, 1);
                calendar.setDate(cal.getTime());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        // Khi chọn ngày → set vào txt_batdau và đóng popup
        calendar.getDayChooser().addPropertyChangeListener("day", evt2 -> {
            java.util.Date utilDate = calendar.getDate();
            if (utilDate != null) {
                java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
                txt_ngaysinh.setText(new SimpleDateFormat("dd-MM-yyyy").format(sqlDate));
                Window w = SwingUtilities.getWindowAncestor(calendar);
                if (w != null) {
                    w.dispose();
                }
            }
        });
        // Tạo popup dialog chỉ chứa JCalendar
        JDialog dialog = new JDialog((Frame) null, "Chọn ngày", true);
        dialog.setLayout(new BorderLayout());
        dialog.add(calendar, BorderLayout.CENTER);
        dialog.pack();
        // Căn giữa popup theo nút btn_ngay
        Point p = btn_ngay.getLocationOnScreen();
        int popupWidth = dialog.getWidth();
        int btnWidth = btn_ngay.getWidth();
        int x = p.x + (btnWidth / 2) - (popupWidth / 2); // căn giữa theo nút
        int y = p.y + btn_ngay.getHeight();               // ngay dưới nút
        dialog.setLocation(x, y);
        dialog.setVisible(true);
    }//GEN-LAST:event_btn_ngayActionPerformed

    private void btn_taomaActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_taomaActionPerformed
        // TODO add your handling code here:
        txt_maKH.setText(randomCode("KH00", 3));
    }//GEN-LAST:event_btn_taomaActionPerformed

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FORM_THEM_KHACH_BAN_HANG.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FORM_THEM_KHACH_BAN_HANG.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FORM_THEM_KHACH_BAN_HANG.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FORM_THEM_KHACH_BAN_HANG.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FORM_THEM_KHACH_BAN_HANG().setVisible(true);
            }
        });
    }

    public boolean Check() {
        if (txt_maKH.getText().trim().isEmpty() || txt_hoten.getText().trim().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui lòng nhập Mã và Tên khách hàng!");
            return false;
        }
        String ngaySinh = txt_ngaysinh.getText().trim();
        if (ngaySinh.isEmpty()) {
            JOptionPane.showMessageDialog(this, "Không được để trống ngày sinh");
            return false;
        }
        return true;
    }
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_huy;
    private javax.swing.JButton btn_ngay;
    private javax.swing.JButton btn_taoma;
    private javax.swing.JButton btn_them;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JPanel jPanel1;
    private javax.swing.ButtonGroup rdo_gr;
    private javax.swing.JRadioButton rdo_nam;
    private javax.swing.JRadioButton rdo_nu;
    private javax.swing.JTextField txt_diachi;
    private javax.swing.JTextField txt_email;
    private javax.swing.JTextField txt_hoten;
    private javax.swing.JTextField txt_maKH;
    private javax.swing.JTextField txt_ngaysinh;
    private javax.swing.JTextField txt_sdt;
    // End of variables declaration//GEN-END:variables

    @Override
    public void open() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void setForm(Khachhang entity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Khachhang getForm() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Khachhang Kh = new Khachhang();

        Kh.setMa_khach_hang(txt_maKH.getText().trim());
        Kh.setTen_khach_hang(txt_hoten.getText().trim());
        Kh.setEmail(txt_email.getText().trim());
        Kh.setDia_chi(txt_diachi.getText().trim());
        Kh.setSDT(txt_sdt.getText().trim());
        String gioiTinh = rdo_nam.isSelected() ? "Nam" : "Nữ";
        Kh.setGioi_tinh(gioiTinh);
        String maNV = Session.getMaTaiKhoan();
        Kh.setMa_nguoi_tao(maNV);
//        ép lại ngày để vào sql
        String ngaySinh = txt_ngaysinh.getText().trim();
        try {
            DateTimeFormatter inFmt = DateTimeFormatter.ofPattern("dd-MM-yyyy");
            LocalDate date = LocalDate.parse(ngaySinh, inFmt);
            Date DATE = java.sql.Date.valueOf(date);
            Kh.setNgay_sinh(DATE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Ngày không hợp lệ! Vui lòng nhập theo định dạng: dd-MM-yyyy");
            return null;
        }
        return Kh;
    }

    @Override
    public void fillToTable() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void edit() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void create() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Khachhang Kh = this.getForm();
        if (Kh == null) {
            return;
        }
        RepoKH.create(Kh);
    }

    @Override
    public void update() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void delete() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void clear() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void setEditable(boolean editable) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void checkAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void uncheckAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deleteCheckedItems() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void moveFirst() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void movePrevious() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void moveNext() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void moveLast() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void moveTo(int rowIndex) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
