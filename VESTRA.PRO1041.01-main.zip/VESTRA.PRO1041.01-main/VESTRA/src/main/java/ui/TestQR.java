/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package ui;

/**
 *
 * @author manhh
 */


;
public class TestQR {
    public static void main(String[] args) {
        QRHELPME.QRTAO("SP006-L-B", "J:\\Vestra_HN2025\\QR", "VESTRA");
    }
}
