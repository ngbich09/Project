/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ui;

import com.toedter.calendar.JCalendar;
import controller.CrudController;
import daoipml.DoanhThuThang_DAOipml;
import daoipml.Hoadon_DAOIpml;
import daoipml.Thongke_DAOIpml;
import entity.DoanhThuThang;
import entity.Hoadon;
import entity.Sanphambanchay;
import java.awt.BorderLayout;
//import entity.SanPhamBanChay;
import java.awt.Cursor;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.List;
import javax.swing.BorderFactory;
import javax.swing.table.DefaultTableModel;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PlotOrientation;
import org.jfree.data.category.DefaultCategoryDataset;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Frame;
import java.awt.Point;
import java.awt.Window;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Locale;
import javax.swing.DefaultComboBoxModel;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.SwingUtilities;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.axis.NumberAxis;
import org.jfree.chart.labels.StandardCategoryItemLabelGenerator;
import org.jfree.chart.plot.CategoryPlot;
import org.jfree.chart.renderer.category.BarRenderer;
import org.jfree.data.general.DefaultPieDataset;

/**
 *
 * @author manhh
 */
public class FORM_BAO_THONG_KE extends javax.swing.JFrame implements dao.DoanhThuThang_DAO {

    private DoanhThuThang_DAOipml repoTK = new DoanhThuThang_DAOipml();
    Thongke_DAOIpml repo1 = new Thongke_DAOIpml();

    /**
     * Creates new form FROM_THONGKE
     */
    public FORM_BAO_THONG_KE() {
        initComponents();
        hienthilabel();
        rdo_bang.setSelected(true);
        fillCboNam();
        fillDoanhThu();
        fillCards();
        fillTableSanPhamBanChay(null, null);
        initCboThoiGian();
        cbo_thoigian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbo_thoigianActionPerformed(evt);
            }
        });
        this.setLocationRelativeTo(null);
    }

    private void fillCards() {
        if (cbo_nam.getSelectedItem() == null) {
            return;
        }
        int nam = (Integer) cbo_nam.getSelectedItem();
        java.time.LocalDate now = java.time.LocalDate.now();
        int thangHienTai = now.getMonthValue();
        String today = now.toString();
        List<DoanhThuThang> listNam = repoTK.getDoanhThuByNam(nam);
        BigDecimal tienCaNam = BigDecimal.ZERO;
        int donHangCaNam = 0;
        BigDecimal tienThangNay = BigDecimal.ZERO;
        int donHangThangNay = 0;
        if (listNam != null) {
            for (DoanhThuThang dt : listNam) {
                if (dt.getDoanhThu() != null) {
                    tienCaNam = tienCaNam.add(dt.getDoanhThu());
                }
                donHangCaNam += dt.getSoDonHang();
                if (dt.getThang() == thangHienTai) {
                    if (dt.getDoanhThu() != null) {
                        tienThangNay = dt.getDoanhThu();
                    }
                    donHangThangNay = dt.getSoDonHang();
                }
            }
        }
        List<DoanhThuThang> listHomNay = repoTK.getDoanhThuByDateRange(today, today);
        BigDecimal tienHomNay = BigDecimal.ZERO;
        int donHangHomNay = 0;
        if (listHomNay != null) {
            for (DoanhThuThang x : listHomNay) {
                if (x.getDoanhThu() != null) {
                    tienHomNay = tienHomNay.add(x.getDoanhThu());
                }
                donHangHomNay += x.getSoDonHang();
            }
        }
        txt_soluong1.setText(String.valueOf(donHangHomNay));
        txt_doanhthu2.setText(formatMoney(tienHomNay));
        txt_soluong3.setText(String.valueOf(donHangThangNay));
        txt_doanhthu3.setText(formatMoney(tienThangNay));
        if (donHangThangNay > 0) {
            BigDecimal aov = tienThangNay.divide(new BigDecimal(donHangThangNay), 0, RoundingMode.HALF_UP);
            txt_aov3.setText(formatMoney(aov));
        } else {
            txt_aov3.setText("0 đ");
        }
        txt_soluong4.setText(String.valueOf(donHangCaNam));
        txt_doanhthu4.setText(formatMoney(tienCaNam));
    }

    private String formatMoney(BigDecimal value) {
        if (value == null) {
            return "0 đ";
        }
        java.text.NumberFormat nf = java.text.NumberFormat.getInstance(new java.util.Locale("vi", "VN"));
        nf.setMaximumFractionDigits(0);
        return nf.format(value) + " đ";
    }

    public void hienthilabel() {
        // phần này là để làm tang defaultPadding cho lbl(Không chỉnh sửa nhé)
        // Đảm bảo label trong suốt
        lblBaoCaoThongKe.setBackground(null);
        lblBaoCaoThongKe.setOpaque(false);

        lblsanpham.setBackground(null);
        lblsanpham.setOpaque(false);

        lblbanhang.setBackground(null);
        lblbanhang.setOpaque(false);

        lblgiamgia.setBackground(null);
        lblgiamgia.setOpaque(false);

        lblhoadon.setBackground(null);
        lblhoadon.setOpaque(false);

        lblnhanvien.setBackground(null);
        lblnhanvien.setOpaque(false);

        lblquanlykhachhang.setBackground(null);
        lblquanlykhachhang.setOpaque(false);

        lbldangnhap.setBackground(null);
        lbldangnhap.setOpaque(false);

        lbldangxuat.setBackground(null);
        lbldangxuat.setOpaque(false);
        // Padding Gốc (Lùi sâu vào 25px): Kích thước cố định.
        javax.swing.border.Border defaultPadding = javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10);
        lblBaoCaoThongKe.setBorder(defaultPadding);
        lblsanpham.setBorder(defaultPadding);
        lblbanhang.setBorder(defaultPadding);
        lblgiamgia.setBorder(defaultPadding);
        lblhoadon.setBorder(defaultPadding);
        lblnhanvien.setBorder(defaultPadding);
        lblquanlykhachhang.setBorder(defaultPadding);
        lbldangnhap.setBorder(defaultPadding);
        lbldangxuat.setBorder(defaultPadding);

    }

    private void showBieuDo() {
        // 1. Kiểm tra năm
        if (cbo_nam.getSelectedItem() == null) {
            return;
        }
        int nam = (Integer) cbo_nam.getSelectedItem();

        // 2. Tạo dataset
        DefaultCategoryDataset dataset = new DefaultCategoryDataset();

        // Reset 12 tháng về 0
        for (int i = 1; i <= 12; i++) {
            dataset.setValue(0, "Doanh thu", "T" + i);
        }

        // 3. Đổ dữ liệu thật
        List<DoanhThuThang> list = repoTK.getDoanhThuByNam(nam);
        if (list != null) {
            for (DoanhThuThang dt : list) {
                Number value = (dt.getDoanhThu() == null) ? 0 : dt.getDoanhThu();
                dataset.setValue(value, "Doanh thu", "T" + dt.getThang());
            }
        }

        // 4. Tạo biểu đồ
        JFreeChart chart = ChartFactory.createBarChart(
                "BIỂU ĐỒ DOANH THU NĂM " + nam,
                "Tháng", "Doanh thu (đ)",
                dataset,
                PlotOrientation.VERTICAL, false, true, false
        );

        // --- CẤU HÌNH GIAO DIỆN ---
        CategoryPlot plot = chart.getCategoryPlot();
        plot.setBackgroundPaint(Color.WHITE);
        plot.setRangeGridlinePaint(Color.GRAY);

        // A. Xử lý Trục Tiền (Y-Axis)
        NumberAxis rangeAxis = (NumberAxis) plot.getRangeAxis();
        rangeAxis.setStandardTickUnits(NumberAxis.createIntegerTickUnits());
        rangeAxis.setNumberFormatOverride(new DecimalFormat("#,###"));

        // B. Xử lý Cột (BarRenderer)
        BarRenderer renderer = (BarRenderer) plot.getRenderer();

        // --- THAY ĐỔI 1: Đổi màu cột thành MÀU ĐỎ ---
        renderer.setSeriesPaint(0, Color.RED);

        StandardCategoryItemLabelGenerator generator = new StandardCategoryItemLabelGenerator(
                "{2}", new DecimalFormat("#,###")
        );

        // 5. Hiển thị
        ChartPanel chartPanel = new ChartPanel(chart);

        // --- THAY ĐỔI 2: Giảm chiều cao xuống còn 200 ---
        Dimension size = new Dimension(1000, 200); // Đã sửa chiều cao

        chartPanel.setPreferredSize(size);
        jScrollPane1.setPreferredSize(size);

        jScrollPane1.setViewportView(chartPanel);
        jScrollPane1.revalidate();
        jScrollPane1.repaint();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rdo_gr_hien_thi = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        lblquanlykhachhang = new javax.swing.JLabel();
        lblsanpham = new javax.swing.JLabel();
        lbldangnhap = new javax.swing.JLabel();
        lblbanhang = new javax.swing.JLabel();
        lblnhanvien = new javax.swing.JLabel();
        lblhoadon = new javax.swing.JLabel();
        lblgiamgia = new javax.swing.JLabel();
        lblBaoCaoThongKe = new javax.swing.JLabel();
        lbldangxuat = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        jLabel3 = new javax.swing.JLabel();
        txt_soluong1 = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jPanel6 = new javax.swing.JPanel();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        txt_doanhthu2 = new javax.swing.JTextField();
        jLabel13 = new javax.swing.JLabel();
        jPanel7 = new javax.swing.JPanel();
        jLabel6 = new javax.swing.JLabel();
        jLabel7 = new javax.swing.JLabel();
        txt_soluong3 = new javax.swing.JTextField();
        jLabel15 = new javax.swing.JLabel();
        txt_doanhthu3 = new javax.swing.JTextField();
        jLabel16 = new javax.swing.JLabel();
        jLabel21 = new javax.swing.JLabel();
        txt_aov3 = new javax.swing.JTextField();
        jPanel9 = new javax.swing.JPanel();
        jLabel17 = new javax.swing.JLabel();
        jLabel18 = new javax.swing.JLabel();
        txt_soluong4 = new javax.swing.JTextField();
        jLabel19 = new javax.swing.JLabel();
        txt_doanhthu4 = new javax.swing.JTextField();
        jLabel20 = new javax.swing.JLabel();
        jPanel11 = new javax.swing.JPanel();
        jLabel9 = new javax.swing.JLabel();
        cbo_thoigian = new javax.swing.JComboBox<>();
        txt_batdau = new javax.swing.JTextField();
        jLabel10 = new javax.swing.JLabel();
        txt_ketthuc = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        btn_timkiem = new javax.swing.JButton();
        btn_ngay = new javax.swing.JButton();
        btn_ngay1 = new javax.swing.JButton();
        jSeparator1 = new javax.swing.JSeparator();
        jTabbedPane2 = new javax.swing.JTabbedPane();
        jPanel12 = new javax.swing.JPanel();
        jLabel12 = new javax.swing.JLabel();
        jScrollPane1 = new javax.swing.JScrollPane();
        tbl_doanhthu = new javax.swing.JTable();
        cbo_nam = new javax.swing.JComboBox<>();
        jLabel22 = new javax.swing.JLabel();
        jLabel23 = new javax.swing.JLabel();
        rdo_bang = new javax.swing.JRadioButton();
        rdo_bieudo = new javax.swing.JRadioButton();
        jPanel13 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_sanpham = new javax.swing.JTable();
        jLabel14 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setOpaque(false);
        jPanel1.setPreferredSize(new java.awt.Dimension(1485, 0));
        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(19, 0, 160));

        lblquanlykhachhang.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblquanlykhachhang.setForeground(new java.awt.Color(255, 255, 255));
        lblquanlykhachhang.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\KhachHang.png")); // NOI18N
        lblquanlykhachhang.setText("Quản lý khách hàng");
        lblquanlykhachhang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblquanlykhachhangMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblquanlykhachhangMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblquanlykhachhangMouseExited(evt);
            }
        });

        lblsanpham.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblsanpham.setForeground(new java.awt.Color(255, 255, 255));
        lblsanpham.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\quanlisanpham.png")); // NOI18N
        lblsanpham.setText("Quản lý sản phẩm");
        lblsanpham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblsanphamMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblsanphamMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblsanphamMouseExited(evt);
            }
        });

        lbldangnhap.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbldangnhap.setForeground(new java.awt.Color(255, 255, 255));
        lbldangnhap.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\dangnhap.png")); // NOI18N
        lbldangnhap.setText("Đăng nhập");
        lbldangnhap.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbldangnhapMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbldangnhapMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbldangnhapMouseExited(evt);
            }
        });

        lblbanhang.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblbanhang.setForeground(new java.awt.Color(255, 255, 255));
        lblbanhang.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\banhang.png")); // NOI18N
        lblbanhang.setText("Quản lý bán hàng");
        lblbanhang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblbanhangMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblbanhangMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblbanhangMouseExited(evt);
            }
        });

        lblnhanvien.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblnhanvien.setForeground(new java.awt.Color(255, 255, 255));
        lblnhanvien.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\nhanvien.png")); // NOI18N
        lblnhanvien.setText("Quản lý nhân viên");
        lblnhanvien.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblnhanvienMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblnhanvienMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblnhanvienMouseExited(evt);
            }
        });

        lblhoadon.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblhoadon.setForeground(new java.awt.Color(255, 255, 255));
        lblhoadon.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\hoadon.png")); // NOI18N
        lblhoadon.setText("Quản lý hóa đơn");
        lblhoadon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblhoadonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblhoadonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblhoadonMouseExited(evt);
            }
        });

        lblgiamgia.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblgiamgia.setForeground(new java.awt.Color(255, 255, 255));
        lblgiamgia.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\giamgia.png")); // NOI18N
        lblgiamgia.setText("Giảm giá");
        lblgiamgia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblgiamgiaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblgiamgiaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblgiamgiaMouseExited(evt);
            }
        });

        lblBaoCaoThongKe.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblBaoCaoThongKe.setForeground(new java.awt.Color(255, 255, 255));
        lblBaoCaoThongKe.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\B1.png")); // NOI18N
        lblBaoCaoThongKe.setText("Báo cáo thông kê");
        lblBaoCaoThongKe.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblBaoCaoThongKeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblBaoCaoThongKeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblBaoCaoThongKeMouseExited(evt);
            }
        });

        lbldangxuat.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbldangxuat.setForeground(new java.awt.Color(255, 255, 255));
        lbldangxuat.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\dangxuat.png")); // NOI18N
        lbldangxuat.setText("Đăng xuất");
        lbldangxuat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbldangxuatMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbldangxuatMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbldangxuatMouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblhoadon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblBaoCaoThongKe, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblsanpham, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblbanhang, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblgiamgia, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblnhanvien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblquanlykhachhang, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
                    .addComponent(lbldangnhap, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbldangxuat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(lblBaoCaoThongKe, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblsanpham, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblbanhang, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblgiamgia, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblhoadon, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblnhanvien, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblquanlykhachhang, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbldangnhap, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbldangxuat, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(270, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 100, 190, 800);

        jPanel4.setBackground(new java.awt.Color(19, 0, 160));
        jPanel4.setPreferredSize(new java.awt.Dimension(1455, 143));

        jLabel1.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\LOGO(TO).png")); // NOI18N
        jLabel1.setText("jLabel1");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1511, Short.MAX_VALUE))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel4);
        jPanel4.setBounds(0, 0, 1500, 100);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setPreferredSize(new java.awt.Dimension(1300, 820));

        jPanel5.setBackground(new java.awt.Color(243, 161, 58));
        jPanel5.setForeground(new java.awt.Color(255, 255, 255));

        jLabel2.setForeground(new java.awt.Color(51, 51, 51));
        jLabel2.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\baocao2.png")); // NOI18N

        jLabel3.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel3.setForeground(new java.awt.Color(255, 255, 255));
        jLabel3.setText("Tổng đơn hàng");

        txt_soluong1.setEditable(false);
        txt_soluong1.setBackground(new java.awt.Color(243, 161, 58));
        txt_soluong1.setForeground(new java.awt.Color(255, 255, 255));
        txt_soluong1.setText("0");
        txt_soluong1.setBorder(null);
        txt_soluong1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_soluong1ActionPerformed(evt);
            }
        });

        jLabel8.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel8.setForeground(new java.awt.Color(255, 255, 255));
        jLabel8.setText("Số lượng:");

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jLabel8)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_soluong1, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel3)
                    .addComponent(jLabel2))
                .addContainerGap(23, Short.MAX_VALUE))
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel2, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel3)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_soluong1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel8))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel6.setBackground(new java.awt.Color(46, 204, 113));
        jPanel6.setForeground(new java.awt.Color(255, 255, 255));

        jLabel4.setForeground(new java.awt.Color(51, 51, 51));
        jLabel4.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\baocao2.png")); // NOI18N

        jLabel5.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel5.setForeground(new java.awt.Color(255, 255, 255));
        jLabel5.setText("Doanh thu");

        txt_doanhthu2.setEditable(false);
        txt_doanhthu2.setBackground(new java.awt.Color(46, 204, 113));
        txt_doanhthu2.setForeground(new java.awt.Color(255, 255, 255));
        txt_doanhthu2.setText("0");
        txt_doanhthu2.setBorder(null);
        txt_doanhthu2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_doanhthu2ActionPerformed(evt);
            }
        });

        jLabel13.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel13.setForeground(new java.awt.Color(255, 255, 255));
        jLabel13.setText("Doanh thu:");

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(jLabel13)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_doanhthu2, javax.swing.GroupLayout.DEFAULT_SIZE, 177, Short.MAX_VALUE))
                    .addComponent(jLabel5)
                    .addComponent(jLabel4))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel5)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_doanhthu2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel13))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel7.setBackground(new java.awt.Color(52, 152, 209));
        jPanel7.setForeground(new java.awt.Color(255, 255, 255));

        jLabel6.setForeground(new java.awt.Color(51, 51, 51));
        jLabel6.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\baocao2.png")); // NOI18N

        jLabel7.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel7.setForeground(new java.awt.Color(255, 255, 255));
        jLabel7.setText("Giá trị đơn hàng trung bình");

        txt_soluong3.setEditable(false);
        txt_soluong3.setBackground(new java.awt.Color(52, 152, 209));
        txt_soluong3.setForeground(new java.awt.Color(255, 255, 255));
        txt_soluong3.setText("HIEN SO DON HAN O DAY");
        txt_soluong3.setBorder(null);
        txt_soluong3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_soluong3ActionPerformed(evt);
            }
        });

        jLabel15.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel15.setForeground(new java.awt.Color(255, 255, 255));
        jLabel15.setText("Số lượng:");

        txt_doanhthu3.setEditable(false);
        txt_doanhthu3.setBackground(new java.awt.Color(52, 152, 209));
        txt_doanhthu3.setForeground(new java.awt.Color(255, 255, 255));
        txt_doanhthu3.setText("HIEN SO DON HAN O DAY");
        txt_doanhthu3.setBorder(null);
        txt_doanhthu3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_doanhthu3ActionPerformed(evt);
            }
        });

        jLabel16.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel16.setForeground(new java.awt.Color(255, 255, 255));
        jLabel16.setText("Doanh thu:");

        jLabel21.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel21.setForeground(new java.awt.Color(255, 255, 255));
        jLabel21.setText("Giá trị(AOV):");

        txt_aov3.setEditable(false);
        txt_aov3.setBackground(new java.awt.Color(52, 152, 209));
        txt_aov3.setForeground(new java.awt.Color(255, 255, 255));
        txt_aov3.setText("HIEN SO DON HAN O DAY");
        txt_aov3.setBorder(null);
        txt_aov3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_aov3ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel21)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(txt_aov3))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel16)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_doanhthu3))
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel15)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_soluong3, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jLabel7)
                    .addComponent(jLabel6))
                .addContainerGap(20, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel6, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel7)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_soluong3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel15))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel16)
                    .addComponent(txt_doanhthu3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel21)
                    .addComponent(txt_aov3, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(24, Short.MAX_VALUE))
        );

        jPanel9.setBackground(new java.awt.Color(155, 89, 182));
        jPanel9.setForeground(new java.awt.Color(255, 255, 255));

        jLabel17.setForeground(new java.awt.Color(51, 51, 51));
        jLabel17.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\baocao2.png")); // NOI18N

        jLabel18.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel18.setForeground(new java.awt.Color(255, 255, 255));
        jLabel18.setText("Doanh thu và số lượng đơn hàng theo năm");

        txt_soluong4.setBackground(new java.awt.Color(155, 89, 182));
        txt_soluong4.setForeground(new java.awt.Color(255, 255, 255));
        txt_soluong4.setText("HIEN SO DON HAN O DAY");
        txt_soluong4.setBorder(null);
        txt_soluong4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_soluong4ActionPerformed(evt);
            }
        });

        jLabel19.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel19.setForeground(new java.awt.Color(255, 255, 255));
        jLabel19.setText("Số lượng:");

        txt_doanhthu4.setEditable(false);
        txt_doanhthu4.setBackground(new java.awt.Color(155, 89, 182));
        txt_doanhthu4.setForeground(new java.awt.Color(255, 255, 255));
        txt_doanhthu4.setText("HIEN SO DON HAN O DAY");
        txt_doanhthu4.setBorder(null);
        txt_doanhthu4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                txt_doanhthu4ActionPerformed(evt);
            }
        });

        jLabel20.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        jLabel20.setForeground(new java.awt.Color(255, 255, 255));
        jLabel20.setText("Doanh thu:");

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(16, 16, 16)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel19)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_soluong4))
                    .addComponent(jLabel18)
                    .addComponent(jLabel17)
                    .addGroup(jPanel9Layout.createSequentialGroup()
                        .addComponent(jLabel20)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_doanhthu4, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(36, Short.MAX_VALUE))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel9Layout.createSequentialGroup()
                .addGap(15, 15, 15)
                .addComponent(jLabel17, javax.swing.GroupLayout.PREFERRED_SIZE, 48, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jLabel18)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_soluong4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel19))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel20)
                    .addComponent(txt_doanhthu4, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel11.setForeground(new java.awt.Color(204, 204, 204));

        jLabel9.setText("Loại thời gian:");

        cbo_thoigian.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbo_thoigian.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbo_thoigianActionPerformed(evt);
            }
        });

        jLabel10.setText("Ngày bắt đầu:");

        jLabel11.setText("Ngày kết thúc:");

        btn_timkiem.setBackground(new java.awt.Color(19, 0, 194));
        btn_timkiem.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_timkiem.setForeground(new java.awt.Color(255, 255, 255));
        btn_timkiem.setText("Tìm kiếm");
        btn_timkiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_timkiemActionPerformed(evt);
            }
        });

        btn_ngay.setBackground(new java.awt.Color(19, 0, 194));
        btn_ngay.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_ngay.setForeground(new java.awt.Color(255, 255, 255));
        btn_ngay.setText("Lịch");
        btn_ngay.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ngayActionPerformed(evt);
            }
        });

        btn_ngay1.setBackground(new java.awt.Color(19, 0, 194));
        btn_ngay1.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        btn_ngay1.setForeground(new java.awt.Color(255, 255, 255));
        btn_ngay1.setText("Lịch");
        btn_ngay1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_ngay1ActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel11Layout = new javax.swing.GroupLayout(jPanel11);
        jPanel11.setLayout(jPanel11Layout);
        jPanel11Layout.setHorizontalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel9, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(cbo_thoigian, javax.swing.GroupLayout.PREFERRED_SIZE, 114, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(34, 34, 34)
                .addComponent(jLabel10)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(txt_batdau, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_ngay)
                .addGap(18, 18, 18)
                .addComponent(jLabel11)
                .addGap(18, 18, 18)
                .addComponent(txt_ketthuc, javax.swing.GroupLayout.PREFERRED_SIZE, 200, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_ngay1)
                .addGap(129, 129, 129)
                .addComponent(btn_timkiem, javax.swing.GroupLayout.PREFERRED_SIZE, 105, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(271, Short.MAX_VALUE))
        );
        jPanel11Layout.setVerticalGroup(
            jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel11Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addGroup(jPanel11Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel9)
                    .addComponent(cbo_thoigian, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(txt_batdau, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel10)
                    .addComponent(txt_ketthuc, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11)
                    .addComponent(btn_timkiem)
                    .addComponent(btn_ngay)
                    .addComponent(btn_ngay1))
                .addContainerGap(18, Short.MAX_VALUE))
        );

        jPanel12.setBackground(new java.awt.Color(255, 255, 255));

        jLabel12.setText("Năm:");

        tbl_doanhthu.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "Tháng", "Sản phẩm đã bán", "Tổng giá bán", "Tổng giảm giá", "Doanh thu"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane1.setViewportView(tbl_doanhthu);

        cbo_nam.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbo_nam.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                cbo_namMouseClicked(evt);
            }
        });
        cbo_nam.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbo_namActionPerformed(evt);
            }
        });

        jLabel22.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel22.setText("Doanh Thu");

        jLabel23.setText("Kiểu hiển thị:");

        rdo_gr_hien_thi.add(rdo_bang);
        rdo_bang.setText("Bảng");
        rdo_bang.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdo_bangActionPerformed(evt);
            }
        });

        rdo_gr_hien_thi.add(rdo_bieudo);
        rdo_bieudo.setText("Biểu đồ");
        rdo_bieudo.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rdo_bieudoMouseClicked(evt);
            }
        });
        rdo_bieudo.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                rdo_bieudoActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel12Layout = new javax.swing.GroupLayout(jPanel12);
        jPanel12.setLayout(jPanel12Layout);
        jPanel12Layout.setHorizontalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGap(642, 642, 642)
                        .addComponent(jLabel22, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE))
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel12Layout.createSequentialGroup()
                                .addGap(20, 20, 20)
                                .addComponent(jLabel12, javax.swing.GroupLayout.PREFERRED_SIZE, 58, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addGap(0, 0, Short.MAX_VALUE))
                            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createSequentialGroup()
                                .addContainerGap(17, Short.MAX_VALUE)
                                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                        .addComponent(cbo_nam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(jLabel23, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE)
                                        .addComponent(rdo_bang, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))
                                    .addComponent(rdo_bieudo, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 85, javax.swing.GroupLayout.PREFERRED_SIZE))))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 1137, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addGap(27, 27, 27))
        );
        jPanel12Layout.setVerticalGroup(
            jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel12Layout.createSequentialGroup()
                .addGap(19, 19, 19)
                .addComponent(jLabel22)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel12Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel12Layout.createSequentialGroup()
                        .addComponent(jLabel12)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(cbo_nam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(18, 18, 18)
                        .addComponent(jLabel23)
                        .addGap(18, 18, 18)
                        .addComponent(rdo_bang)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(rdo_bieudo))
                    .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 350, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(21, Short.MAX_VALUE))
        );

        jTabbedPane2.addTab("Doanh Thu", jPanel12);

        jPanel13.setBackground(new java.awt.Color(255, 255, 255));

        tbl_sanpham.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã sản phẩm", "Tên sản phẩm", "Thương hiệu", "Size", "Cổ áo", "Chất liệu", "Màu sắc", "Số lượt bán", "Giá bán"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        jScrollPane2.setViewportView(tbl_sanpham);

        jLabel14.setFont(new java.awt.Font("Segoe UI", 1, 18)); // NOI18N
        jLabel14.setText("Top các sản phẩm bán chạy");

        javax.swing.GroupLayout jPanel13Layout = new javax.swing.GroupLayout(jPanel13);
        jPanel13.setLayout(jPanel13Layout);
        jPanel13Layout.setHorizontalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane2)
                .addContainerGap())
            .addGroup(jPanel13Layout.createSequentialGroup()
                .addGap(415, 415, 415)
                .addComponent(jLabel14, javax.swing.GroupLayout.PREFERRED_SIZE, 242, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(615, Short.MAX_VALUE))
        );
        jPanel13Layout.setVerticalGroup(
            jPanel13Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel13Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jLabel14)
                .addGap(18, 18, 18)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 390, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );

        jTabbedPane2.addTab("Sản phẩm bán chạy", jPanel13);

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(206, 206, 206)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(44, 44, 44)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(41, 41, 41)
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 1272, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 1277, javax.swing.GroupLayout.PREFERRED_SIZE)))
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(110, 110, 110)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                    .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addComponent(jPanel11, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(9, 9, 9)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 67, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jTabbedPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 456, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(72, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3);
        jPanel3.setBounds(0, 0, 1500, 900);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 875, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblBaoCaoThongKeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBaoCaoThongKeMouseEntered
// TODO add your handling code here:
        lblBaoCaoThongKe.setBackground(new java.awt.Color(70, 130, 180));
        lblBaoCaoThongKe.setOpaque(true);
        lblBaoCaoThongKe.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblBaoCaoThongKeMouseEntered

    private void lblBaoCaoThongKeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBaoCaoThongKeMouseExited
        // TODO add your handling code here:
        lblBaoCaoThongKe.setBackground(null);
        lblBaoCaoThongKe.setOpaque(false);
    }//GEN-LAST:event_lblBaoCaoThongKeMouseExited

    private void lblsanphamMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblsanphamMouseEntered
        // TODO add your handling code here:
        lblsanpham.setBackground(new java.awt.Color(70, 130, 180));
        lblsanpham.setOpaque(true);
        lblsanpham.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblsanphamMouseEntered

    private void lblsanphamMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblsanphamMouseExited
        // TODO add your handling code here:
        lblsanpham.setBackground(null);
        lblsanpham.setOpaque(false);
    }//GEN-LAST:event_lblsanphamMouseExited

    private void lblbanhangMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblbanhangMouseEntered
        // TODO add your handling code here:
        lblbanhang.setBackground(new java.awt.Color(70, 130, 180));
        lblbanhang.setOpaque(true);
        lblbanhang.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblbanhangMouseEntered

    private void lblbanhangMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblbanhangMouseExited
        // TODO add your handling code here:
        lblbanhang.setBackground(null);
        lblbanhang.setOpaque(false);
    }//GEN-LAST:event_lblbanhangMouseExited

    private void lblgiamgiaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblgiamgiaMouseEntered
        // TODO add your handling code here:
        lblgiamgia.setBackground(new java.awt.Color(70, 130, 180));
        lblgiamgia.setOpaque(true);
        lblgiamgia.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblgiamgiaMouseEntered

    private void lblgiamgiaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblgiamgiaMouseExited
        // TODO add your handling code here:
        lblgiamgia.setBackground(null);
        lblgiamgia.setOpaque(false);
    }//GEN-LAST:event_lblgiamgiaMouseExited

    private void lblhoadonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblhoadonMouseEntered
        // TODO add your handling code here:
        lblhoadon.setBackground(new java.awt.Color(70, 130, 180));
        lblhoadon.setOpaque(true);
        lblhoadon.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblhoadonMouseEntered

    private void lblhoadonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblhoadonMouseExited
        // TODO add your handling code here:
        lblhoadon.setBackground(null);
        lblhoadon.setOpaque(false);
    }//GEN-LAST:event_lblhoadonMouseExited

    private void lblnhanvienMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblnhanvienMouseEntered
        // TODO add your handling code here:
        lblnhanvien.setBackground(new java.awt.Color(70, 130, 180));
        lblnhanvien.setOpaque(true);
        lblnhanvien.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblnhanvienMouseEntered

    private void lblnhanvienMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblnhanvienMouseExited
        // TODO add your handling code here:
        lblnhanvien.setBackground(null);
        lblnhanvien.setOpaque(false);
    }//GEN-LAST:event_lblnhanvienMouseExited

    private void lblquanlykhachhangMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblquanlykhachhangMouseEntered
        // TODO add your handling code here:
        lblquanlykhachhang.setBackground(new java.awt.Color(70, 130, 180));
        lblquanlykhachhang.setOpaque(true);
        lblquanlykhachhang.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblquanlykhachhangMouseEntered

    private void lblquanlykhachhangMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblquanlykhachhangMouseExited
        // TODO add your handling code here:
        lblquanlykhachhang.setBackground(null);
        lblquanlykhachhang.setOpaque(false);
    }//GEN-LAST:event_lblquanlykhachhangMouseExited

    private void lbldangnhapMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangnhapMouseEntered
        // TODO add your handling code here:
        lbldangnhap.setBackground(new java.awt.Color(70, 130, 180));
        lbldangnhap.setOpaque(true);
        lbldangnhap.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lbldangnhapMouseEntered

    private void lbldangnhapMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangnhapMouseExited
        // TODO add your handling code here:
        lbldangnhap.setBackground(null);
        lbldangnhap.setOpaque(false);
    }//GEN-LAST:event_lbldangnhapMouseExited

    private void lbldangxuatMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangxuatMouseEntered
        // TODO add your handling code here:
        lbldangxuat.setBackground(new java.awt.Color(70, 130, 180));
        lbldangxuat.setOpaque(true);
        lbldangxuat.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lbldangxuatMouseEntered

    private void lbldangxuatMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangxuatMouseExited
        // TODO add your handling code here:
        lbldangxuat.setBackground(null);
        lbldangxuat.setOpaque(false);
    }//GEN-LAST:event_lbldangxuatMouseExited

    private void txt_soluong1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_soluong1ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_soluong1ActionPerformed

    private void txt_doanhthu2ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_doanhthu2ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_doanhthu2ActionPerformed

    private void txt_soluong3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_soluong3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_soluong3ActionPerformed

    private void txt_doanhthu3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_doanhthu3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_doanhthu3ActionPerformed

    private void txt_soluong4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_soluong4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_soluong4ActionPerformed

    private void txt_doanhthu4ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_doanhthu4ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_doanhthu4ActionPerformed

    private void txt_aov3ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_txt_aov3ActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_txt_aov3ActionPerformed

    private void lblBaoCaoThongKeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBaoCaoThongKeMouseClicked
        // TODO add your handling code here:
        FORM_BAO_THONG_KE form = new FORM_BAO_THONG_KE();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblBaoCaoThongKeMouseClicked

    private void lblsanphamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblsanphamMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_SAN_PHAM form = new FORM_QUAN_LY_SAN_PHAM();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblsanphamMouseClicked

    private void lblbanhangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblbanhangMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_BAN_HANG form = new FORM_QUAN_LY_BAN_HANG();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblbanhangMouseClicked

    private void lblgiamgiaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblgiamgiaMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_GIAM_GIA form = new FORM_QUAN_LY_GIAM_GIA();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblgiamgiaMouseClicked

    private void lblhoadonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblhoadonMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_HOA_DON form = new FORM_QUAN_LY_HOA_DON();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblhoadonMouseClicked

    private void lblnhanvienMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblnhanvienMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_NHAN_VIEN form = new FORM_QUAN_LY_NHAN_VIEN();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblnhanvienMouseClicked

    private void lbldangnhapMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangnhapMouseClicked
        // TODO add your handling code here:
        FORM_DANG_NHAP form = new FORM_DANG_NHAP();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lbldangnhapMouseClicked

    private void rdo_bangActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdo_bangActionPerformed
        // TODO add your handling code here:
        jScrollPane1.setViewportView(tbl_doanhthu);
    }//GEN-LAST:event_rdo_bangActionPerformed

    private void rdo_bieudoActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_rdo_bieudoActionPerformed
        // TODO add your handling code here:
        showBieuDo();
    }//GEN-LAST:event_rdo_bieudoActionPerformed

    private void rdo_bieudoMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rdo_bieudoMouseClicked

    }//GEN-LAST:event_rdo_bieudoMouseClicked

    private void cbo_namMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_cbo_namMouseClicked

    }//GEN-LAST:event_cbo_namMouseClicked

    private void btn_timkiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_timkiemActionPerformed
        // TODO add your handling code here:
        String start = "";
        java.text.SimpleDateFormat fmt1 = new java.text.SimpleDateFormat("yyyy-MM-dd");
        java.text.SimpleDateFormat fmt2 = new java.text.SimpleDateFormat("dd-MM-yyyy");
        fmt2.setLenient(false);
        String s = "", e = "";
        try {
            int idx = cbo_thoigian.getSelectedIndex();
            if (idx == 0) {
                java.util.Date now = new java.util.Date();
                s = fmt1.format(now);
                e = fmt1.format(now);
            } else {
                if (txt_batdau.getText().trim().isEmpty() || txt_ketthuc.getText().trim().isEmpty()) {
                    javax.swing.JOptionPane.showMessageDialog(this, "Nhập ngày vào (dd-MM-yyyy)");
                    return;
                }
                java.util.Date d1 = fmt2.parse(txt_batdau.getText().trim());
                java.util.Date d2 = fmt2.parse(txt_ketthuc.getText().trim());
                java.util.Date now = new java.util.Date();

                if (d1.after(d2)) {
                    javax.swing.JOptionPane.showMessageDialog(this, "Ngày bắt đầu không được lớn hơn ngày kết thúc!");
                    return;
                }
                if (d2.after(now)) {
                    javax.swing.JOptionPane.showMessageDialog(this, "Ngày kết thúc không được vượt quá ngày hiện tại!");
                    return;
                }
                // gan gia tri
                s = fmt1.format(d1);
                e = fmt1.format(d2);
            }
            fillTableByDateRange(s, e);
            fillCardsByDateRange(s, e);
            fillTableSanPhamBanChay(s, e);
        } catch (Exception ex) {
            ex.printStackTrace();
            javax.swing.JOptionPane.showMessageDialog(this, "Lỗi ngày tháng: " + ex.getMessage());
        }

    }//GEN-LAST:event_btn_timkiemActionPerformed

    private void cbo_namActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbo_namActionPerformed
        if (cbo_nam.getSelectedItem() != null) {
            fillDoanhThu();
            if (rdo_bieudo.isSelected()) {
                showBieuDo();
            } else {
                // Nếu đang xem bảng thì set lại Viewport là bảng
                jScrollPane1.setViewportView(tbl_doanhthu);
            }
        }
    }//GEN-LAST:event_cbo_namActionPerformed

    private void btn_ngayActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ngayActionPerformed
        // TODO add your handling code here:
        // Tạo JCalendar
        JCalendar calendar = new JCalendar();
        calendar.setLocale(new Locale("vi", "VN"));
        // Nếu txt_batdau có giá trị cũ, set lại
        try {
            String text = txt_batdau.getText().trim();
            if (!text.isEmpty()) {
                java.util.Date d = new SimpleDateFormat("dd-MM-yyyy").parse(text);
                calendar.setDate(d);
            } else {
                // Mặc định tháng 1 năm hiện tại
                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.MONTH, 0);
                cal.set(Calendar.DAY_OF_MONTH, 1);
                calendar.setDate(cal.getTime());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        // Khi chọn ngày → set vào txt_batdau và đóng popup
        calendar.getDayChooser().addPropertyChangeListener("day", evt2 -> {
            java.util.Date utilDate = calendar.getDate();
            if (utilDate != null) {
                java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
                txt_batdau.setText(new SimpleDateFormat("dd-MM-yyyy").format(sqlDate));
                Window w = SwingUtilities.getWindowAncestor(calendar);
                if (w != null) {
                    w.dispose();
                }
            }
        });
        // Tạo popup dialog chỉ chứa JCalendar
        JDialog dialog = new JDialog((Frame) null, "Chọn ngày", true);
        dialog.setLayout(new BorderLayout());
        dialog.add(calendar, BorderLayout.CENTER);
        dialog.pack();
        // Căn giữa popup theo nút btn_ngay
        Point p = btn_ngay.getLocationOnScreen();
        int popupWidth = dialog.getWidth();
        int btnWidth = btn_ngay.getWidth();
        int x = p.x + (btnWidth / 2) - (popupWidth / 2); // căn giữa theo nút
        int y = p.y + btn_ngay.getHeight();               // ngay dưới nút
        dialog.setLocation(x, y);
        dialog.setVisible(true);
    }//GEN-LAST:event_btn_ngayActionPerformed

    private void btn_ngay1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_ngay1ActionPerformed
        // TODO add your handling code here:
        // Tạo JCalendar
        JCalendar calendar = new JCalendar();
        calendar.setLocale(new Locale("vi", "VN"));
        // Nếu txt_batdau có giá trị cũ, set lại
        try {
            String text = txt_ketthuc.getText().trim();
            if (!text.isEmpty()) {
                java.util.Date d = new SimpleDateFormat("dd-MM-yyyy").parse(text);
                calendar.setDate(d);
            } else {
                // Mặc định tháng 1 năm hiện tại
                Calendar cal = Calendar.getInstance();
                cal.set(Calendar.MONTH, 0);
                cal.set(Calendar.DAY_OF_MONTH, 1);
                calendar.setDate(cal.getTime());
            }
        } catch (Exception ex) {
            ex.printStackTrace();
        }
        // Khi chọn ngày → set vào txt_batdau và đóng popup
        calendar.getDayChooser().addPropertyChangeListener("day", evt2 -> {
            java.util.Date utilDate = calendar.getDate();
            if (utilDate != null) {
                java.sql.Date sqlDate = new java.sql.Date(utilDate.getTime());
                txt_ketthuc.setText(new SimpleDateFormat("dd-MM-yyyy").format(sqlDate));
                Window w = SwingUtilities.getWindowAncestor(calendar);
                if (w != null) {
                    w.dispose();
                }
            }
        });
        // Tạo popup dialog chỉ chứa JCalendar
        JDialog dialog = new JDialog((Frame) null, "Chọn ngày", true);
        dialog.setLayout(new BorderLayout());
        dialog.add(calendar, BorderLayout.CENTER);
        dialog.pack();
        // Căn giữa popup theo nút btn_ngay
        Point p = btn_ngay1.getLocationOnScreen();
        int popupWidth = dialog.getWidth();
        int btnWidth = btn_ngay1.getWidth();
        int x = p.x + (btnWidth / 2) - (popupWidth / 2); // căn giữa theo nút
        int y = p.y + btn_ngay1.getHeight();               // ngay dưới nút
        dialog.setLocation(x, y);
        dialog.setVisible(true);
    }//GEN-LAST:event_btn_ngay1ActionPerformed

    private void cbo_thoigianActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbo_thoigianActionPerformed
        // TODO add your handling code here:
        int i = cbo_thoigian.getSelectedIndex();
        if (i == 0) {
            txt_batdau.setEnabled(false);
            txt_ketthuc.setEnabled(false);
            fillCards();
        } else {
            txt_batdau.setEnabled(true);
            txt_ketthuc.setEnabled(true);
        }
    }//GEN-LAST:event_cbo_thoigianActionPerformed

    private void lblquanlykhachhangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblquanlykhachhangMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_KHACH_HANG form = new FORM_QUAN_LY_KHACH_HANG();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblquanlykhachhangMouseClicked

    private void lbldangxuatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangxuatMouseClicked
        // TODO add your handling code here:
        int yes = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn thoát hay không?");
        if (yes == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_lbldangxuatMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FORM_BAO_THONG_KE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FORM_BAO_THONG_KE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FORM_BAO_THONG_KE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FORM_BAO_THONG_KE.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FORM_BAO_THONG_KE.class.getName()).log(java.util.logging.Level.SEVERE,
                    null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FORM_BAO_THONG_KE.class.getName()).log(java.util.logging.Level.SEVERE,
                    null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FORM_BAO_THONG_KE.class.getName()).log(java.util.logging.Level.SEVERE,
                    null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FORM_BAO_THONG_KE.class.getName()).log(java.util.logging.Level.SEVERE,
                    null, ex);
        }
        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FORM_BAO_THONG_KE().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_ngay;
    private javax.swing.JButton btn_ngay1;
    private javax.swing.JButton btn_timkiem;
    private javax.swing.JComboBox<String> cbo_nam;
    private javax.swing.JComboBox<String> cbo_thoigian;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel15;
    private javax.swing.JLabel jLabel16;
    private javax.swing.JLabel jLabel17;
    private javax.swing.JLabel jLabel18;
    private javax.swing.JLabel jLabel19;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel20;
    private javax.swing.JLabel jLabel21;
    private javax.swing.JLabel jLabel22;
    private javax.swing.JLabel jLabel23;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel11;
    private javax.swing.JPanel jPanel12;
    private javax.swing.JPanel jPanel13;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JTabbedPane jTabbedPane2;
    private javax.swing.JLabel lblBaoCaoThongKe;
    private javax.swing.JLabel lblbanhang;
    private javax.swing.JLabel lbldangnhap;
    private javax.swing.JLabel lbldangxuat;
    private javax.swing.JLabel lblgiamgia;
    private javax.swing.JLabel lblhoadon;
    private javax.swing.JLabel lblnhanvien;
    private javax.swing.JLabel lblquanlykhachhang;
    private javax.swing.JLabel lblsanpham;
    private javax.swing.JRadioButton rdo_bang;
    private javax.swing.JRadioButton rdo_bieudo;
    private javax.swing.ButtonGroup rdo_gr_hien_thi;
    private javax.swing.JTable tbl_doanhthu;
    private javax.swing.JTable tbl_sanpham;
    private javax.swing.JTextField txt_aov3;
    private javax.swing.JTextField txt_batdau;
    private javax.swing.JTextField txt_doanhthu2;
    private javax.swing.JTextField txt_doanhthu3;
    private javax.swing.JTextField txt_doanhthu4;
    private javax.swing.JTextField txt_ketthuc;
    private javax.swing.JTextField txt_soluong1;
    private javax.swing.JTextField txt_soluong3;
    private javax.swing.JTextField txt_soluong4;
    // End of variables declaration//GEN-END:variables
/// 1. Đổ dữ liệu doanh thu vào bảng theo khoảng thời gian (Start - End)
    private void fillTableByDateRange(String start, String end) {
        DefaultTableModel model = (DefaultTableModel) tbl_doanhthu.getModel();
        model.setRowCount(0); // Xóa sạch bảng cũ
        List<DoanhThuThang> list = repoTK.getDoanhThuByDateRange(start, end);

        // Nếu list rỗng và đang chọn chế độ lọc theo khoảng -> Báo lỗi
        if (list.isEmpty() && cbo_thoigian.getSelectedIndex() == 1) {
            javax.swing.JOptionPane.showMessageDialog(this, "Không có dữ liệu trong khoảng thời gian này!");
        }
        // Duyệt list và thêm dòng vào bảng (Code gộp dòng gọn)
        for (DoanhThuThang dt : list) {
            model.addRow(new Object[]{dt.getThang() + "/" + dt.getNam(), dt.getSanPhamDaBan(), formatMoney(dt.getTongGiaBan()), formatMoney(dt.getTongGiamGia()), formatMoney(dt.getDoanhThu())});
        }
    }

    // 2. Cập nhật số liệu tổng lên các thẻ (Card màu) theo khoảng thời gian
    private void fillCardsByDateRange(String start, String end) {
        List<DoanhThuThang> list = repoTK.getDoanhThuByDateRange(start, end);
        BigDecimal totalMoney = BigDecimal.ZERO;
        int totalCount = 0;
        if (list != null) {
            for (DoanhThuThang dt : list) {
                // Cộng dồn doanh thu và số lượng sản phẩm bán ra
                if (dt.getDoanhThu() != null) {
                    totalMoney = totalMoney.add(dt.getDoanhThu());
                }
                totalCount += dt.getSanPhamDaBan();
            }
        }
        // Hiển thị kết quả lên TextField
        txt_soluong1.setText(String.valueOf(totalCount));
        txt_doanhthu2.setText(formatMoney(totalMoney) + " đ");
    }

    // 3. Đổ dữ liệu Top sản phẩm bán chạy (Xử lý thông minh: Null -> Lấy tất cả, Có ngày -> Lọc)
    private void fillTableSanPhamBanChay(String start, String end) {
        DefaultTableModel model = (DefaultTableModel) tbl_sanpham.getModel();
        model.setRowCount(0);
        // Dùng toán tử 3 ngôi để chọn hàm DAO phù hợp
        List<Sanphambanchay> list = (start == null || end == null) ? repoTK.getSanPhamBanChay() : repoTK.getSanPhamBanChayByDate(start, end);
        if (list != null) {
            for (Sanphambanchay sp : list) {
                model.addRow(new Object[]{sp.getMa_san_pham(), sp.getTen_san_pham(), sp.getTen_thuong_hieu(), sp.getTen_Size(), sp.getTen_co_ao(), sp.getTen_chat_lieu(), sp.getTen_mau(), sp.getSo_Luot_Ban(), formatMoney(sp.getGia_ban())});
            }
        }
    }

    // 4. Khởi tạo ComboBox chọn loại thời gian (Hôm nay / Khoảng thời gian)
    private void initCboThoiGian() {
        DefaultComboBoxModel model = (DefaultComboBoxModel) cbo_thoigian.getModel();
        model.removeAllElements();
        model.addElement("Hôm nay");
        model.addElement("Theo khoảng thời gian");
        cbo_thoigian.setSelectedIndex(0); // Mặc định chọn 'Hôm nay'
        txt_batdau.setEnabled(false); // Khóa ô nhập ngày
        txt_ketthuc.setEnabled(false);
    }

    // 5. Đổ danh sách Năm hoạt động vào ComboBox
    private void fillCboNam() {
        DefaultComboBoxModel model = (DefaultComboBoxModel) cbo_nam.getModel();
        model.removeAllElements();
        List<Integer> list = repoTK.getListNam();
        if (list != null) {
            for (Integer n : list) {
                model.addElement(n);
            }
            if (!list.isEmpty()) {
                cbo_nam.setSelectedIndex(0); // Chọn năm đầu tiên
            }
        }
    }

    // 6. Đổ doanh thu chi tiết theo Năm được chọn
    private void fillDoanhThu() {
        if (cbo_nam.getSelectedItem() == null) {
            return; // Chưa chọn năm thì thoát
        }
        DefaultTableModel model = (DefaultTableModel) tbl_doanhthu.getModel();
        model.setRowCount(0);
        List<DoanhThuThang> list = repoTK.getDoanhThuByNam((Integer) cbo_nam.getSelectedItem());
        if (list != null) {
            for (DoanhThuThang dt : list) {
                model.addRow(new Object[]{"Tháng " + dt.getThang(), dt.getSanPhamDaBan(), formatMoney(dt.getTongGiaBan()), formatMoney(dt.getTongGiamGia()), formatMoney(dt.getDoanhThu())});
            }
        }
    }

    @Override
    public DoanhThuThang create(DoanhThuThang entity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void update(DoanhThuThang entity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deleteById(Iterable id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<DoanhThuThang> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public DoanhThuThang findById(Iterable id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Integer> getListNam() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<DoanhThuThang> getDoanhThuByNam(int nam) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<DoanhThuThang> getDoanhThuByDateRange(String start, String end) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<DoanhThuThang> getDoanhThu() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Sanphambanchay> getSanPhamBanChay() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
