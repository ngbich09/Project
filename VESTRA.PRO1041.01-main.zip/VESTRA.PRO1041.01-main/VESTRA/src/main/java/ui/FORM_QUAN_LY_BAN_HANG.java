/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/GUIForms/JFrame.java to edit this template
 */
package ui;
// Swing

import javax.swing.*;
import javax.swing.table.DefaultTableModel;

import controller.Hoadon_CRUD;
import daoipml.Hoadon_DAOIpml;
import daoipml.Hoadonchitiet_DAOIpml;
import daoipml.Nhanvien_DAOIpml;
import daoipml.Sanphamchitiet_DAOIpml;
import daoipml.Voucher_DAOIpml;
import entity.Hoadon;
import entity.Nhanvien;
import entity.Sanphamchitiet;
import entity.Voucher;
import java.awt.Cursor;
import java.awt.image.BufferedImage;
import java.math.BigDecimal;
import java.text.NumberFormat;
import java.time.format.DateTimeFormatter;
import java.util.Locale;
import javax.swing.BorderFactory;
import javax.swing.DefaultCellEditor;
import javax.swing.JCheckBox;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.event.TableModelEvent;
import javax.swing.table.DefaultTableModel;
// QR
import com.github.sarxos.webcam.Webcam;
import com.github.sarxos.webcam.WebcamPanel;
import com.google.zxing.*;
import com.google.zxing.common.HybridBinarizer;
import com.google.zxing.client.j2se.BufferedImageLuminanceSource;
import com.itextpdf.io.font.PdfEncodings;
import com.itextpdf.kernel.font.PdfFont;
import com.itextpdf.kernel.font.PdfFontFactory;

import com.itextpdf.kernel.pdf.PdfWriter;
import com.itextpdf.kernel.pdf.PdfDocument;
import com.itextpdf.layout.Document;
import com.itextpdf.layout.element.Paragraph;
import com.itextpdf.layout.element.Table;
import com.itextpdf.layout.element.Cell;
import com.itextpdf.layout.properties.UnitValue;

import daoipml.Khachhang_DAOIpml;
import entity.Hoadonchitiet;
import entity.Khachhang;
import java.awt.BorderLayout;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.InputStream;
import java.math.MathContext;
import javax.swing.Timer;
import java.util.List;
import static javax.swing.JOptionPane.YES_OPTION;

/**
 *
 * @author manhh
 */
public class FORM_QUAN_LY_BAN_HANG extends javax.swing.JFrame implements Hoadon_CRUD {

    private Hoadon_DAOIpml repoHD = new Hoadon_DAOIpml();
    private DefaultTableModel ModelHD = new DefaultTableModel();
    private Hoadonchitiet_DAOIpml repoHDCT = new Hoadonchitiet_DAOIpml();
    private DefaultTableModel ModelGioHang = new DefaultTableModel();
    private Sanphamchitiet_DAOIpml repoSPCT = new Sanphamchitiet_DAOIpml();
    private DefaultTableModel ModelSPCT = new DefaultTableModel();
    private Voucher_DAOIpml repoVoucher = new Voucher_DAOIpml();
    private Nhanvien_DAOIpml repoNV = new Nhanvien_DAOIpml();
    private Khachhang_DAOIpml repoKH = new Khachhang_DAOIpml();
    private int index = -1;
    private String ma_san_pham_chi_tiet;
    private boolean isScanning = true;
    private Webcam webcam;
    private WebcamPanel webcamPanel;
    private Timer qrTimer;
    private boolean UpdateSL = false;
    private int CHECKHD = 0;

    /**
     * Creates new form FROM_THONGKE
     */
    public FORM_QUAN_LY_BAN_HANG() {
        initComponents();
        panecam.setVisible(false);
        hienthilabel();  // hiển thi lable cho from (không xóa);
        txt_manv.setText(Session.getMaNhanVien()); 
        this.fillToTableHD(); 
        this.fillToTablespchitiet(); 
        repoVoucher.UPDATETRANGTHAI();
        ModelGioHang.setRowCount(0);
        rdo_tienmat.setSelected(true);
        cbo_voucher.removeAllItems();
        cbo_voucher.addItem("Mời chọn Voucher");
        for (Voucher x : repoVoucher.ListVoucher()) {
            cbo_voucher.addItem(x.Thongtinvoucher());
        }
        cbo_voucher.addActionListener(e -> {
            if (Check()) {
                calculate_discount();
            } else {
                cbo_voucher.setSelectedIndex(0);
                txt_tiengiam.setText("0");
            }
        });
        tbl_giohang.getModel().addTableModelListener(e -> {
            if (UpdateSL) {
                return;
            }
            if (e.getType() == TableModelEvent.UPDATE && e.getColumn() == 7) {
                int row = e.getFirstRow();
                if (row >= 0) {
                    UpdateSoLuong(row);
                    fillToTablespchitiet();
                    calculate_discount();
                }
            }
        });
        txt_tienkhachdua.addActionListener(e -> {
            if (!Check()) {
                return;
            }
            try {
                BigDecimal tongTien = fromVietnameseMoney(txt_ttt.getText());
                BigDecimal tienKhach = fromVietnameseMoney(txt_tienkhachdua.getText());
                BigDecimal tienThua = tienKhach.subtract(tongTien);
                txt_tienthoi.setText(tienThua.toString());
                if (tienThua.compareTo(new BigDecimal("0")) > 0) {
                    JOptionPane.showMessageDialog(null, "Trả lại khách: " + toVietnameseMoney(tienThua));
                } else if (tienThua.compareTo(new BigDecimal("0")) < 0) {
                    JOptionPane.showMessageDialog(null, "Khách còn thiếu: " + toVietnameseMoney(tienThua));
                } else {
                    JOptionPane.showMessageDialog(null, "Khách đưa đủ, không cần trả lại");
                    txt_tienthoi.setText("0");
                }
            } catch (NumberFormatException ex) {
                txt_tienthoi.setText("0");
                ex.printStackTrace();
            }
        });
        Khoa();
    }

    public String toVietnameseMoney(BigDecimal value) {
        if (value == null) {
            return "0 ₫";
        }
        Locale locale = new Locale("vi", "VN");
        NumberFormat formatter = NumberFormat.getCurrencyInstance(locale);
        return formatter.format(value);
    }

    public BigDecimal fromVietnameseMoney(String text) {
        if (text == null || text.trim().isEmpty()) {
            return BigDecimal.ZERO;
        }

        String cleaned = text.replaceAll("[^0-9-]", "");

        if (cleaned.isEmpty()) {
            return BigDecimal.ZERO;
        }

        return new BigDecimal(cleaned);
    }

    private void UpdateSoLuong(int row) {
        if (UpdateSL) {
            return;
        }
        UpdateSL = true;
        if (tbl_giohang.isEditing()) {
            tbl_giohang.getCellEditor().stopCellEditing();
        }
        String maSPCT = tbl_giohang.getValueAt(row, 0).toString();
        int IDHD = Integer.parseInt(txt_hoadon.getText());
        Sanphamchitiet SPCT = repoSPCT.IDSPCT(maSPCT);
        int soLuongCu = 0;
        for (int i = 0; i < ModelGioHang.getRowCount(); i++) {
            Object value = ModelGioHang.getValueAt(i, 0); // cột mã SPCT
            if (value != null && value.equals(maSPCT)) {
                Hoadonchitiet HDCT = repoHDCT.SoLuongCu(SPCT.getID_san_pham_chi_tiet(), IDHD);
                soLuongCu = HDCT.getSo_luong();
            }
        }
        int tonKho = SPCT.getSo_luong_ton();;
        String TENSP = tbl_giohang.getValueAt(row, 1).toString();
        int soLuongMoi;
        try {
            soLuongMoi = Integer.parseInt(tbl_giohang.getValueAt(row, 7).toString());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(this, "Số lượng không hợp lệ,Số lượng sẽ được đặt về 1");
            soLuongMoi = 1;
        }
        if (soLuongMoi <= 0) {
            JOptionPane.showMessageDialog(this, "Số lượng phải lớn hơn 0, số lượng sẽ được đặt về 1");
            soLuongMoi = 1;
        }
        int soLuongToiDa = tonKho + soLuongCu;
        if (soLuongMoi > soLuongToiDa) {
            JOptionPane.showMessageDialog(this, "Sản phẩm " + TENSP + " chỉ còn tối đa: " + soLuongToiDa);
            soLuongMoi = soLuongToiDa;
        }

        tbl_giohang.setValueAt(soLuongMoi, row, 7);
        String Dongia = tbl_giohang.getValueAt(row, 8).toString();
        BigDecimal donGia = fromVietnameseMoney(Dongia);
        BigDecimal thanhTien = donGia.multiply(BigDecimal.valueOf(soLuongMoi));
        tbl_giohang.setValueAt(toVietnameseMoney(thanhTien), row, 9);
        int IDSPCT = SPCT.getID_san_pham_chi_tiet();
        Hoadonchitiet HDCTT = repoHDCT.IDHDCT(IDHD, IDSPCT);
        int iDHDCT = HDCTT.getID_hdct();
        Hoadonchitiet HDCTUP = new Hoadonchitiet();
        HDCTUP.setSo_luong(soLuongMoi);
        HDCTUP.setID_hdct(iDHDCT);
        repoHDCT.update(HDCTUP);
        fillToTablespchitiet();
        TongTienTamTinh();
        UpdateSL = false;
    }

    public void Lammoi() {
        txt_hoadon.setText("");
        txt_tienkhachdua.setText("");
        txt_tienthoi.setText("");
        txt_hoadon.setText("");
        txt_tiengiam.setText("");
        txt_sodt.setText("");
        txt_tenkhach.setText("");
        txt_ghichu.setText("");
        cbo_voucher.setSelectedIndex(0);
        txt_ttt.setText("");
        txt_tienhang.setText("");
        fillToTableHD();
        ModelGioHang.setRowCount(0);
        rdo_tienmat.setSelected(true);
    }

    public void Lammoitimkiem() {
        txt_timkiemsanpham.setText("");
        fillToTablespchitiet();
    }

    public void Khoa() {
        txt_manv.setEditable(false);
        txt_tienthoi.setEditable(false);
        txt_hoadon.setEditable(false);
        txt_ttt.setEditable(false);
        txt_tienhang.setEditable(false);
        txt_tiengiam.setEditable(false);
        txt_tienthoi.setEditable(false);
    }

    public void TongTienTamTinh() {
        int id = Integer.parseInt(txt_hoadon.getText());
        Hoadon HD = repoHD.TongTienTT(id);
        BigDecimal tien = HD.getTong_tien_tam_tinh();
        if (tien == null) {
            txt_ttt.setText("0");
        } else {
            txt_ttt.setText(toVietnameseMoney(tien));
        }
        totalamount();
    }

    public Khachhang GetfromKH() {

        Khachhang KH = repoKH.KH(txt_sodt.getText());
        if (KH == null) {
            JOptionPane.showMessageDialog(this, "Không tìm thấy thông tin khách hàng!");
            return null;
        }
        return KH;
    }

    public void EDITKH() {
        Khachhang KH = GetfromKH();
        txt_tenkhach.setText(KH.getTen_khach_hang());
        txt_sodt.setText(KH.getSDT());
    }

    public int CheckHoaDon() {
        int soluong = 0;
        ModelHD = (DefaultTableModel) tbl_hoadon.getModel();
        if (ModelHD.getRowCount() > 0) {
            boolean Trong = true;

            for (int i = 0; i < ModelHD.getRowCount(); i++) {
                if (ModelHD.getValueAt(i, 0) != null) {
                    Trong = false;
                    soluong++;
                }
            }
            if (Trong) {
                ModelHD.setRowCount(0);
            }
        }
        return soluong;
    }

    public void AddSP(int index) {

        ModelGioHang = (DefaultTableModel) tbl_giohang.getModel();
        if (ModelGioHang.getRowCount() > 0) {
            boolean Trong = true;

            for (int i = 0; i < ModelGioHang.getRowCount(); i++) {
                if (ModelGioHang.getValueAt(i, 0) != null) {
                    Trong = false;
                    break;
                }
            }
            if (Trong) {
                ModelGioHang.setRowCount(0);
            }
        }

        Sanphamchitiet SPCTT = repoSPCT.SPQRCODE(tbl_sanphamchitie.getValueAt(index, 1).toString());
        String maSPCT = SPCTT.getMa_san_pham_chi_tiet();
        String tenSP = SPCTT.getTen_san_pham();
        int soluongcheck = Integer.parseInt(tbl_sanphamchitie.getValueAt(index, 8).toString());
        if (soluongcheck == 0) {
            JOptionPane.showMessageDialog(this, "Sản phẩm " + tenSP + " đã hết hàng, vui lòng chọn sản phẩm khác!");
            return;
        }
        for (int i = 0; i < ModelGioHang.getRowCount(); i++) {
            Object value = ModelGioHang.getValueAt(i, 0); // cột mã SPCT
            if (value != null && value.equals(maSPCT)) {
                int soLuongCu = Integer.parseInt(ModelGioHang.getValueAt(i, 7).toString());
                int soLuongMoi = soLuongCu + 1;
                ModelGioHang.setValueAt(soLuongMoi, i, 7); // update số lượng
                BigDecimal thanhTien = SPCTT.getDon_gia().multiply(BigDecimal.valueOf(soLuongMoi));
                ModelGioHang.setValueAt(toVietnameseMoney(thanhTien), i, 9); // update thành tiền
                return;
            }
        }
        Object MASPCT = tbl_sanphamchitie.getValueAt(index, 1).toString();
        Object TenSP = tbl_sanphamchitie.getValueAt(index, 2).toString();
        Object Coao = tbl_sanphamchitie.getValueAt(index, 3).toString();
        Object ThuongHieu = tbl_sanphamchitie.getValueAt(index, 4).toString();
        Object ChatLieu = tbl_sanphamchitie.getValueAt(index, 5).toString();
        Object MauSac = tbl_sanphamchitie.getValueAt(index, 6).toString();
        Object Size = tbl_sanphamchitie.getValueAt(index, 7).toString();
        int Soluong = 1;
        BigDecimal DonGia = fromVietnameseMoney(tbl_sanphamchitie.getValueAt(index, 9).toString());
        BigDecimal ThanhTien = DonGia.multiply(BigDecimal.valueOf(Soluong));

        ModelGioHang.addRow(new Object[]{
            MASPCT, TenSP, Coao, ThuongHieu, ChatLieu, MauSac, Size, Soluong, toVietnameseMoney(DonGia), toVietnameseMoney(ThanhTien), false
        }); 
        tbl_giohang.getColumnModel().getColumn(10).setCellEditor(new DefaultCellEditor(new JCheckBox()));
        tbl_giohang.getColumnModel().getColumn(10).setCellRenderer(tbl_giohang.getDefaultRenderer(Boolean.class));
        Sanphamchitiet SPCT = repoSPCT.IDSPCT(tbl_sanphamchitie.getValueAt(index, 1).toString());
        Hoadonchitiet HDCT = new Hoadonchitiet();
        HDCT.setID_san_pham_chi_tiet(SPCT.getID_san_pham_chi_tiet());
        HDCT.setID_hoa_don(Integer.parseInt(txt_hoadon.getText()));
        HDCT.setSo_luong(1);
        BigDecimal dongia = fromVietnameseMoney(tbl_sanphamchitie.getValueAt(index, 9).toString());
        HDCT.setDon_gia(dongia);
        repoHDCT.create(HDCT);
        fillToTablespchitiet();
        TongTienTamTinh();
        calculate_discount();
        totalamount();
    };
    
    public void deleteGioHang(String MSPCT) {
        Sanphamchitiet SPCT = repoSPCT.IDSPCT(MSPCT);
        int IDHD = Integer.parseInt(txt_hoadon.getText());
        int IDSPCT = SPCT.getID_san_pham_chi_tiet();
        Hoadonchitiet HDCT = repoHDCT.IDHDCT(IDHD, IDSPCT);
        if (HDCT != null) {
            repoHDCT.deleteById(HDCT.getID_hdct());
        }
    }

    private void addSanPhamByQR(String maQR) {
        if (maQR == null || maQR.trim().isEmpty()) {
            return;
        }
        Sanphamchitiet SPCT = repoSPCT.SPQRCODE(maQR.trim());
        if (SPCT == null) {
            JOptionPane.showMessageDialog(this, "Không tìm thấy sản phẩm!");
            return;
        }

        String thongTin = "Mã SPCT: " + SPCT.getMa_san_pham_chi_tiet() + "\n"
                + "Tên SP: " + SPCT.getTen_san_pham() + "\n"
                + "Thương hiệu: " + SPCT.getTen_thuong_hieu() + "\n"
                + "Màu: " + SPCT.getTen_mau() + "\n"
                + "Size: " + SPCT.getTen_size() + "\n"
                + "Đơn giá: " + toVietnameseMoney(SPCT.getDon_gia()) + " VND\n\n"
                + "Bạn có muốn thêm sản phẩm này vào giỏ hàng?";

        int confirm = JOptionPane.showConfirmDialog(this, thongTin, "Xác nhân thêm sản phẩm", JOptionPane.YES_OPTION);
        if (confirm != JOptionPane.YES_OPTION) {
            return;
        }
        String maSPCT = SPCT.getMa_san_pham_chi_tiet();
        ModelGioHang = (DefaultTableModel) tbl_giohang.getModel();
        if (ModelGioHang.getRowCount() > 0) {
            boolean Trong = true;
            for (int i = 0; i < ModelGioHang.getRowCount(); i++) {
                if (ModelGioHang.getValueAt(i, 0) != null) {
                    Trong = false;
                    break;
                }
            }
            if (Trong) {
                ModelGioHang.setRowCount(0);
            }
        }
        String tenSP = SPCT.getTen_san_pham();
        Sanphamchitiet SPCTCHECK = repoSPCT.IDSPCT(maQR);
        int soluongton = SPCTCHECK.getSo_luong_ton();
        if (soluongton == 0) {
            JOptionPane.showMessageDialog(this, "Sản phẩm " + tenSP + " đã hết hàng, vui lòng chọn sản phẩm khác!");
            return;
        }
        for (int i = 0; i < ModelGioHang.getRowCount(); i++) {
            Object value = ModelGioHang.getValueAt(i, 0);
            if (value != null && value.equals(maSPCT)) {
                int soLuongCu = Integer.parseInt(ModelGioHang.getValueAt(i, 7).toString());
                int soLuongMoi = soLuongCu + 1;
                ModelGioHang.setValueAt(soLuongMoi, i, 7); // update số lượng
                BigDecimal thanhTien = SPCT.getDon_gia().multiply(BigDecimal.valueOf(soLuongMoi));
                ModelGioHang.setValueAt(toVietnameseMoney(thanhTien), i, 9);
                return;
            }
        }
        String slInput = JOptionPane.showInputDialog(this, "Nhập số lượng: ");
        int soLuong = 1;

        if (slInput != null && !slInput.trim().isEmpty()) {
            try {
                soLuong = Integer.parseInt(slInput.trim());
                if (soLuong <= 0) {
                    soLuong = 1;
                }
            } catch (Exception e) {
                JOptionPane.showMessageDialog(this, "Số lượng phải là số và lớn hơn 0. số lượng sẽ được đặt về 1");
                soLuong = 1;
            }
        }
        if (soLuong > soluongton) {
            JOptionPane.showMessageDialog(this, "Sản phẩm " + tenSP + " chỉ còn tối đa: " + soluongton);
            soLuong = soluongton;
        }
        BigDecimal donGia = SPCT.getDon_gia();
        BigDecimal thanhTien = donGia.multiply(BigDecimal.valueOf(soLuong));

        Sanphamchitiet T = repoSPCT.IDSPCT(maQR.trim());
        Hoadonchitiet HDCT = new Hoadonchitiet();
        HDCT.setID_san_pham_chi_tiet(T.getID_san_pham_chi_tiet());
        HDCT.setID_hoa_don(Integer.parseInt(txt_hoadon.getText()));
        HDCT.setSo_luong(soLuong);
        HDCT.setDon_gia(donGia);
        repoHDCT.create(HDCT);
        ModelGioHang.addRow(new Object[]{
            SPCT.getMa_san_pham_chi_tiet(),
            SPCT.getTen_san_pham(),
            SPCT.getTen_co_ao(),
            SPCT.getTen_thuong_hieu(),
            SPCT.getTen_chat_lieu(),
            SPCT.getTen_mau(),
            SPCT.getTen_size(),
            soLuong,
            toVietnameseMoney(donGia),
            toVietnameseMoney(thanhTien),
            false 
        });
        TongTienTamTinh();
        calculate_discount();
        totalamount();
        fillToTablespchitiet();
    }
    private boolean Check_Giohang() {
        DefaultTableModel model = (DefaultTableModel) tbl_giohang.getModel();
        if (model.getRowCount() == 0) {
            JOptionPane.showMessageDialog(this, "Vui lòng thêm sản phẩm vào giỏ hàng trước khi thanh toán");
            return false;
        }
        for (int i = 0; i < model.getRowCount(); i++) {
            if (model.getValueAt(i, 0) != null) {
                return true;
            }
        }
        model.setRowCount(0);
        JOptionPane.showMessageDialog(this, "Vui lòng thêm sản phẩm vào giỏ hàng trước khi thanh toán");
        return false;
    }
    private void startCamera() {
        if (webcam != null) {
            return;
        }
        webcam = Webcam.getDefault();
        if (webcam == null) {
            JOptionPane.showMessageDialog(this, "Không tìm thấy webcam!");
            return;
        }
        webcam.setViewSize(new java.awt.Dimension(320, 240));
        webcamPanel = new WebcamPanel(webcam);
        webcamPanel.setFPSDisplayed(true);
        webcamPanel.setMirrored(true);
        panelWebcam.setLayout(new java.awt.BorderLayout());
        panelWebcam.add(webcamPanel, java.awt.BorderLayout.CENTER);
        panelWebcam.revalidate();
        webcamPanel.start();
        startQRScanner();
    }

    private void stopCamera() {
        if (qrTimer != null) {
            qrTimer.stop();
            qrTimer = null;
        }
        if (webcamPanel != null) {
            webcamPanel.stop();
            panelWebcam.remove(webcamPanel);
            panelWebcam.revalidate();
            panelWebcam.repaint();
            webcamPanel = null;
        }
        if (webcam != null) {
            webcam.close();
            webcam = null;
        }
        isScanning = true; 
    }
    private void startQRScanner() {
        qrTimer = new Timer(200, e -> {
            if (webcam == null || !webcam.isOpen()) {
                return;
            }
            try {
                BufferedImage image = webcam.getImage();
                if (image == null) {
                    return;
                }
                LuminanceSource source = new BufferedImageLuminanceSource(image);
                BinaryBitmap bitmap = new BinaryBitmap(new HybridBinarizer(source));
                Result result = new MultiFormatReader().decode(bitmap);
                if (result != null && isScanning) {
                    isScanning = false;
                    String maQR = result.getText().trim();
                    addSanPhamByQR(maQR);
                    new java.util.Timer().schedule(new java.util.TimerTask() {
                        @Override
                        public void run() {
                            isScanning = true;
                        }
                    }, 1000);
                }
            } catch (NotFoundException ex) {
            } catch (Exception ex) {
                ex.printStackTrace();
            }
        });
        qrTimer.start();
    }

    public void calculate_discount() {
        if (cbo_voucher.getSelectedItem().equals("Mời chọn Voucher")) {
            txt_tiengiam.setText("0");
            return;
        }
        String item = cbo_voucher.getSelectedItem().toString();
        String ma_code_voucher = item.split("\\|")[0].trim();
        Voucher VC = repoVoucher.VoucherBANHANG(ma_code_voucher);
        BigDecimal Tongtientamtinh = fromVietnameseMoney(txt_ttt.getText());
        BigDecimal Dieukien = VC.getDieu_kien();
        BigDecimal MucGiamToida = VC.getMuc_giam_toi_da();
        try {
            if (Tongtientamtinh.compareTo(Dieukien) >= 0) {
                if (VC.getLoai_giam_gia().equalsIgnoreCase("Tien")) {
                    txt_tiengiam.setText(toVietnameseMoney(VC.getGia_tri_giam()));
                } else {
                    BigDecimal phantramgiam = new BigDecimal(VC.getGia_tri_giam().toString());
                    BigDecimal Giatrigiam = Tongtientamtinh.multiply(phantramgiam).divide(new BigDecimal("100"));
                    if (MucGiamToida.compareTo(Giatrigiam) >= 0) {
                        txt_tiengiam.setText(toVietnameseMoney(Giatrigiam));
                    } else {
                        txt_tiengiam.setText(toVietnameseMoney(MucGiamToida));
                    }
                }
            } else {
                JOptionPane.showMessageDialog(this, "Hóa đơn của bạn không đủ điều kiện áp dụng voucher" + "(Điều kiện giảm voucher: " + ma_code_voucher + " Là: " + toVietnameseMoney(Dieukien) + ")");
                cbo_voucher.setSelectedItem("Mời chọn Voucher");
            }
            if (!cbo_voucher.getSelectedItem().equals("Mời chọn Voucher")) {
                totalamount();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void totalamount() {
        BigDecimal Tongtientamtinh = fromVietnameseMoney(txt_ttt.getText());
        BigDecimal giamVoucher;
        if (!txt_tiengiam.getText().isEmpty()) {
            giamVoucher = fromVietnameseMoney(txt_tiengiam.getText());
        } else {
            giamVoucher = new BigDecimal("0");
        }
        BigDecimal Tongtienthanhtoan = Tongtientamtinh.subtract(giamVoucher);
        txt_tienhang.setText(toVietnameseMoney(Tongtienthanhtoan));
    }

    public void INPDF(String file, int ID_hoadon) {
        try {
            DateTimeFormatter fm = DateTimeFormatter.ofPattern("HH:mm:ss dd-MM-yyyy");
            String time = java.time.LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH-mm-ss_dd-MM-yyyy"));
            String fileName = "Phieu_Tam_Tinh_" + time + ".pdf";
            String fullPath = file + File.separator + fileName;
            PdfWriter writer = new PdfWriter(fullPath);
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);
            Hoadon HD = repoHD.INHOADONA(Integer.parseInt(txt_hoadon.getText()));
            List<Hoadonchitiet> HDCT = repoHDCT.LISTHDCTINPDF(ID_hoadon);
            PdfFont Font_chinh = PdfFontFactory.createFont("J:/Vestra_HN2025/Font/static/Roboto-ExtraBold.ttf", PdfEncodings.IDENTITY_H, PdfFontFactory.EmbeddingStrategy.PREFER_EMBEDDED);
            PdfFont Font_phu = PdfFontFactory.createFont("J:/Vestra_HN2025/Font/static/Roboto-Italic.ttf", PdfEncodings.IDENTITY_H, PdfFontFactory.EmbeddingStrategy.PREFER_EMBEDDED);

            document.add(new Paragraph("PHIẾU TẠM TÍNH - VESTRA").setFont(Font_chinh).setFontSize(18));

            document.add(new Paragraph("Tên Khách hàng: " + HD.getTen_khach_hang()).setFont(Font_phu));
            document.add(new Paragraph("Tên Nhân viên: " + HD.getTen_nhan_vien()).setFont(Font_phu));
            document.add(new Paragraph("Ngày lập: " + HD.getNgay_lap_hoa_don().format(fm)).setFont(Font_phu));
            document.add(new Paragraph("Tổng tiền tạm tính: " + txt_ttt.getText()).setFont(Font_phu));

            Table table = new Table(new float[]{4, 2, 2, 2});
            table.setWidth(UnitValue.createPercentValue(100));
            table.addHeaderCell(new Cell().add(new Paragraph("Tên sản phẩm").setFont(Font_phu)));
            table.addHeaderCell(new Cell().add(new Paragraph("Số lượng").setFont(Font_phu)));
            table.addHeaderCell(new Cell().add(new Paragraph("Đơn giá").setFont(Font_phu)));
            table.addHeaderCell(new Cell().add(new Paragraph("Thành tiền").setFont(Font_phu)));
            for (Hoadonchitiet HDCT1 : HDCT) {
                table.addCell(new Cell().add(new Paragraph(HDCT1.getTen_san_pham()).setFont(Font_phu)));
                table.addCell(new Cell().add(new Paragraph(String.valueOf(HDCT1.getSo_luong())).setFont(Font_phu)));
                table.addCell(new Cell().add(new Paragraph(String.valueOf(toVietnameseMoney(HDCT1.getDon_gia()))).setFont(Font_phu)));
                table.addCell(new Cell().add(new Paragraph(String.valueOf(toVietnameseMoney(HDCT1.getThanh_tien()))).setFont(Font_phu)));
            }
            table.addCell(new Cell().add(new Paragraph("Tổng tiền tạm tính").setFont(Font_chinh)));
            table.addCell(new Cell());
            table.addCell(new Cell());
            table.addCell(new Cell().add(new Paragraph(txt_ttt.getText()).setFont(Font_chinh)));

            table.addCell(new Cell().add(new Paragraph("Trạng thái thanh toán").setFont(Font_chinh)));
            table.addCell(new Cell());
            table.addCell(new Cell());
            table.addCell(new Cell().add(new Paragraph("Chưa thanh toán").setFont(Font_chinh)));

            document.add(table);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    public void UPDATETHANHTOAN() {
        if (cbo_voucher.getSelectedItem().equals("Mời chọn Voucher")) {
            UPDATENOVOUCHER();
        } else {
            UPDATEYESVOUCHER();
        }
    }
    public void INHOADON() {
        int yes = JOptionPane.showConfirmDialog(this, "Bạn có muốn in hóa đơn không?");
        if (yes == JOptionPane.YES_OPTION) {
            int id_hoa_don = Integer.parseInt(txt_hoadon.getText());
            INPDFHD("J:\\Vestra_HN2025\\QUAN LY HOA DON\\Hoa don", id_hoa_don);
            JOptionPane.showMessageDialog(this, "In hóa đơn thành công");
        }
    }
    public void CHECKBANKING(int status) {
        SwingUtilities.invokeLater(() -> {
            if (status == 1) {
                UPDATETHANHTOAN();
                INHOADON();
                JOptionPane.showMessageDialog(this, "Thanh Toán Thành Công");
                ModelGioHang.setRowCount(0);
                fillToTableHD();
                Lammoi();
            } else {
                JOptionPane.showMessageDialog(this, "Bạn đã hủy thanh toán");
            }

        });
    }
    public void ThanhToanChuyenKhoan(String TongTien, String IDHOADON) {
        if (CHECKHD == 1) {
            return;
        }
        BigDecimal tt = fromVietnameseMoney(TongTien);
        FORM_QR_BANKING form = new FORM_QR_BANKING(tt, IDHOADON, (status) -> {
            CHECKBANKING(status);
        }
        );
        form.setVisible(true);
        form.setLocationRelativeTo(null);
    }
    public void INPDFHD(String file, int ID_hoadon) {
        try {
            DateTimeFormatter fm = DateTimeFormatter.ofPattern("HH:mm:ss dd-MM-yyyy");
            String time = java.time.LocalDateTime.now().format(DateTimeFormatter.ofPattern("HH-mm-ss_dd-MM-yyyy"));
            String fileName = "Phieu_Tam_Tinh_" + time + ".pdf";
            String fullPath = file + File.separator + fileName;
            PdfWriter writer = new PdfWriter(fullPath);
            PdfDocument pdf = new PdfDocument(writer);
            Document document = new Document(pdf);
            Hoadon HD = repoHD.INHOADONA(Integer.parseInt(txt_hoadon.getText()));
            List<Hoadonchitiet> HDCT = repoHDCT.LISTHDCTINPDF(ID_hoadon);
            PdfFont Font_chinh = PdfFontFactory.createFont("J:/Vestra_HN2025/Font/static/Roboto-ExtraBold.ttf", PdfEncodings.IDENTITY_H, PdfFontFactory.EmbeddingStrategy.PREFER_EMBEDDED);
            PdfFont Font_phu = PdfFontFactory.createFont("J:/Vestra_HN2025/Font/static/Roboto-Italic.ttf", PdfEncodings.IDENTITY_H, PdfFontFactory.EmbeddingStrategy.PREFER_EMBEDDED);

            document.add(new Paragraph("Hóa Đơn - VESTRA").setFont(Font_chinh).setFontSize(18));

            document.add(new Paragraph("Tên Khách hàng: " + HD.getTen_khach_hang()).setFont(Font_phu));
            document.add(new Paragraph("Tên Nhân viên: " + HD.getTen_nhan_vien()).setFont(Font_phu));
            document.add(new Paragraph("Ngày lập: " + HD.getNgay_lap_hoa_don().format(fm)).setFont(Font_phu));
            document.add(new Paragraph("Tổng tiền: " + txt_ttt.getText()).setFont(Font_phu));

            Table table = new Table(new float[]{4, 2, 2, 2});
            table.setWidth(UnitValue.createPercentValue(100));
            table.addHeaderCell(new Cell().add(new Paragraph("Tên sản phẩm").setFont(Font_phu)));
            table.addHeaderCell(new Cell().add(new Paragraph("Số lượng").setFont(Font_phu)));
            table.addHeaderCell(new Cell().add(new Paragraph("Đơn giá").setFont(Font_phu)));
            table.addHeaderCell(new Cell().add(new Paragraph("Thành tiền").setFont(Font_phu)));
            for (Hoadonchitiet HDCT1 : HDCT) {
                table.addCell(new Cell().add(new Paragraph(HDCT1.getTen_san_pham()).setFont(Font_phu)));
                table.addCell(new Cell().add(new Paragraph(String.valueOf(HDCT1.getSo_luong())).setFont(Font_phu)));
                table.addCell(new Cell().add(new Paragraph(String.valueOf(toVietnameseMoney(HDCT1.getDon_gia()))).setFont(Font_phu)));
                table.addCell(new Cell().add(new Paragraph(String.valueOf(toVietnameseMoney(HDCT1.getThanh_tien()))).setFont(Font_phu)));
            }
            if (!txt_tiengiam.equals("0")) {
                table.addCell(new Cell().add(new Paragraph("Giảm giá").setFont(Font_chinh)));
                table.addCell(new Cell());
                table.addCell(new Cell());
                table.addCell(new Cell().add(new Paragraph("- " + txt_tiengiam.getText()).setFont(Font_chinh)));
            }
            table.addCell(new Cell().add(new Paragraph("Tổng tiền").setFont(Font_chinh)));
            table.addCell(new Cell());
            table.addCell(new Cell());
            table.addCell(new Cell().add(new Paragraph(txt_tienhang.getText()).setFont(Font_chinh)));

            table.addCell(new Cell().add(new Paragraph("Trạng thái thanh toán").setFont(Font_chinh)));
            table.addCell(new Cell());
            table.addCell(new Cell());
            table.addCell(new Cell().add(new Paragraph("Đã thanh toán").setFont(Font_chinh)));

            document.add(table);
            document.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean Check() {
        if (txt_hoadon.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "Vui vào chọn hóa đơn!");
            return false;
        } else if (txt_manv.getText().isEmpty()) {
            JOptionPane.showMessageDialog(this, "vui lòng đăng nhập tài khoản!");
            return false;
        }
        return true;
    }

    public void hienthilabel() {
        // phần này là để làm tang defaultPadding cho lbl(Không chỉnh sửa nhé)
        // Đảm bảo label trong suốt
        lblBaoCaoThongKe.setBackground(null);
        lblBaoCaoThongKe.setOpaque(false);

        lblsanpham.setBackground(null);
        lblsanpham.setOpaque(false);

        lblbanhang.setBackground(null);
        lblbanhang.setOpaque(false);

        lblgiamgia.setBackground(null);
        lblgiamgia.setOpaque(false);

        lblhoadon.setBackground(null);
        lblhoadon.setOpaque(false);

        lblnhanvien.setBackground(null);
        lblnhanvien.setOpaque(false);

        lblquanlykhachhang.setBackground(null);
        lblquanlykhachhang.setOpaque(false);

        lbldangnhap.setBackground(null);
        lbldangnhap.setOpaque(false);

        lbldangxuat.setBackground(null);
        lbldangxuat.setOpaque(false);
        // Padding Gốc (Lùi sâu vào 25px): Kích thước cố định.
        javax.swing.border.Border defaultPadding = javax.swing.BorderFactory.createEmptyBorder(10, 10, 10, 10);
        lblBaoCaoThongKe.setBorder(defaultPadding);
        lblsanpham.setBorder(defaultPadding);
        lblbanhang.setBorder(defaultPadding);
        lblgiamgia.setBorder(defaultPadding);
        lblhoadon.setBorder(defaultPadding);
        lblnhanvien.setBorder(defaultPadding);
        lblquanlykhachhang.setBorder(defaultPadding);
        lbldangnhap.setBorder(defaultPadding);
        lbldangxuat.setBorder(defaultPadding);

    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        rdo_gr = new javax.swing.ButtonGroup();
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        lblquanlykhachhang = new javax.swing.JLabel();
        lblsanpham = new javax.swing.JLabel();
        lbldangnhap = new javax.swing.JLabel();
        lblbanhang = new javax.swing.JLabel();
        lblnhanvien = new javax.swing.JLabel();
        lblhoadon = new javax.swing.JLabel();
        lblgiamgia = new javax.swing.JLabel();
        lblBaoCaoThongKe = new javax.swing.JLabel();
        lbldangxuat = new javax.swing.JLabel();
        jPanel4 = new javax.swing.JPanel();
        jLabel1 = new javax.swing.JLabel();
        jPanel3 = new javax.swing.JPanel();
        jPanel5 = new javax.swing.JPanel();
        btn_camera = new javax.swing.JButton();
        panecam = new javax.swing.JPanel();
        panelWebcam = new javax.swing.JPanel();
        jPanel9 = new javax.swing.JPanel();
        jScrollPane4 = new javax.swing.JScrollPane();
        tbl_hoadon = new javax.swing.JTable();
        btn_xoahd = new javax.swing.JButton();
        jPanel6 = new javax.swing.JPanel();
        jScrollPane3 = new javax.swing.JScrollPane();
        tbl_giohang = new javax.swing.JTable();
        btn_xoasp = new javax.swing.JButton();
        jPanel7 = new javax.swing.JPanel();
        jScrollPane2 = new javax.swing.JScrollPane();
        tbl_sanphamchitie = new javax.swing.JTable();
        jLabel10 = new javax.swing.JLabel();
        txt_timkiemsanpham = new javax.swing.JTextField();
        btn_timkiem = new javax.swing.JButton();
        btn_lammoi = new javax.swing.JButton();
        jPanel8 = new javax.swing.JPanel();
        jLabel2 = new javax.swing.JLabel();
        txt_tenkhach = new javax.swing.JTextField();
        jSeparator1 = new javax.swing.JSeparator();
        jLabel3 = new javax.swing.JLabel();
        txt_sodt = new javax.swing.JTextField();
        jLabel4 = new javax.swing.JLabel();
        jLabel5 = new javax.swing.JLabel();
        jLabel6 = new javax.swing.JLabel();
        txt_ttt = new javax.swing.JTextField();
        jLabel7 = new javax.swing.JLabel();
        txt_tiengiam = new javax.swing.JTextField();
        jLabel8 = new javax.swing.JLabel();
        jSeparator2 = new javax.swing.JSeparator();
        txt_tienhang = new javax.swing.JTextField();
        txt_tienkhachdua = new javax.swing.JTextField();
        btn_thanhtoan = new javax.swing.JButton();
        btn_taohoadon = new javax.swing.JButton();
        btn_huy = new javax.swing.JButton();
        jLabel9 = new javax.swing.JLabel();
        txt_manv = new javax.swing.JTextField();
        cbo_voucher = new javax.swing.JComboBox<>();
        txt_tienthoi = new javax.swing.JTextField();
        jLabel11 = new javax.swing.JLabel();
        txt_ghichu = new javax.swing.JTextField();
        jLabel12 = new javax.swing.JLabel();
        btn_tamtinh = new javax.swing.JButton();
        btn_timkiem1 = new javax.swing.JButton();
        jLabel13 = new javax.swing.JLabel();
        txt_hoadon = new javax.swing.JTextField();
        jLabel14 = new javax.swing.JLabel();
        rdo_chuyenkhoan = new javax.swing.JRadioButton();
        rdo_tienmat = new javax.swing.JRadioButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setLayout(null);

        jPanel2.setBackground(new java.awt.Color(19, 0, 160));

        lblquanlykhachhang.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblquanlykhachhang.setForeground(new java.awt.Color(255, 255, 255));
        lblquanlykhachhang.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\KhachHang.png")); // NOI18N
        lblquanlykhachhang.setText("Quản lý khách hàng");
        lblquanlykhachhang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblquanlykhachhangMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblquanlykhachhangMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblquanlykhachhangMouseExited(evt);
            }
        });

        lblsanpham.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblsanpham.setForeground(new java.awt.Color(255, 255, 255));
        lblsanpham.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\quanlisanpham.png")); // NOI18N
        lblsanpham.setText("Quản lý sản phẩm");
        lblsanpham.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblsanphamMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblsanphamMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblsanphamMouseExited(evt);
            }
        });

        lbldangnhap.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbldangnhap.setForeground(new java.awt.Color(255, 255, 255));
        lbldangnhap.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\dangnhap.png")); // NOI18N
        lbldangnhap.setText("Đăng nhập");
        lbldangnhap.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbldangnhapMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbldangnhapMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbldangnhapMouseExited(evt);
            }
        });

        lblbanhang.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblbanhang.setForeground(new java.awt.Color(255, 255, 255));
        lblbanhang.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\banhang.png")); // NOI18N
        lblbanhang.setText("Quản lý bán hàng");
        lblbanhang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblbanhangMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblbanhangMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblbanhangMouseExited(evt);
            }
        });

        lblnhanvien.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblnhanvien.setForeground(new java.awt.Color(255, 255, 255));
        lblnhanvien.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\nhanvien.png")); // NOI18N
        lblnhanvien.setText("Quản lý nhân viên");
        lblnhanvien.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblnhanvienMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblnhanvienMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblnhanvienMouseExited(evt);
            }
        });

        lblhoadon.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblhoadon.setForeground(new java.awt.Color(255, 255, 255));
        lblhoadon.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\hoadon.png")); // NOI18N
        lblhoadon.setText("Quản lý hóa đơn");
        lblhoadon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblhoadonMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblhoadonMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblhoadonMouseExited(evt);
            }
        });

        lblgiamgia.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblgiamgia.setForeground(new java.awt.Color(255, 255, 255));
        lblgiamgia.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\giamgia.png")); // NOI18N
        lblgiamgia.setText("Giảm giá");
        lblgiamgia.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblgiamgiaMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblgiamgiaMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblgiamgiaMouseExited(evt);
            }
        });

        lblBaoCaoThongKe.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lblBaoCaoThongKe.setForeground(new java.awt.Color(255, 255, 255));
        lblBaoCaoThongKe.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\B1.png")); // NOI18N
        lblBaoCaoThongKe.setText("Báo cáo thông kê");
        lblBaoCaoThongKe.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lblBaoCaoThongKeMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lblBaoCaoThongKeMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lblBaoCaoThongKeMouseExited(evt);
            }
        });

        lbldangxuat.setFont(new java.awt.Font("Segoe UI", 1, 12)); // NOI18N
        lbldangxuat.setForeground(new java.awt.Color(255, 255, 255));
        lbldangxuat.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\dangxuat.png")); // NOI18N
        lbldangxuat.setText("Đăng xuất");
        lbldangxuat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                lbldangxuatMouseClicked(evt);
            }
            public void mouseEntered(java.awt.event.MouseEvent evt) {
                lbldangxuatMouseEntered(evt);
            }
            public void mouseExited(java.awt.event.MouseEvent evt) {
                lbldangxuatMouseExited(evt);
            }
        });

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(lblhoadon, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblBaoCaoThongKe, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblsanpham, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblbanhang, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblgiamgia, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblnhanvien, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lblquanlykhachhang, javax.swing.GroupLayout.DEFAULT_SIZE, 178, Short.MAX_VALUE)
                    .addComponent(lbldangnhap, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(lbldangxuat, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap())
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(44, 44, 44)
                .addComponent(lblBaoCaoThongKe, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblsanpham, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblbanhang, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblgiamgia, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblhoadon, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblnhanvien, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lblquanlykhachhang, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbldangnhap, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(18, 18, 18)
                .addComponent(lbldangxuat, javax.swing.GroupLayout.PREFERRED_SIZE, 38, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(270, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel2);
        jPanel2.setBounds(0, 100, 190, 800);

        jPanel4.setBackground(new java.awt.Color(19, 0, 160));
        jPanel4.setPreferredSize(new java.awt.Dimension(1455, 143));

        jLabel1.setIcon(new javax.swing.ImageIcon("J:\\Vestra_HN2025\\VESTRA\\src\\main\\java\\RES\\LOGO(TO).png")); // NOI18N
        jLabel1.setText("jLabel1");

        javax.swing.GroupLayout jPanel4Layout = new javax.swing.GroupLayout(jPanel4);
        jPanel4.setLayout(jPanel4Layout);
        jPanel4Layout.setHorizontalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 1511, Short.MAX_VALUE)
                .addGap(1051, 1051, 1051))
        );
        jPanel4Layout.setVerticalGroup(
            jPanel4Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel4Layout.createSequentialGroup()
                .addComponent(jLabel1, javax.swing.GroupLayout.PREFERRED_SIZE, 143, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(0, 0, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel4);
        jPanel4.setBounds(0, 0, 1500, 100);

        jPanel3.setBackground(new java.awt.Color(255, 255, 255));
        jPanel3.setPreferredSize(new java.awt.Dimension(1300, 820));

        jPanel5.setBackground(new java.awt.Color(255, 255, 255));
        jPanel5.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Hóa đơn", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        btn_camera.setBackground(new java.awt.Color(19, 0, 194));
        btn_camera.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_camera.setForeground(new java.awt.Color(255, 255, 255));
        btn_camera.setText("Bật Camera");
        btn_camera.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_cameraActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout panelWebcamLayout = new javax.swing.GroupLayout(panelWebcam);
        panelWebcam.setLayout(panelWebcamLayout);
        panelWebcamLayout.setHorizontalGroup(
            panelWebcamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 320, Short.MAX_VALUE)
        );
        panelWebcamLayout.setVerticalGroup(
            panelWebcamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 241, Short.MAX_VALUE)
        );

        javax.swing.GroupLayout panecamLayout = new javax.swing.GroupLayout(panecam);
        panecam.setLayout(panecamLayout);
        panecamLayout.setHorizontalGroup(
            panecamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelWebcam, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        panecamLayout.setVerticalGroup(
            panecamLayout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(panelWebcam, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );

        jPanel9.setBackground(new java.awt.Color(255, 255, 255));

        tbl_hoadon.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null},
                {null, null, null, null, null}
            },
            new String [] {
                "ID hóa đơn", "Tên nhân viên", "Tên Khách hàng", "Trạng thái", "Ngày tạo"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_hoadon.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_hoadonMouseClicked(evt);
            }
        });
        jScrollPane4.setViewportView(tbl_hoadon);

        javax.swing.GroupLayout jPanel9Layout = new javax.swing.GroupLayout(jPanel9);
        jPanel9.setLayout(jPanel9Layout);
        jPanel9Layout.setHorizontalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 632, Short.MAX_VALUE)
            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel9Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 638, Short.MAX_VALUE)
                    .addContainerGap()))
        );
        jPanel9Layout.setVerticalGroup(
            jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGap(0, 224, Short.MAX_VALUE)
            .addGroup(jPanel9Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                .addGroup(jPanel9Layout.createSequentialGroup()
                    .addContainerGap()
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 212, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)))
        );

        btn_xoahd.setBackground(new java.awt.Color(19, 0, 194));
        btn_xoahd.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_xoahd.setForeground(new java.awt.Color(255, 255, 255));
        btn_xoahd.setText("Hủy hóa đơn");
        btn_xoahd.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_xoahdActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel5Layout = new javax.swing.GroupLayout(jPanel5);
        jPanel5.setLayout(jPanel5Layout);
        jPanel5Layout.setHorizontalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel5Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jPanel9, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addGap(6, 6, 6)
                        .addComponent(btn_camera)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_xoahd)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(panecam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap())
        );
        jPanel5Layout.setVerticalGroup(
            jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel5Layout.createSequentialGroup()
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(panecam, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel5Layout.createSequentialGroup()
                        .addComponent(jPanel9, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addGroup(jPanel5Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                            .addComponent(btn_camera)
                            .addComponent(btn_xoahd)))))
        );

        jPanel6.setBackground(new java.awt.Color(255, 255, 255));
        jPanel6.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Sản phẩm thanh toán", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        tbl_giohang.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã sản phẩm chi tiết", "Tên sản phẩm", "Tên cổ áo", "Thương hiệu", "Chất liệu", "Màu sắc", "Size", "Số lượng", "Đơn giá", "Thành tiền", "Chọn"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Object.class, java.lang.Boolean.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, true, false, false, true
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_giohang.setCursor(new java.awt.Cursor(java.awt.Cursor.DEFAULT_CURSOR));
        tbl_giohang.addAncestorListener(new javax.swing.event.AncestorListener() {
            public void ancestorAdded(javax.swing.event.AncestorEvent evt) {
                tbl_giohangAncestorAdded(evt);
            }
            public void ancestorMoved(javax.swing.event.AncestorEvent evt) {
            }
            public void ancestorRemoved(javax.swing.event.AncestorEvent evt) {
                tbl_giohangAncestorRemoved(evt);
            }
        });
        tbl_giohang.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_giohangMouseClicked(evt);
            }
        });
        jScrollPane3.setViewportView(tbl_giohang);

        btn_xoasp.setBackground(new java.awt.Color(19, 0, 194));
        btn_xoasp.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_xoasp.setForeground(new java.awt.Color(255, 255, 255));
        btn_xoasp.setText("Xóa");
        btn_xoasp.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_xoaspActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel6Layout = new javax.swing.GroupLayout(jPanel6);
        jPanel6.setLayout(jPanel6Layout);
        jPanel6Layout.setHorizontalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane3, javax.swing.GroupLayout.DEFAULT_SIZE, 964, Short.MAX_VALUE)
                    .addGroup(jPanel6Layout.createSequentialGroup()
                        .addComponent(btn_xoasp)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel6Layout.setVerticalGroup(
            jPanel6Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel6Layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(jScrollPane3, javax.swing.GroupLayout.PREFERRED_SIZE, 165, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_xoasp)
                .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
        );

        jPanel7.setBackground(new java.awt.Color(255, 255, 255));
        jPanel7.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Danh sách sản phẩm", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        tbl_sanphamchitie.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null},
                {null, null, null, null, null, null, null, null, null, null, null}
            },
            new String [] {
                "Mã sản phẩm", "Mã Sản phẩm chi tiết", "Tên sản phẩm", "Tên cổ áo", "Thương hiệu", "Chất liệu", "Màu sắc", "Size", "Số lượng", "Đơn giá", "Trạng thái"
            }
        ) {
            boolean[] canEdit = new boolean [] {
                false, false, false, false, false, false, false, false, false, false, false
            };

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        tbl_sanphamchitie.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                tbl_sanphamchitieMouseClicked(evt);
            }
        });
        jScrollPane2.setViewportView(tbl_sanphamchitie);

        jLabel10.setText("Tên sản phẩm | Thương hiệu :");

        btn_timkiem.setBackground(new java.awt.Color(19, 0, 194));
        btn_timkiem.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_timkiem.setForeground(new java.awt.Color(255, 255, 255));
        btn_timkiem.setText("Tìm kiếm");
        btn_timkiem.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_timkiemActionPerformed(evt);
            }
        });

        btn_lammoi.setBackground(new java.awt.Color(19, 0, 194));
        btn_lammoi.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_lammoi.setForeground(new java.awt.Color(255, 255, 255));
        btn_lammoi.setText("Làm mới");
        btn_lammoi.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_lammoiActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel7Layout = new javax.swing.GroupLayout(jPanel7);
        jPanel7.setLayout(jPanel7Layout);
        jPanel7Layout.setHorizontalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 955, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addGroup(jPanel7Layout.createSequentialGroup()
                        .addComponent(jLabel10, javax.swing.GroupLayout.PREFERRED_SIZE, 160, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(txt_timkiemsanpham, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(btn_timkiem)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(btn_lammoi)))
                .addContainerGap(15, Short.MAX_VALUE))
        );
        jPanel7Layout.setVerticalGroup(
            jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel7Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel7Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel10)
                    .addComponent(txt_timkiemsanpham, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_timkiem)
                    .addComponent(btn_lammoi))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                .addComponent(jScrollPane2, javax.swing.GroupLayout.PREFERRED_SIZE, 130, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(17, 17, 17))
        );

        jPanel8.setBackground(new java.awt.Color(255, 255, 255));
        jPanel8.setBorder(javax.swing.BorderFactory.createTitledBorder(null, "Thanh toán", javax.swing.border.TitledBorder.DEFAULT_JUSTIFICATION, javax.swing.border.TitledBorder.TOP));

        jLabel2.setText("Tên khách hàng:");

        jLabel3.setText("Số điện thoại:");

        jLabel4.setText("Tiền khách đưa:");

        jLabel5.setText("Mã voucher:");

        jLabel6.setText("Tiền tạm tính:");

        txt_ttt.setBorder(null);

        jLabel7.setText("Tiền giảm:");

        txt_tiengiam.setBorder(null);

        jLabel8.setText("Tổng tiền hàng:");

        txt_tienhang.setText("0");
        txt_tienhang.setBorder(null);

        btn_thanhtoan.setBackground(new java.awt.Color(19, 0, 194));
        btn_thanhtoan.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_thanhtoan.setForeground(new java.awt.Color(255, 255, 255));
        btn_thanhtoan.setText("THANH TOÁN");
        btn_thanhtoan.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_thanhtoanActionPerformed(evt);
            }
        });

        btn_taohoadon.setBackground(new java.awt.Color(46, 204, 113));
        btn_taohoadon.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_taohoadon.setForeground(new java.awt.Color(255, 255, 255));
        btn_taohoadon.setText("TẠO HÓA ĐƠN");
        btn_taohoadon.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_taohoadonActionPerformed(evt);
            }
        });

        btn_huy.setBackground(new java.awt.Color(255, 0, 0));
        btn_huy.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_huy.setForeground(new java.awt.Color(255, 255, 255));
        btn_huy.setText("HUY");
        btn_huy.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_huyActionPerformed(evt);
            }
        });

        jLabel9.setText("Mã nhân viên:");

        txt_manv.setBorder(null);

        cbo_voucher.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "Item 1", "Item 2", "Item 3", "Item 4" }));
        cbo_voucher.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                cbo_voucherActionPerformed(evt);
            }
        });

        jLabel11.setText("Tiền thừa:");

        jLabel12.setText("Ghi chú:");

        btn_tamtinh.setBackground(new java.awt.Color(0, 255, 0));
        btn_tamtinh.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_tamtinh.setForeground(new java.awt.Color(255, 255, 255));
        btn_tamtinh.setText("PHIẾU TẠM TÍNH");
        btn_tamtinh.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_tamtinhActionPerformed(evt);
            }
        });

        btn_timkiem1.setBackground(new java.awt.Color(19, 0, 194));
        btn_timkiem1.setFont(new java.awt.Font("Segoe UI", 1, 14)); // NOI18N
        btn_timkiem1.setForeground(new java.awt.Color(255, 255, 255));
        btn_timkiem1.setText("Tìm khách hàng");
        btn_timkiem1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btn_timkiem1ActionPerformed(evt);
            }
        });

        jLabel13.setText("ID hóa đơn");

        txt_hoadon.setBorder(null);

        jLabel14.setText("Phương thức:");

        rdo_gr.add(rdo_chuyenkhoan);
        rdo_chuyenkhoan.setText("Chuyển khoản");
        rdo_chuyenkhoan.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rdo_chuyenkhoanMouseClicked(evt);
            }
        });

        rdo_gr.add(rdo_tienmat);
        rdo_tienmat.setText("Tiền mặt");
        rdo_tienmat.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mouseClicked(java.awt.event.MouseEvent evt) {
                rdo_tienmatMouseClicked(evt);
            }
        });

        javax.swing.GroupLayout jPanel8Layout = new javax.swing.GroupLayout(jPanel8);
        jPanel8.setLayout(jPanel8Layout);
        jPanel8Layout.setHorizontalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jSeparator1)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addComponent(btn_taohoadon, javax.swing.GroupLayout.PREFERRED_SIZE, 116, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(8, 8, 8)
                        .addComponent(btn_huy, javax.swing.GroupLayout.DEFAULT_SIZE, 131, Short.MAX_VALUE))
                    .addComponent(btn_thanhtoan, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(jLabel2)
                            .addComponent(jLabel3))
                        .addGap(18, 18, 18)
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addComponent(txt_sodt)
                            .addComponent(txt_tenkhach)))
                    .addComponent(btn_tamtinh, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jSeparator2)
                    .addGroup(jPanel8Layout.createSequentialGroup()
                        .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel5)
                                    .addComponent(jLabel6)
                                    .addComponent(jLabel9)
                                    .addComponent(jLabel13)
                                    .addComponent(jLabel7))
                                .addGap(18, 18, 18)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING, false)
                                    .addComponent(txt_manv)
                                    .addComponent(cbo_voucher, javax.swing.GroupLayout.Alignment.LEADING, 0, 155, Short.MAX_VALUE)
                                    .addComponent(txt_ttt)
                                    .addComponent(txt_tiengiam)
                                    .addComponent(txt_tienhang)
                                    .addComponent(txt_hoadon)))
                            .addComponent(btn_timkiem1)
                            .addGroup(jPanel8Layout.createSequentialGroup()
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(jLabel8)
                                    .addComponent(jLabel4)
                                    .addComponent(jLabel11)
                                    .addComponent(jLabel12)
                                    .addComponent(jLabel14))
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                                    .addComponent(rdo_chuyenkhoan, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(rdo_tienmat, javax.swing.GroupLayout.PREFERRED_SIZE, 98, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txt_ghichu)
                                    .addComponent(txt_tienkhachdua, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.DEFAULT_SIZE, 158, Short.MAX_VALUE)
                                    .addComponent(txt_tienthoi, javax.swing.GroupLayout.Alignment.TRAILING))))
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        jPanel8Layout.setVerticalGroup(
            jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel8Layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel2)
                    .addComponent(txt_tenkhach, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(16, 16, 16)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_sodt, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel3))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_timkiem1)
                .addGap(1, 1, 1)
                .addComponent(jSeparator1, javax.swing.GroupLayout.PREFERRED_SIZE, 10, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel13)
                    .addComponent(txt_hoadon, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(14, 14, 14)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jLabel9)
                    .addComponent(txt_manv, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel5)
                    .addComponent(cbo_voucher, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel6)
                    .addComponent(txt_ttt))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_tiengiam, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel7))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel8)
                    .addComponent(txt_tienhang, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel4)
                    .addComponent(txt_tienkhachdua, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_tienthoi, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel11))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(txt_ghichu, javax.swing.GroupLayout.PREFERRED_SIZE, 22, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel12))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel14)
                    .addComponent(rdo_chuyenkhoan))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 7, Short.MAX_VALUE)
                .addComponent(rdo_tienmat)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(jSeparator2, javax.swing.GroupLayout.PREFERRED_SIZE, 11, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(btn_thanhtoan, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(jPanel8Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(btn_huy, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(btn_taohoadon, javax.swing.GroupLayout.Alignment.TRAILING, javax.swing.GroupLayout.PREFERRED_SIZE, 39, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(btn_tamtinh, javax.swing.GroupLayout.PREFERRED_SIZE, 55, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(39, Short.MAX_VALUE))
        );

        javax.swing.GroupLayout jPanel3Layout = new javax.swing.GroupLayout(jPanel3);
        jPanel3.setLayout(jPanel3Layout);
        jPanel3Layout.setHorizontalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(198, 198, 198)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(jPanel6, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel7, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jPanel5, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(27, 27, 27))
        );
        jPanel3Layout.setVerticalGroup(
            jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel3Layout.createSequentialGroup()
                .addGap(124, 124, 124)
                .addGroup(jPanel3Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(jPanel3Layout.createSequentialGroup()
                        .addComponent(jPanel5, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel6, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(jPanel7, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(jPanel8, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap(36, Short.MAX_VALUE))
        );

        jPanel1.add(jPanel3);
        jPanel3.setBounds(0, 0, 1500, 900);

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 1499, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, 882, Short.MAX_VALUE)
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void lblBaoCaoThongKeMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBaoCaoThongKeMouseEntered
// TODO add your handling code here:
        lblBaoCaoThongKe.setBackground(new java.awt.Color(70, 130, 180));
        lblBaoCaoThongKe.setOpaque(true);
        lblBaoCaoThongKe.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblBaoCaoThongKeMouseEntered

    private void lblBaoCaoThongKeMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBaoCaoThongKeMouseExited
        // TODO add your handling code here:
        lblBaoCaoThongKe.setBackground(null);
        lblBaoCaoThongKe.setOpaque(false);
    }//GEN-LAST:event_lblBaoCaoThongKeMouseExited

    private void lblsanphamMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblsanphamMouseEntered
        // TODO add your handling code here:
        lblsanpham.setBackground(new java.awt.Color(70, 130, 180));
        lblsanpham.setOpaque(true);
        lblsanpham.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblsanphamMouseEntered

    private void lblsanphamMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblsanphamMouseExited
        // TODO add your handling code here:
        lblsanpham.setBackground(null);
        lblsanpham.setOpaque(false);
    }//GEN-LAST:event_lblsanphamMouseExited

    private void lblbanhangMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblbanhangMouseEntered
        // TODO add your handling code here:
        lblbanhang.setBackground(new java.awt.Color(70, 130, 180));
        lblbanhang.setOpaque(true);
        lblbanhang.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblbanhangMouseEntered

    private void lblbanhangMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblbanhangMouseExited
        // TODO add your handling code here:
        lblbanhang.setBackground(null);
        lblbanhang.setOpaque(false);
    }//GEN-LAST:event_lblbanhangMouseExited

    private void lblgiamgiaMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblgiamgiaMouseEntered
        // TODO add your handling code here:
        lblgiamgia.setBackground(new java.awt.Color(70, 130, 180));
        lblgiamgia.setOpaque(true);
        lblgiamgia.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblgiamgiaMouseEntered

    private void lblgiamgiaMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblgiamgiaMouseExited
        // TODO add your handling code here:
        lblgiamgia.setBackground(null);
        lblgiamgia.setOpaque(false);
    }//GEN-LAST:event_lblgiamgiaMouseExited

    private void lblhoadonMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblhoadonMouseEntered
        // TODO add your handling code here:
        lblhoadon.setBackground(new java.awt.Color(70, 130, 180));
        lblhoadon.setOpaque(true);
        lblhoadon.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblhoadonMouseEntered

    private void lblhoadonMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblhoadonMouseExited
        // TODO add your handling code here:
        lblhoadon.setBackground(null);
        lblhoadon.setOpaque(false);
    }//GEN-LAST:event_lblhoadonMouseExited

    private void lblnhanvienMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblnhanvienMouseEntered
        // TODO add your handling code here:
        lblnhanvien.setBackground(new java.awt.Color(70, 130, 180));
        lblnhanvien.setOpaque(true);
        lblnhanvien.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblnhanvienMouseEntered

    private void lblnhanvienMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblnhanvienMouseExited
        // TODO add your handling code here:
        lblnhanvien.setBackground(null);
        lblnhanvien.setOpaque(false);
    }//GEN-LAST:event_lblnhanvienMouseExited

    private void lblquanlykhachhangMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblquanlykhachhangMouseEntered
        // TODO add your handling code here:
        lblquanlykhachhang.setBackground(new java.awt.Color(70, 130, 180));
        lblquanlykhachhang.setOpaque(true);
        lblquanlykhachhang.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lblquanlykhachhangMouseEntered

    private void lblquanlykhachhangMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblquanlykhachhangMouseExited
        // TODO add your handling code here:
        lblquanlykhachhang.setBackground(null);
        lblquanlykhachhang.setOpaque(false);
    }//GEN-LAST:event_lblquanlykhachhangMouseExited

    private void lbldangnhapMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangnhapMouseEntered
        // TODO add your handling code here:
        lbldangnhap.setBackground(new java.awt.Color(70, 130, 180));
        lbldangnhap.setOpaque(true);
        lbldangnhap.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lbldangnhapMouseEntered

    private void lbldangnhapMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangnhapMouseExited
        // TODO add your handling code here:
        lbldangnhap.setBackground(null);
        lbldangnhap.setOpaque(false);
    }//GEN-LAST:event_lbldangnhapMouseExited

    private void lbldangxuatMouseEntered(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangxuatMouseEntered
        // TODO add your handling code here:
        lbldangxuat.setBackground(new java.awt.Color(70, 130, 180));
        lbldangxuat.setOpaque(true);
        lbldangxuat.setCursor(new Cursor(Cursor.HAND_CURSOR)); // đổi con trỏ
    }//GEN-LAST:event_lbldangxuatMouseEntered

    private void lbldangxuatMouseExited(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangxuatMouseExited
        // TODO add your handling code here:
        lbldangxuat.setBackground(null);
        lbldangxuat.setOpaque(false);
    }//GEN-LAST:event_lbldangxuatMouseExited

    private void btn_thanhtoanActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_thanhtoanActionPerformed
        // TODO add your handling code here:
        if (!Check()) {
            return;
        }
        if (!Check_Giohang()) {
            return;
        }
        int xacNhan = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn thanh toán không?");
        if (xacNhan != JOptionPane.YES_OPTION) {
            return;
        }
        CHECKHD = 0;
        if (rdo_chuyenkhoan.isSelected()) {
            ThanhToanChuyenKhoan(txt_tienhang.getText(), txt_hoadon.getText());
        } else {
            UPDATETHANHTOAN();
            INHOADON();
            JOptionPane.showMessageDialog(this, "Thanh Toán Thành Công");
            ModelGioHang.setRowCount(0);
            fillToTableHD();
            Lammoi();
            CHECKHD = 0;
        }

    }//GEN-LAST:event_btn_thanhtoanActionPerformed

    private void btn_taohoadonActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_taohoadonActionPerformed
        // TODO add your handling code here:
        if (CheckHoaDon() < 7) {
            CreateHD();
            HOADONNOWEIDT();
        } else {
            JOptionPane.showMessageDialog(this, "Số lượng hóa đơn đã đạt số lượng là 7. Vui lòng thanh toán hóa đơn hoặc xóa đơn");
        }
    }//GEN-LAST:event_btn_taohoadonActionPerformed

    private void btn_huyActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_huyActionPerformed
        // TODO add your handling code here:
        int yes = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn hủy hóa đơn không?");
        if (yes == JOptionPane.YES_OPTION) {
            this.delete();
            Lammoi();
            JOptionPane.showMessageDialog(this, "Hủy hoàn đơn thành công");
        }
    }//GEN-LAST:event_btn_huyActionPerformed

    private void lblBaoCaoThongKeMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblBaoCaoThongKeMouseClicked
        // TODO add your handling code here:
        FORM_BAO_THONG_KE form = new FORM_BAO_THONG_KE();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblBaoCaoThongKeMouseClicked

    private void lblsanphamMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblsanphamMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_SAN_PHAM form = new FORM_QUAN_LY_SAN_PHAM();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblsanphamMouseClicked

    private void lblbanhangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblbanhangMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_BAN_HANG form = new FORM_QUAN_LY_BAN_HANG();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblbanhangMouseClicked

    private void lblgiamgiaMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblgiamgiaMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_GIAM_GIA form = new FORM_QUAN_LY_GIAM_GIA();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblgiamgiaMouseClicked

    private void lblhoadonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblhoadonMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_HOA_DON form = new FORM_QUAN_LY_HOA_DON();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblhoadonMouseClicked

    private void lblnhanvienMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblnhanvienMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_NHAN_VIEN form = new FORM_QUAN_LY_NHAN_VIEN();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblnhanvienMouseClicked

    private void lblquanlykhachhangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lblquanlykhachhangMouseClicked
        // TODO add your handling code here:
        FORM_QUAN_LY_KHACH_HANG form = new FORM_QUAN_LY_KHACH_HANG();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lblquanlykhachhangMouseClicked

    private void lbldangnhapMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangnhapMouseClicked
        // TODO add your handling code here:
        FORM_DANG_NHAP form = new FORM_DANG_NHAP();

        // Hiển thị form mới
        form.setVisible(true);

        // Căn giữa màn hình
        form.setLocationRelativeTo(null);

        // Đóng form hiện tại
        this.dispose();
    }//GEN-LAST:event_lbldangnhapMouseClicked

    private void btn_tamtinhActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_tamtinhActionPerformed
        // TODO add your handling code here:

        if (!Check()) {
            return;
        }
        if (!Check_Giohang()) {
            JOptionPane.showMessageDialog(this, "Vui lòng thêm sản phẩm vào giỏ hàng trước khi in phiếu tạm tính");
            return;
        }
        int yess = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn in phiếu tạm tính không?");
        if (yess == JOptionPane.YES_OPTION) {
            int id_hoa_don = Integer.parseInt(txt_hoadon.getText());
            INPDF("J:\\Vestra_HN2025\\QUAN LY HOA DON\\Phieu tam tinh", id_hoa_don);
            JOptionPane.showMessageDialog(this, "In phiếu tạm tính thành công");
        }
    }//GEN-LAST:event_btn_tamtinhActionPerformed

    private void tbl_sanphamchitieMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_sanphamchitieMouseClicked
        // TODO add your handling code here:
        if (!Check()) {
            return;
        }
        int Yes = JOptionPane.showConfirmDialog(this, "Bạn có muốn thêm sản phẩm không?");
        if (Yes == JOptionPane.YES_OPTION) {
            index = tbl_sanphamchitie.getSelectedRow();
            AddSP(index);
        }
    }//GEN-LAST:event_tbl_sanphamchitieMouseClicked

    private void tbl_giohangAncestorAdded(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_tbl_giohangAncestorAdded
        // TODO add your handling code here:
    }//GEN-LAST:event_tbl_giohangAncestorAdded

    private void btn_xoaspActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_xoaspActionPerformed
        // TODO add your handling code here:
        int YES = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn xóa sản phẩm không ?");
        if (YES == JOptionPane.YES_OPTION) {
            txt_tiengiam.setText("0");
            for (int i = ModelGioHang.getRowCount() - 1; i >= 0; i--) {
                Boolean selected = (Boolean) ModelGioHang.getValueAt(i, 10);
                if (selected != null && selected) {
                    this.deleteGioHang(ModelGioHang.getValueAt(i, 0).toString());
                    ModelGioHang.removeRow(i);
                }
            };
            fillToTableSPTHANHTOAN();
            fillToTablespchitiet();
            cbo_voucher.setSelectedItem("Mời chọn Voucher");
            TongTienTamTinh();
            totalamount();
        }

    }//GEN-LAST:event_btn_xoaspActionPerformed

    private void tbl_giohangAncestorRemoved(javax.swing.event.AncestorEvent evt) {//GEN-FIRST:event_tbl_giohangAncestorRemoved
        // TODO add your handling code here:
    }//GEN-LAST:event_tbl_giohangAncestorRemoved

    private void tbl_hoadonMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_hoadonMouseClicked
        // TODO add your handling code here:
        index = tbl_hoadon.getSelectedRow();
        this.edit();
        fillToTableSPTHANHTOAN();
        TongTienTamTinh();
    }//GEN-LAST:event_tbl_hoadonMouseClicked

    private void btn_cameraActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_cameraActionPerformed
        // TODO add your handling code here:
        if (!Check()) {
            return;
        }
        if (webcam == null) {
            startCamera();        
            panecam.setVisible(true);
            btn_camera.setText("Tắt Camera");
        } else {
            stopCamera();         
            panecam.setVisible(false);
            btn_camera.setText("Bật Camera");
        }
    }//GEN-LAST:event_btn_cameraActionPerformed

    private void btn_xoahdActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_xoahdActionPerformed
        // TODO add your handling code here:
        if (!Check()) {
            return;
        }
        int yes = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn hủy hóa đơn không?");
        if (yes == JOptionPane.YES_OPTION) {
            this.delete();
            Lammoi();
            JOptionPane.showMessageDialog(this, "Hủy hoàn đơn thành công");
        }

    }//GEN-LAST:event_btn_xoahdActionPerformed

    private void btn_timkiemActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_timkiemActionPerformed
        // TODO add your handling code here:
        fillToTablespchitie_searcht();
    }//GEN-LAST:event_btn_timkiemActionPerformed

    private void btn_timkiem1ActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_timkiem1ActionPerformed
        // TODO add your handling code here:
        Khachhang KH = GetfromKH();
        if (KH == null) {
            int ok = JOptionPane.showConfirmDialog(this, "Bạn có muốn thêm khách hàng không ?");
            if (ok == JOptionPane.YES_OPTION) {
                FORM_THEM_KHACH_BAN_HANG form = new FORM_THEM_KHACH_BAN_HANG();
                form.setVisible(true);
                form.setLocationRelativeTo(null);
            }
        } else {
            GetfromKH();
            EDITKH();
        }

    }//GEN-LAST:event_btn_timkiem1ActionPerformed

    private void tbl_giohangMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tbl_giohangMouseClicked
        // TODO add your handling code here:

    }//GEN-LAST:event_tbl_giohangMouseClicked

    private void btn_lammoiActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btn_lammoiActionPerformed
        // TODO add your handling code here:
        Lammoitimkiem();
    }//GEN-LAST:event_btn_lammoiActionPerformed

    private void cbo_voucherActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_cbo_voucherActionPerformed
        // TODO add your handling code here:
    }//GEN-LAST:event_cbo_voucherActionPerformed

    private void rdo_chuyenkhoanMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rdo_chuyenkhoanMouseClicked
        // TODO add your handling code here:
        txt_tienkhachdua.setVisible(false);
        txt_tienthoi.setVisible(false);
    }//GEN-LAST:event_rdo_chuyenkhoanMouseClicked

    private void rdo_tienmatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_rdo_tienmatMouseClicked
        // TODO add your handling code here:
        txt_tienkhachdua.setVisible(true);
        txt_tienthoi.setVisible(true);
    }//GEN-LAST:event_rdo_tienmatMouseClicked

    private void lbldangxuatMouseClicked(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_lbldangxuatMouseClicked
        // TODO add your handling code here:
        int yes = JOptionPane.showConfirmDialog(this, "Bạn có chắc muốn thoát hay không?");
        if (yes == JOptionPane.YES_OPTION) {
            System.exit(0);
        }
    }//GEN-LAST:event_lbldangxuatMouseClicked

    /**
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the Nimbus look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
                    break;

                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(FORM_QUAN_LY_BAN_HANG.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(FORM_QUAN_LY_BAN_HANG.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(FORM_QUAN_LY_BAN_HANG.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);

        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(FORM_QUAN_LY_BAN_HANG.class
                    .getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new FORM_QUAN_LY_BAN_HANG().setVisible(true);
            }
        });
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton btn_camera;
    private javax.swing.JButton btn_huy;
    private javax.swing.JButton btn_lammoi;
    private javax.swing.JButton btn_tamtinh;
    private javax.swing.JButton btn_taohoadon;
    private javax.swing.JButton btn_thanhtoan;
    private javax.swing.JButton btn_timkiem;
    private javax.swing.JButton btn_timkiem1;
    private javax.swing.JButton btn_xoahd;
    private javax.swing.JButton btn_xoasp;
    private javax.swing.JComboBox<String> cbo_voucher;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel10;
    private javax.swing.JLabel jLabel11;
    private javax.swing.JLabel jLabel12;
    private javax.swing.JLabel jLabel13;
    private javax.swing.JLabel jLabel14;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JLabel jLabel3;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JLabel jLabel5;
    private javax.swing.JLabel jLabel6;
    private javax.swing.JLabel jLabel7;
    private javax.swing.JLabel jLabel8;
    private javax.swing.JLabel jLabel9;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JPanel jPanel3;
    private javax.swing.JPanel jPanel4;
    private javax.swing.JPanel jPanel5;
    private javax.swing.JPanel jPanel6;
    private javax.swing.JPanel jPanel7;
    private javax.swing.JPanel jPanel8;
    private javax.swing.JPanel jPanel9;
    private javax.swing.JScrollPane jScrollPane2;
    private javax.swing.JScrollPane jScrollPane3;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JSeparator jSeparator1;
    private javax.swing.JSeparator jSeparator2;
    private javax.swing.JLabel lblBaoCaoThongKe;
    private javax.swing.JLabel lblbanhang;
    private javax.swing.JLabel lbldangnhap;
    private javax.swing.JLabel lbldangxuat;
    private javax.swing.JLabel lblgiamgia;
    private javax.swing.JLabel lblhoadon;
    private javax.swing.JLabel lblnhanvien;
    private javax.swing.JLabel lblquanlykhachhang;
    private javax.swing.JLabel lblsanpham;
    private javax.swing.JPanel panecam;
    private javax.swing.JPanel panelWebcam;
    private javax.swing.JRadioButton rdo_chuyenkhoan;
    private javax.swing.ButtonGroup rdo_gr;
    private javax.swing.JRadioButton rdo_tienmat;
    private javax.swing.JTable tbl_giohang;
    private javax.swing.JTable tbl_hoadon;
    private javax.swing.JTable tbl_sanphamchitie;
    private javax.swing.JTextField txt_ghichu;
    private javax.swing.JTextField txt_hoadon;
    private javax.swing.JTextField txt_manv;
    private javax.swing.JTextField txt_sodt;
    private javax.swing.JTextField txt_tenkhach;
    private javax.swing.JTextField txt_tiengiam;
    private javax.swing.JTextField txt_tienhang;
    private javax.swing.JTextField txt_tienkhachdua;
    private javax.swing.JTextField txt_tienthoi;
    private javax.swing.JTextField txt_timkiemsanpham;
    private javax.swing.JTextField txt_ttt;
    // End of variables declaration//GEN-END:variables

    @Override
    public void open() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void setForm(Hoadon entity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Hoadon getForm() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public Hoadon getFormHDINSERT() {
        Khachhang KH = GetfromKH();
        if (KH == null) {
            JOptionPane.showConfirmDialog(this, "Không tìm thấy thông tin khách hàng!");
            return null;
        };
        int IDKH = KH.getID_khach_hang();
        Hoadon HD = new Hoadon();
        Nhanvien A = repoNV.IDNHANVIEN(txt_manv.getText());
        HD.setTen_nguoi_nhan(txt_tenkhach.getText());
        HD.setSDT_nguoi_nhan(txt_sodt.getText());
        HD.setID_nhan_vien(A.getID_nhan_vien());
        HD.setID_khach_hang(IDKH);
        return HD;
    }

    public Hoadon getFormUPDATENOVOUCHER() {
        Hoadon HD = new Hoadon();
        HD.setGhi_chu(txt_ghichu.getText());
        HD.setTien_giam_voucher(new BigDecimal(0));
        HD.setTong_tien_tam_tinh(fromVietnameseMoney(txt_ttt.getText()));
        HD.setTong_tien_thanh_toan(fromVietnameseMoney(txt_tienhang.getText()));
        HD.setTrang_thai_thanh_toan(true);
        if (rdo_tienmat.isSelected()) {
            HD.setPhuong_thuc_thanh_toan(true);
        } else {
            HD.setPhuong_thuc_thanh_toan(false);
        }
        HD.setID_hoa_don(Integer.parseInt(txt_hoadon.getText()));
        return HD;
    }

    public Hoadon getFormHDUPDATEYESVHOUCHER() {
        String item = cbo_voucher.getSelectedItem().toString();
        String ma_code_voucher = item.split("\\|")[0].trim();
        Voucher VC = repoVoucher.VoucherBANHANG(ma_code_voucher);
        int IDVC = VC.getID_voucher();
        Hoadon HD = new Hoadon();
        HD.setGhi_chu(txt_ghichu.getText());
        HD.setTien_giam_voucher(fromVietnameseMoney(txt_tiengiam.getText()));
        HD.setTong_tien_tam_tinh(fromVietnameseMoney(txt_ttt.getText()));
        HD.setTong_tien_thanh_toan(fromVietnameseMoney(txt_tienhang.getText()));
        HD.setTrang_thai_thanh_toan(true);
        HD.setID_voucher(IDVC);
        if (rdo_tienmat.isSelected()) {
            HD.setPhuong_thuc_thanh_toan(true);
        } else {
            HD.setPhuong_thuc_thanh_toan(false);
        }
        HD.setID_hoa_don(Integer.parseInt(txt_hoadon.getText()));
        return HD;
    }

    @Override
    public void fillToTable() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void fillToTableHD() {
        DateTimeFormatter fm = DateTimeFormatter.ofPattern("dd-MM-yyyy");
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        ModelHD = (DefaultTableModel) tbl_hoadon.getModel();
        ModelHD.setRowCount(0);
        for (Hoadon HD : repoHD.LISTHDD()) {
            Object[] date = new Object[]{
                HD.getID_hoa_don(), HD.getTen_nhan_vien(), HD.getTen_khach_hang(), HD.hoatdong(HD.isTrang_thai_thanh_toan()), HD.getNgay_lap_hoa_don().format(fm)
            };
            ModelHD.addRow(date);
        }
    }

    public void fillToTableSPTHANHTOAN() {
        ModelGioHang = (DefaultTableModel) tbl_giohang.getModel();
        ModelGioHang.setRowCount(0);
        for (Hoadonchitiet HDCT : repoHDCT.ListHDCT(Integer.parseInt(txt_hoadon.getText()))) {
            Object[] data = new Object[]{
                HDCT.getMa_san_pham_chi_tiet(), HDCT.getTen_san_pham(), HDCT.getTen_co_ao(), HDCT.getTen_thuong_hieu(), HDCT.getTen_chat_lieu(), HDCT.getTen_mau(), HDCT.getTen_size(), HDCT.getSo_luong(), toVietnameseMoney(HDCT.getDon_gia()), toVietnameseMoney(HDCT.getThanh_tien()), false
            };
            tbl_giohang.getColumnModel().getColumn(10).setCellEditor(new DefaultCellEditor(new JCheckBox()));
            tbl_giohang.getColumnModel().getColumn(10).setCellRenderer(tbl_giohang.getDefaultRenderer(Boolean.class));
            ModelGioHang.addRow(data);
        }
    }

    public void fillToTablespchitiet() {
        ModelSPCT = (DefaultTableModel) tbl_sanphamchitie.getModel();
        ModelSPCT.setRowCount(0);
        for (Sanphamchitiet SPCT : repoSPCT.findAll()) {
            Object[] data = new Object[]{
                SPCT.getMa_san_pham(), SPCT.getMa_san_pham_chi_tiet(), SPCT.getTen_san_pham(), SPCT.getTen_co_ao(), SPCT.getTen_thuong_hieu(), SPCT.getTen_chat_lieu(), SPCT.getTen_mau(), SPCT.getTen_size(), SPCT.getSo_luong_ton(),
                toVietnameseMoney(SPCT.getDon_gia()), SPCT.hoatdong(SPCT.isTrang_thai())

            };
            ModelSPCT.addRow(data);
        }
    }

    public void fillToTablespchitie_searcht() {
        ModelSPCT = (DefaultTableModel) tbl_sanphamchitie.getModel();
        ModelSPCT.setRowCount(0);
        for (Sanphamchitiet SPCT : repoSPCT.TIMKIEM(txt_timkiemsanpham.getText())) {
            Object[] data = new Object[]{
                SPCT.getMa_san_pham(), SPCT.getMa_san_pham_chi_tiet(), SPCT.getTen_san_pham(), SPCT.getTen_co_ao(), SPCT.getTen_thuong_hieu(), SPCT.getTen_chat_lieu(), SPCT.getTen_mau(), SPCT.getTen_size(), SPCT.getSo_luong_ton(),
                toVietnameseMoney(SPCT.getDon_gia()), SPCT.hoatdong(SPCT.isTrang_thai())
            };
            ModelSPCT.addRow(data);
        }
    }

    @Override
    public void edit() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Hoadon HD = repoHD.SDTKH(Integer.parseInt(tbl_hoadon.getValueAt(index, 0).toString()));
        txt_hoadon.setText(tbl_hoadon.getValueAt(index, 0).toString());
        txt_sodt.setText(HD.getSDT_nguoi_nhan().toString());
        txt_tenkhach.setText(HD.getTen_nguoi_nhan().toString());
        rdo_tienmat.setSelected(true);
    }

    public void HOADONNOWEIDT() {
        Hoadon HD = repoHD.HOADONMOINHAT();
        txt_hoadon.setText(String.valueOf(HD.getID_hoa_don()));
        if (HD.getSDT_nguoi_nhan() == null) {
            txt_sodt.setText("");
        } else {
            txt_sodt.setText(HD.getSDT());
        }
        txt_tenkhach.setText(HD.getTen_khach_hang().toString());
        rdo_tienmat.setSelected(true);
    }

    @Override
    public void create() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody

    }

    public void CreateHD() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Hoadon HD = this.getFormHDINSERT();
        repoHD.create(HD);
        this.fillToTableHD();
    }

    @Override
    public void update() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public void UPDATENOVOUCHER() {
        Hoadon HD = this.getFormUPDATENOVOUCHER();
        repoHD.UPDATENOVOUCHER(HD);
    }

    public void UPDATEYESVOUCHER() {
        Hoadon HD = this.getFormHDUPDATEYESVHOUCHER();
        repoHD.UPDATEYESVOUCHER(HD);
    }

    @Override
    public void delete() {
        int id = Integer.parseInt(txt_hoadon.getText());
        repoHDCT.deleteById(id);
        repoHD.deleteById(id);
        fillToTableHD();
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void clear() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void setEditable(boolean editable) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void checkAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void uncheckAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deleteCheckedItems() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void moveFirst() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void movePrevious() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void moveNext() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void moveLast() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void moveTo(int rowIndex) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
