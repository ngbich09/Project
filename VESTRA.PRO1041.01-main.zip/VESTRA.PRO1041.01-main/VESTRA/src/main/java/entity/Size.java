/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author manhh
 */
public class Size {
    private int  ID_size;
   private String ma_size;
   private String ten_size;
   private boolean Trang_thai;

    public Size() {
    }

    public Size(int ID_size, String ma_size, String ten_size, boolean Trang_thai) {
        this.ID_size = ID_size;
        this.ma_size = ma_size;
        this.ten_size = ten_size;
        this.Trang_thai = Trang_thai;
    }

    public int getID_size() {
        return ID_size;
    }

    public void setID_size(int ID_size) {
        this.ID_size = ID_size;
    }

    public String getMa_size() {
        return ma_size;
    }

    public void setMa_size(String ma_size) {
        this.ma_size = ma_size;
    }

    public String getTen_size() {
        return ten_size;
    }

    public void setTen_size(String ten_size) {
        this.ten_size = ten_size;
    }

    public boolean isTrang_thai() {
        return Trang_thai;
    }

    public void setTrang_thai(boolean Trang_thai) {
        this.Trang_thai = Trang_thai;
    } 
    public String hoatdong(boolean Trang_thai){
    return Trang_thai ? "Hoạt động" : "Không hoạt động";
    }
}
