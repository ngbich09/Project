/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author manhh
 */
public class Chatlieu {
  private int ID_chat_lieu;
    private String ma_chat_lieu;
    private String ten_chat_lieu;
    private boolean Trang_thai;

    public Chatlieu() {
    }

    public Chatlieu(int ID_chat_lieu, String ma_chat_lieu, String ten_chat_lieu, boolean Trang_thai) {
        this.ID_chat_lieu = ID_chat_lieu;
        this.ma_chat_lieu = ma_chat_lieu;
        this.ten_chat_lieu = ten_chat_lieu;
        this.Trang_thai = Trang_thai;
    }

    public int getID_chat_lieu() {
        return ID_chat_lieu;
    }

    public void setID_chat_lieu(int ID_chat_lieu) {
        this.ID_chat_lieu = ID_chat_lieu;
    }

    public String getMa_chat_lieu() {
        return ma_chat_lieu;
    }

    public void setMa_chat_lieu(String ma_chat_lieu) {
        this.ma_chat_lieu = ma_chat_lieu;
    }

    public String getTen_chat_lieu() {
        return ten_chat_lieu;
    }

    public void setTen_chat_lieu(String ten_chat_lieu) {
        this.ten_chat_lieu = ten_chat_lieu;
    }

    public boolean isTrang_thai() {
        return Trang_thai;
    }

    public void setTrang_thai(boolean Trang_thai) {
        this.Trang_thai = Trang_thai;
    }  
    public String hoatdong(boolean Trang_thai){
    return Trang_thai ? "Hoạt động" : "Không hoạt động";
    }
}
