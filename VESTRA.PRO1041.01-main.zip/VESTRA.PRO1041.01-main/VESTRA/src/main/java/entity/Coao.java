/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author manhh
 */
public class Coao {
    private int ID_co_ao;
    private String ma_co_ao;
    private String ten_co_ao;
    private boolean Trang_thai;

    public Coao() {
    }

    public Coao(int ID_co_ao, String ma_co_ao, String ten_co_ao, boolean Trang_thai) {
        this.ID_co_ao = ID_co_ao;
        this.ma_co_ao = ma_co_ao;
        this.ten_co_ao = ten_co_ao;
        this.Trang_thai = Trang_thai;
    }

    public int getID_co_ao() {
        return ID_co_ao;
    }

    public void setID_co_ao(int ID_co_ao) {
        this.ID_co_ao = ID_co_ao;
    }

    public String getMa_co_ao() {
        return ma_co_ao;
    }

    public void setMa_co_ao(String ma_co_ao) {
        this.ma_co_ao = ma_co_ao;
    }

    public String getTen_co_ao() {
        return ten_co_ao;
    }

    public void setTen_co_ao(String ten_co_ao) {
        this.ten_co_ao = ten_co_ao;
    }

    public boolean isTrang_thai() {
        return Trang_thai;
    }

    public void setTrang_thai(boolean Trang_thai) {
        this.Trang_thai = Trang_thai;
    }
    public String hoatdong(boolean Trang_thai){
    return Trang_thai ? "Hoạt động" : "Không hoạt động";
    }
}
