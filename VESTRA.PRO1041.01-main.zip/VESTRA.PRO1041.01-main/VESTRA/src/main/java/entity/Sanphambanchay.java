/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.math.BigDecimal;

/**
 *
 * @author manhh
 */
public class Sanphambanchay {
    private String Ma_san_pham;
    private String Ten_san_pham;
    private String ten_thuong_hieu;
    private String ten_Size;
    private BigDecimal Gia_ban;
    private int So_Luot_Ban;
    private String ten_chat_lieu;
    private String ten_co_ao;
    private String ten_mau;

    public Sanphambanchay() {
    }

    public Sanphambanchay(String Ma_san_pham, String Ten_san_pham, String ten_thuong_hieu, String ten_Size, BigDecimal Gia_ban, int So_Luot_Ban, String ten_chat_lieu, String ten_co_ao, String ten_mau) {
        this.Ma_san_pham = Ma_san_pham;
        this.Ten_san_pham = Ten_san_pham;
        this.ten_thuong_hieu = ten_thuong_hieu;
        this.ten_Size = ten_Size;
        this.Gia_ban = Gia_ban;
        this.So_Luot_Ban = So_Luot_Ban;
        this.ten_chat_lieu = ten_chat_lieu;
        this.ten_co_ao = ten_co_ao;
        this.ten_mau = ten_mau;
    }

    public String getMa_san_pham() {
        return Ma_san_pham;
    }

    public void setMa_san_pham(String Ma_san_pham) {
        this.Ma_san_pham = Ma_san_pham;
    }

    public String getTen_san_pham() {
        return Ten_san_pham;
    }

    public void setTen_san_pham(String Ten_san_pham) {
        this.Ten_san_pham = Ten_san_pham;
    }

    public String getTen_thuong_hieu() {
        return ten_thuong_hieu;
    }

    public void setTen_thuong_hieu(String ten_thuong_hieu) {
        this.ten_thuong_hieu = ten_thuong_hieu;
    }

    public String getTen_Size() {
        return ten_Size;
    }

    public void setTen_Size(String ten_Size) {
        this.ten_Size = ten_Size;
    }

    public BigDecimal getGia_ban() {
        return Gia_ban;
    }

    public void setGia_ban(BigDecimal Gia_ban) {
        this.Gia_ban = Gia_ban;
    }

    public int getSo_Luot_Ban() {
        return So_Luot_Ban;
    }

    public void setSo_Luot_Ban(int So_Luot_Ban) {
        this.So_Luot_Ban = So_Luot_Ban;
    }

    public String getTen_chat_lieu() {
        return ten_chat_lieu;
    }

    public void setTen_chat_lieu(String ten_chat_lieu) {
        this.ten_chat_lieu = ten_chat_lieu;
    }

    public String getTen_co_ao() {
        return ten_co_ao;
    }

    public void setTen_co_ao(String ten_co_ao) {
        this.ten_co_ao = ten_co_ao;
    }

    public String getTen_mau() {
        return ten_mau;
    }

    public void setTen_mau(String ten_mau) {
        this.ten_mau = ten_mau;
    }

}
