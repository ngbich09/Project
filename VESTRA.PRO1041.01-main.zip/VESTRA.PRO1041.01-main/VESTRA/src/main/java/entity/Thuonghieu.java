/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author manhh
 */
public class Thuonghieu {
     private int ID_thuong_hieu;
    private String ma_thuong_hieu;
    private String ten_thuong_hieu;
    private boolean Trang_thai;

    public Thuonghieu() {
    }

    public Thuonghieu(int ID_thuong_hieu, String ma_thuong_hieu, String ten_thuong_hieu, boolean Trang_thai) {
        this.ID_thuong_hieu = ID_thuong_hieu;
        this.ma_thuong_hieu = ma_thuong_hieu;
        this.ten_thuong_hieu = ten_thuong_hieu;
        this.Trang_thai = Trang_thai;
    }

    public int getID_thuong_hieu() {
        return ID_thuong_hieu;
    }

    public void setID_thuong_hieu(int ID_thuong_hieu) {
        this.ID_thuong_hieu = ID_thuong_hieu;
    }

    public String getMa_thuong_hieu() {
        return ma_thuong_hieu;
    }

    public void setMa_thuong_hieu(String ma_thuong_hieu) {
        this.ma_thuong_hieu = ma_thuong_hieu;
    }

    public String getTen_thuong_hieu() {
        return ten_thuong_hieu;
    }

    public void setTen_thuong_hieu(String ten_thuong_hieu) {
        this.ten_thuong_hieu = ten_thuong_hieu;
    }

    public boolean isTrang_thai() {
        return Trang_thai;
    }

    public void setTrang_thai(boolean Trang_thai) {
        this.Trang_thai = Trang_thai;
    }
    public String hoatdong(boolean Trang_thai){
    return Trang_thai ? "Hoạt động" : "Không hoạt động";
    }
}
