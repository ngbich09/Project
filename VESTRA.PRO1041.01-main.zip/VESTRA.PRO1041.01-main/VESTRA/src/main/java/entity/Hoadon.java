/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 *
 * @author manhh
 */
public class Hoadon {

    private int ID_hoa_don;
    private int ID_khach_hang;
    private int ID_voucher;
    private int ID_nhan_vien;
    private String ten_nguoi_nhan;
    private String SDT_nguoi_nhan;
    private String ghi_chu;
    private BigDecimal tong_tien_tam_tinh;
    private BigDecimal tien_giam_voucher;
    private BigDecimal tong_tien_thanh_toan;
    private LocalDateTime ngay_lap_hoa_don;
    private boolean trang_thai_thanh_toan;
    private String ma_code_voucher;
    private String ten_nhan_vien;
    private String ten_khach_hang;
    private boolean phuong_thuc_thanh_toan;
    private String ma_khach_hang;
    private String SDT;

    public Hoadon() {
    }

    public Hoadon(int ID_hoa_don, int ID_khach_hang, int ID_voucher, int ID_nhan_vien, String ten_nguoi_nhan, String SDT_nguoi_nhan, String ghi_chu, BigDecimal tong_tien_tam_tinh, BigDecimal tien_giam_voucher, BigDecimal tong_tien_thanh_toan, LocalDateTime ngay_lap_hoa_don, boolean trang_thai_thanh_toan, boolean phuong_thuc_thanh_toan) {
        this.ID_hoa_don = ID_hoa_don;
        this.ID_khach_hang = ID_khach_hang;
        this.ID_voucher = ID_voucher;
        this.ID_nhan_vien = ID_nhan_vien;
        this.ten_nguoi_nhan = ten_nguoi_nhan;
        this.SDT_nguoi_nhan = SDT_nguoi_nhan;
        this.ghi_chu = ghi_chu;
        this.tong_tien_tam_tinh = tong_tien_tam_tinh;
        this.tien_giam_voucher = tien_giam_voucher;
        this.tong_tien_thanh_toan = tong_tien_thanh_toan;
        this.ngay_lap_hoa_don = ngay_lap_hoa_don;
        this.trang_thai_thanh_toan = trang_thai_thanh_toan;
        this.phuong_thuc_thanh_toan = phuong_thuc_thanh_toan;
    }

    public Hoadon(int ID_hoa_don, int ID_khach_hang, int ID_voucher, int ID_nhan_vien, String ten_nguoi_nhan, String SDT_nguoi_nhan, String ghi_chu, BigDecimal tong_tien_tam_tinh, BigDecimal tien_giam_voucher, BigDecimal tong_tien_thanh_toan, LocalDateTime ngay_lap_hoa_don, boolean trang_thai_thanh_toan, String ma_code_voucher, String ten_nhan_vien, String ten_khach_hang, boolean phuong_thuc_thanh_toan, String ma_khach_hang, String SDT) {
        this.ID_hoa_don = ID_hoa_don;
        this.ID_khach_hang = ID_khach_hang;
        this.ID_voucher = ID_voucher;
        this.ID_nhan_vien = ID_nhan_vien;
        this.ten_nguoi_nhan = ten_nguoi_nhan;
        this.SDT_nguoi_nhan = SDT_nguoi_nhan;
        this.ghi_chu = ghi_chu;
        this.tong_tien_tam_tinh = tong_tien_tam_tinh;
        this.tien_giam_voucher = tien_giam_voucher;
        this.tong_tien_thanh_toan = tong_tien_thanh_toan;
        this.ngay_lap_hoa_don = ngay_lap_hoa_don;
        this.trang_thai_thanh_toan = trang_thai_thanh_toan;
        this.ma_code_voucher = ma_code_voucher;
        this.ten_nhan_vien = ten_nhan_vien;
        this.ten_khach_hang = ten_khach_hang;
        this.phuong_thuc_thanh_toan = phuong_thuc_thanh_toan;
        this.ma_khach_hang = ma_khach_hang;
        this.SDT = SDT;
    }

    public int getID_hoa_don() {
        return ID_hoa_don;
    }

    public void setID_hoa_don(int ID_hoa_don) {
        this.ID_hoa_don = ID_hoa_don;
    }

    public int getID_khach_hang() {
        return ID_khach_hang;
    }

    public void setID_khach_hang(int ID_khach_hang) {
        this.ID_khach_hang = ID_khach_hang;
    }

    public int getID_voucher() {
        return ID_voucher;
    }

    public void setID_voucher(int ID_voucher) {
        this.ID_voucher = ID_voucher;
    }

    public int getID_nhan_vien() {
        return ID_nhan_vien;
    }

    public void setID_nhan_vien(int ID_nhan_vien) {
        this.ID_nhan_vien = ID_nhan_vien;
    }

    public String getTen_nguoi_nhan() {
        return ten_nguoi_nhan;
    }

    public void setTen_nguoi_nhan(String ten_nguoi_nhan) {
        this.ten_nguoi_nhan = ten_nguoi_nhan;
    }

    public String getSDT_nguoi_nhan() {
        return SDT_nguoi_nhan;
    }

    public void setSDT_nguoi_nhan(String SDT_nguoi_nhan) {
        this.SDT_nguoi_nhan = SDT_nguoi_nhan;
    }

    public String getGhi_chu() {
        return ghi_chu;
    }

    public void setGhi_chu(String ghi_chu) {
        this.ghi_chu = ghi_chu;
    }

    public BigDecimal getTong_tien_tam_tinh() {
        return tong_tien_tam_tinh;
    }

    public void setTong_tien_tam_tinh(BigDecimal tong_tien_tam_tinh) {
        this.tong_tien_tam_tinh = tong_tien_tam_tinh;
    }

    public BigDecimal getTien_giam_voucher() {
        return tien_giam_voucher;
    }

    public void setTien_giam_voucher(BigDecimal tien_giam_voucher) {
        this.tien_giam_voucher = tien_giam_voucher;
    }

    public BigDecimal getTong_tien_thanh_toan() {
        return tong_tien_thanh_toan;
    }

    public void setTong_tien_thanh_toan(BigDecimal tong_tien_thanh_toan) {
        this.tong_tien_thanh_toan = tong_tien_thanh_toan;
    }

    public LocalDateTime getNgay_lap_hoa_don() {
        return ngay_lap_hoa_don;
    }

    public void setNgay_lap_hoa_don(LocalDateTime ngay_lap_hoa_don) {
        this.ngay_lap_hoa_don = ngay_lap_hoa_don;
    }

    public boolean isTrang_thai_thanh_toan() {
        return trang_thai_thanh_toan;
    }

    public void setTrang_thai_thanh_toan(boolean trang_thai_thanh_toan) {
        this.trang_thai_thanh_toan = trang_thai_thanh_toan;
    }

    public String getMa_code_voucher() {
        return ma_code_voucher;
    }

    public void setMa_code_voucher(String ma_code_voucher) {
        this.ma_code_voucher = ma_code_voucher;
    }

    public String getTen_nhan_vien() {
        return ten_nhan_vien;
    }

    public void setTen_nhan_vien(String ten_nhan_vien) {
        this.ten_nhan_vien = ten_nhan_vien;
    }

    public String getTen_khach_hang() {
        return ten_khach_hang;
    }

    public void setTen_khach_hang(String ten_khach_hang) {
        this.ten_khach_hang = ten_khach_hang;
    }

    public boolean isPhuong_thuc_thanh_toan() {
        return phuong_thuc_thanh_toan;
    }

    public void setPhuong_thuc_thanh_toan(boolean phuong_thuc_thanh_toan) {
        this.phuong_thuc_thanh_toan = phuong_thuc_thanh_toan;
    }

    public String getMa_khach_hang() {
        return ma_khach_hang;
    }

    public void setMa_khach_hang(String ma_khach_hang) {
        this.ma_khach_hang = ma_khach_hang;
    }

    public String getSDT() {
        return SDT;
    }

    public void setSDT(String SDT) {
        this.SDT = SDT;
    }

    public String PTHT(boolean phuong_thuc_thanh_toan) {
        return phuong_thuc_thanh_toan ? "Tiền mặt" : "Chuyển khoản";
    }

    public String hoatdong(boolean Trang_thai) {
        return Trang_thai ? "Đã thanh toán" : "Chưa thanh toán";
    }

}
