/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.Date;

/**
 *
 * @author manhh
 */
public class Khachhang {
     private int ID_khach_hang;
    private String ma_khach_hang;
    private String ten_khach_hang;
    private String SDT;
    private String email;
    private String dia_chi;
    private Date ngay_sinh;
    private String gioi_tinh;
    private boolean Trang_thai;
    private LocalDate Ngay_tao;
    private String Ma_nguoi_tao;
    private LocalDateTime Ngay_cap_nhat;
    private String Ma_nguoi_cap_nhat;

    public Khachhang() {
    }

    public Khachhang(int ID_khach_hang, String ma_khach_hang, String ten_khach_hang, String SDT, String email, String dia_chi, Date ngay_sinh, String gioi_tinh, boolean Trang_thai, LocalDate Ngay_tao, String Ma_nguoi_tao, LocalDateTime Ngay_cap_nhat, String Ma_nguoi_cap_nhat) {
        this.ID_khach_hang = ID_khach_hang;
        this.ma_khach_hang = ma_khach_hang;
        this.ten_khach_hang = ten_khach_hang;
        this.SDT = SDT;
        this.email = email;
        this.dia_chi = dia_chi;
        this.ngay_sinh = ngay_sinh;
        this.gioi_tinh = gioi_tinh;
        this.Trang_thai = Trang_thai;
        this.Ngay_tao = Ngay_tao;
        this.Ma_nguoi_tao = Ma_nguoi_tao;
        this.Ngay_cap_nhat = Ngay_cap_nhat;
        this.Ma_nguoi_cap_nhat = Ma_nguoi_cap_nhat;
    }

    public int getID_khach_hang() {
        return ID_khach_hang;
    }

    public void setID_khach_hang(int ID_khach_hang) {
        this.ID_khach_hang = ID_khach_hang;
    }

    public String getMa_khach_hang() {
        return ma_khach_hang;
    }

    public void setMa_khach_hang(String ma_khach_hang) {
        this.ma_khach_hang = ma_khach_hang;
    }

    public String getTen_khach_hang() {
        return ten_khach_hang;
    }

    public void setTen_khach_hang(String ten_khach_hang) {
        this.ten_khach_hang = ten_khach_hang;
    }

    public String getSDT() {
        return SDT;
    }

    public void setSDT(String SDT) {
        this.SDT = SDT;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getDia_chi() {
        return dia_chi;
    }

    public void setDia_chi(String dia_chi) {
        this.dia_chi = dia_chi;
    }

    public Date getNgay_sinh() {
        return ngay_sinh;
    }

    public void setNgay_sinh(Date ngay_sinh) {
        this.ngay_sinh = ngay_sinh;
    }

    public String getGioi_tinh() {
        return gioi_tinh;
    }

    public void setGioi_tinh(String gioi_tinh) {
        this.gioi_tinh = gioi_tinh;
    }

    public boolean isTrang_thai() {
        return Trang_thai;
    }

    public void setTrang_thai(boolean Trang_thai) {
        this.Trang_thai = Trang_thai;
    }

    public LocalDate getNgay_tao() {
        return Ngay_tao;
    }

    public void setNgay_tao(LocalDate Ngay_tao) {
        this.Ngay_tao = Ngay_tao;
    }

    public String getMa_nguoi_tao() {
        return Ma_nguoi_tao;
    }

    public void setMa_nguoi_tao(String Ma_nguoi_tao) {
        this.Ma_nguoi_tao = Ma_nguoi_tao;
    }

    public LocalDateTime getNgay_cap_nhat() {
        return Ngay_cap_nhat;
    }

    public void setNgay_cap_nhat(LocalDateTime Ngay_cap_nhat) {
        this.Ngay_cap_nhat = Ngay_cap_nhat;
    }

    public String getMa_nguoi_cap_nhat() {
        return Ma_nguoi_cap_nhat;
    }

    public void setMa_nguoi_cap_nhat(String Ma_nguoi_cap_nhat) {
        this.Ma_nguoi_cap_nhat = Ma_nguoi_cap_nhat;
    }
    public String hoatdong(boolean Trang_thai){
    return Trang_thai ? "Hoạt động" : "Không hoạt động";
    }
}
