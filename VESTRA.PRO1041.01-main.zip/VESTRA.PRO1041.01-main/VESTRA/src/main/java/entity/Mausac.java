/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

/**
 *
 * @author manhh
 */
public class Mausac {
     private int ID_mau_sac;
    private String ma_mau_sac;
    private String ten_mau;
    private boolean Trang_thai;

    public Mausac() {
    }

    public Mausac(int ID_mau_sac, String ma_mau_sac, String ten_mau, boolean Trang_thai) {
        this.ID_mau_sac = ID_mau_sac;
        this.ma_mau_sac = ma_mau_sac;
        this.ten_mau = ten_mau;
        this.Trang_thai = Trang_thai;
    }

    public int getID_mau_sac() {
        return ID_mau_sac;
    }

    public void setID_mau_sac(int ID_mau_sac) {
        this.ID_mau_sac = ID_mau_sac;
    }

    public String getMa_mau_sac() {
        return ma_mau_sac;
    }

    public void setMa_mau_sac(String ma_mau_sac) {
        this.ma_mau_sac = ma_mau_sac;
    }

    public String getTen_mau() {
        return ten_mau;
    }

    public void setTen_mau(String ten_mau) {
        this.ten_mau = ten_mau;
    }

    public boolean isTrang_thai() {
        return Trang_thai;
    }

    public void setTrang_thai(boolean Trang_thai) {
        this.Trang_thai = Trang_thai;
    }
    public String hoatdong(boolean Trang_thai){
    return Trang_thai ? "Hoạt động" : "Không hoạt động";
    }
}
