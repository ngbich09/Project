/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.time.LocalDateTime;
import java.util.Date;

/**
 *
 * @author manhh
 */
public class Nhanvien {
        private int ID_nhan_vien;
    private int ID_chuc_vu;
    private String ma_nhan_vien;
    private String ten_nhan_vien;
    private String ten_dang_nhap;
    private String mat_khau;
    private String gioi_tinh;
    private Date ngay_sinh;
    private String dia_chi;
    private String SDT;
    private String email;
    private String CCCD;
    private boolean Trang_thai;
    private LocalDateTime Ngay_tao;
    private String Ma_nguoi_tao;
    private LocalDateTime Ngay_cap_nhat;
    private String Ma_nguoi_cap_nhat;
    private String ten_chuc_vu;

    public Nhanvien() {
    }

    public Nhanvien(int ID_nhan_vien, int ID_chuc_vu, String ma_nhan_vien, String ten_nhan_vien, String ten_dang_nhap, String mat_khau, String gioi_tinh, Date ngay_sinh, String dia_chi, String SDT, String email, String CCCD, boolean Trang_thai, LocalDateTime Ngay_tao, String Ma_nguoi_tao, LocalDateTime Ngay_cap_nhat, String Ma_nguoi_cap_nhat, String ten_chuc_vu) {
        this.ID_nhan_vien = ID_nhan_vien;
        this.ID_chuc_vu = ID_chuc_vu;
        this.ma_nhan_vien = ma_nhan_vien;
        this.ten_nhan_vien = ten_nhan_vien;
        this.ten_dang_nhap = ten_dang_nhap;
        this.mat_khau = mat_khau;
        this.gioi_tinh = gioi_tinh;
        this.ngay_sinh = ngay_sinh;
        this.dia_chi = dia_chi;
        this.SDT = SDT;
        this.email = email;
        this.CCCD = CCCD;
        this.Trang_thai = Trang_thai;
        this.Ngay_tao = Ngay_tao;
        this.Ma_nguoi_tao = Ma_nguoi_tao;
        this.Ngay_cap_nhat = Ngay_cap_nhat;
        this.Ma_nguoi_cap_nhat = Ma_nguoi_cap_nhat;
        this.ten_chuc_vu = ten_chuc_vu;
    }

    public Nhanvien(int ID_nhan_vien, int ID_chuc_vu, String ma_nhan_vien, String ten_nhan_vien, String ten_dang_nhap, String mat_khau, String gioi_tinh, Date ngay_sinh, String dia_chi, String SDT, String email, String CCCD, boolean Trang_thai, LocalDateTime Ngay_tao, String Ma_nguoi_tao, LocalDateTime Ngay_cap_nhat, String Ma_nguoi_cap_nhat) {
        this.ID_nhan_vien = ID_nhan_vien;
        this.ID_chuc_vu = ID_chuc_vu;
        this.ma_nhan_vien = ma_nhan_vien;
        this.ten_nhan_vien = ten_nhan_vien;
        this.ten_dang_nhap = ten_dang_nhap;
        this.mat_khau = mat_khau;
        this.gioi_tinh = gioi_tinh;
        this.ngay_sinh = ngay_sinh;
        this.dia_chi = dia_chi;
        this.SDT = SDT;
        this.email = email;
        this.CCCD = CCCD;
        this.Trang_thai = Trang_thai;
        this.Ngay_tao = Ngay_tao;
        this.Ma_nguoi_tao = Ma_nguoi_tao;
        this.Ngay_cap_nhat = Ngay_cap_nhat;
        this.Ma_nguoi_cap_nhat = Ma_nguoi_cap_nhat;
    }

    public int getID_nhan_vien() {
        return ID_nhan_vien;
    }

    public void setID_nhan_vien(int ID_nhan_vien) {
        this.ID_nhan_vien = ID_nhan_vien;
    }

    public int getID_chuc_vu() {
        return ID_chuc_vu;
    }

    public void setID_chuc_vu(int ID_chuc_vu) {
        this.ID_chuc_vu = ID_chuc_vu;
    }

    public String getMa_nhan_vien() {
        return ma_nhan_vien;
    }

    public void setMa_nhan_vien(String ma_nhan_vien) {
        this.ma_nhan_vien = ma_nhan_vien;
    }

    public String getTen_nhan_vien() {
        return ten_nhan_vien;
    }

    public void setTen_nhan_vien(String ten_nhan_vien) {
        this.ten_nhan_vien = ten_nhan_vien;
    }

    public String getTen_dang_nhap() {
        return ten_dang_nhap;
    }

    public void setTen_dang_nhap(String ten_dang_nhap) {
        this.ten_dang_nhap = ten_dang_nhap;
    }

    public String getMat_khau() {
        return mat_khau;
    }

    public void setMat_khau(String mat_khau) {
        this.mat_khau = mat_khau;
    }

    public String getGioi_tinh() {
        return gioi_tinh;
    }

    public void setGioi_tinh(String gioi_tinh) {
        this.gioi_tinh = gioi_tinh;
    }

    public Date getNgay_sinh() {
        return ngay_sinh;
    }

    public void setNgay_sinh(Date ngay_sinh) {
        this.ngay_sinh = ngay_sinh;
    }

    public String getDia_chi() {
        return dia_chi;
    }

    public void setDia_chi(String dia_chi) {
        this.dia_chi = dia_chi;
    }

    public String getSDT() {
        return SDT;
    }

    public void setSDT(String SDT) {
        this.SDT = SDT;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCCCD() {
        return CCCD;
    }

    public void setCCCD(String CCCD) {
        this.CCCD = CCCD;
    }

    public boolean isTrang_thai() {
        return Trang_thai;
    }

    public void setTrang_thai(boolean Trang_thai) {
        this.Trang_thai = Trang_thai;
    }

    public LocalDateTime getNgay_tao() {
        return Ngay_tao;
    }

    public void setNgay_tao(LocalDateTime Ngay_tao) {
        this.Ngay_tao = Ngay_tao;
    }

    public String getMa_nguoi_tao() {
        return Ma_nguoi_tao;
    }

    public void setMa_nguoi_tao(String Ma_nguoi_tao) {
        this.Ma_nguoi_tao = Ma_nguoi_tao;
    }

    public LocalDateTime getNgay_cap_nhat() {
        return Ngay_cap_nhat;
    }

    public void setNgay_cap_nhat(LocalDateTime Ngay_cap_nhat) {
        this.Ngay_cap_nhat = Ngay_cap_nhat;
    }

    public String getMa_nguoi_cap_nhat() {
        return Ma_nguoi_cap_nhat;
    }

    public void setMa_nguoi_cap_nhat(String Ma_nguoi_cap_nhat) {
        this.Ma_nguoi_cap_nhat = Ma_nguoi_cap_nhat;
    }

    public String getTen_chuc_vu() {
        return ten_chuc_vu;
    }

    public void setTen_chuc_vu(String ten_chuc_vu) {
        this.ten_chuc_vu = ten_chuc_vu;
    }
    public String hoatdong(boolean Trang_thai){
    return Trang_thai ? "Đi làm" : "Nghỉ làm";
    }
}
