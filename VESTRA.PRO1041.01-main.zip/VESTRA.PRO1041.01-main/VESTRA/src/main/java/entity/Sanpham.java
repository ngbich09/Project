/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.math.BigDecimal;

/**
 *
 * @author manhh
 */
public class Sanpham {
     private int ID_san_pham;
    private String ma_san_pham;
    private String ten_san_pham;
    private boolean Trang_thai;
    private String Mo_ta_san_pham;
    private int ID_co_ao;
    private int ID_thuong_hieu;
    private int ID_chat_lieu;
    private String ten_thuong_hieu;
    private String ten_chat_lieu;
    private String ten_co_ao;
    private int so_luong;
    private BigDecimal don_gia;


    public Sanpham() {

    }

    public Sanpham(int ID_san_pham, String ma_san_pham, String ten_san_pham, boolean Trang_thai, String Mo_ta_san_pham, int ID_co_ao, int ID_thuong_hieu, int ID_chat_lieu, String ten_thuong_hieu, String ten_chat_lieu, String ten_co_ao, int so_luong, BigDecimal don_gia) {
        this.ID_san_pham = ID_san_pham;
        this.ma_san_pham = ma_san_pham;
        this.ten_san_pham = ten_san_pham;
        this.Trang_thai = Trang_thai;
        this.Mo_ta_san_pham = Mo_ta_san_pham;
        this.ID_co_ao = ID_co_ao;
        this.ID_thuong_hieu = ID_thuong_hieu;
        this.ID_chat_lieu = ID_chat_lieu;
        this.ten_thuong_hieu = ten_thuong_hieu;
        this.ten_chat_lieu = ten_chat_lieu;
        this.ten_co_ao = ten_co_ao;
        this.so_luong = so_luong;
        this.don_gia = don_gia;
    }

    public Sanpham(int ID_san_pham, String ma_san_pham, String ten_san_pham, boolean Trang_thai, String Mo_ta_san_pham, int ID_co_ao, int ID_thuong_hieu, int ID_chat_lieu) {
        this.ID_san_pham = ID_san_pham;
        this.ma_san_pham = ma_san_pham;
        this.ten_san_pham = ten_san_pham;
        this.Trang_thai = Trang_thai;
        this.Mo_ta_san_pham = Mo_ta_san_pham;
        this.ID_co_ao = ID_co_ao;
        this.ID_thuong_hieu = ID_thuong_hieu;
        this.ID_chat_lieu = ID_chat_lieu;
    }

    public int getID_san_pham() {
        return ID_san_pham;
    }

    public void setID_san_pham(int ID_san_pham) {
        this.ID_san_pham = ID_san_pham;
    }

    public String getMa_san_pham() {
        return ma_san_pham;
    }

    public void setMa_san_pham(String ma_san_pham) {
        this.ma_san_pham = ma_san_pham;
    }

    public String getTen_san_pham() {
        return ten_san_pham;
    }

    public void setTen_san_pham(String ten_san_pham) {
        this.ten_san_pham = ten_san_pham;
    }

    public boolean isTrang_thai() {
        return Trang_thai;
    }

    public void setTrang_thai(boolean Trang_thai) {
        this.Trang_thai = Trang_thai;
    }

    public String getMo_ta_san_pham() {
        return Mo_ta_san_pham;
    }

    public void setMo_ta_san_pham(String Mo_ta_san_pham) {
        this.Mo_ta_san_pham = Mo_ta_san_pham;
    }

    public int getID_co_ao() {
        return ID_co_ao;
    }

    public void setID_co_ao(int ID_co_ao) {
        this.ID_co_ao = ID_co_ao;
    }

    public int getID_thuong_hieu() {
        return ID_thuong_hieu;
    }

    public void setID_thuong_hieu(int ID_thuong_hieu) {
        this.ID_thuong_hieu = ID_thuong_hieu;
    }

    public int getID_chat_lieu() {
        return ID_chat_lieu;
    }

    public void setID_chat_lieu(int ID_chat_lieu) {
        this.ID_chat_lieu = ID_chat_lieu;
    }

    public String getTen_thuong_hieu() {
        return ten_thuong_hieu;
    }

    public void setTen_thuong_hieu(String ten_thuong_hieu) {
        this.ten_thuong_hieu = ten_thuong_hieu;
    }

    public String getTen_chat_lieu() {
        return ten_chat_lieu;
    }

    public void setTen_chat_lieu(String ten_chat_lieu) {
        this.ten_chat_lieu = ten_chat_lieu;
    }

    public String getTen_co_ao() {
        return ten_co_ao;
    }

    public void setTen_co_ao(String ten_co_ao) {
        this.ten_co_ao = ten_co_ao;
    }

    public int getSo_luong() {
        return so_luong;
    }

    public void setSo_luong(int so_luong) {
        this.so_luong = so_luong;
    }

    public BigDecimal getDon_gia() {
        return don_gia;
    }

    public void setDon_gia(BigDecimal don_gia) {
        this.don_gia = don_gia;
    }

    public String hoatdong(boolean Trang_thai) {
        return Trang_thai ? "Hoạt động" : "Không hoạt động";
    }
}
