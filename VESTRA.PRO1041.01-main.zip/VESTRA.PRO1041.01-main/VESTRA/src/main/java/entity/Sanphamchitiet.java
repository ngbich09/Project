/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 *
 * @author manhh
 */
public class Sanphamchitiet {

    private int ID_san_pham_chi_tiet;
    private int ID_san_pham;
    private String ten_san_pham;
    private String ma_san_pham_chi_tiet;
    private int ID_size;
    private int ID_mau_sac;
    private int so_luong_ton;
    private BigDecimal don_gia;
    private boolean Trang_thai;
    private LocalDateTime Ngay_tao;
    private String Ma_nguoi_tao;
    private LocalDateTime Ngay_cap_nhat;
    private String Ma_nguoi_cap_nhat;
    private String ten_thuong_hieu;
    private String ten_co_ao;
    private String ten_size;
    private String ten_mau;
    private String ten_chat_lieu;
    private String ma_san_pham;

    public Sanphamchitiet() {
    }

    public Sanphamchitiet(int ID_san_pham_chi_tiet, int ID_san_pham, String ten_san_pham, String ma_san_pham_chi_tiet, int ID_size, int ID_mau_sac, int so_luong_ton, BigDecimal don_gia, boolean Trang_thai, LocalDateTime Ngay_tao, String Ma_nguoi_tao, LocalDateTime Ngay_cap_nhat, String Ma_nguoi_cap_nhat, String ten_thuong_hieu, String ten_co_ao, String ten_size, String ten_mau, String ten_chat_lieu, String ma_san_pham) {
        this.ID_san_pham_chi_tiet = ID_san_pham_chi_tiet;
        this.ID_san_pham = ID_san_pham;
        this.ten_san_pham = ten_san_pham;
        this.ma_san_pham_chi_tiet = ma_san_pham_chi_tiet;
        this.ID_size = ID_size;
        this.ID_mau_sac = ID_mau_sac;
        this.so_luong_ton = so_luong_ton;
        this.don_gia = don_gia;
        this.Trang_thai = Trang_thai;
        this.Ngay_tao = Ngay_tao;
        this.Ma_nguoi_tao = Ma_nguoi_tao;
        this.Ngay_cap_nhat = Ngay_cap_nhat;
        this.Ma_nguoi_cap_nhat = Ma_nguoi_cap_nhat;
        this.ten_thuong_hieu = ten_thuong_hieu;
        this.ten_co_ao = ten_co_ao;
        this.ten_size = ten_size;
        this.ten_mau = ten_mau;
        this.ten_chat_lieu = ten_chat_lieu;
        this.ma_san_pham = ma_san_pham;
    }

    public Sanphamchitiet(int ID_san_pham_chi_tiet, int ID_san_pham, String ten_san_pham, String ma_san_pham_chi_tiet, int ID_size, int ID_mau_sac, int so_luong_ton, BigDecimal don_gia, boolean Trang_thai, LocalDateTime Ngay_tao, String Ma_nguoi_tao, LocalDateTime Ngay_cap_nhat, String Ma_nguoi_cap_nhat) {
        this.ID_san_pham_chi_tiet = ID_san_pham_chi_tiet;
        this.ID_san_pham = ID_san_pham;
        this.ten_san_pham = ten_san_pham;
        this.ma_san_pham_chi_tiet = ma_san_pham_chi_tiet;
        this.ID_size = ID_size;
        this.ID_mau_sac = ID_mau_sac;
        this.so_luong_ton = so_luong_ton;
        this.don_gia = don_gia;
        this.Trang_thai = Trang_thai;
        this.Ngay_tao = Ngay_tao;
        this.Ma_nguoi_tao = Ma_nguoi_tao;
        this.Ngay_cap_nhat = Ngay_cap_nhat;
        this.Ma_nguoi_cap_nhat = Ma_nguoi_cap_nhat;
    }

    public int getID_san_pham_chi_tiet() {
        return ID_san_pham_chi_tiet;
    }

    public void setID_san_pham_chi_tiet(int ID_san_pham_chi_tiet) {
        this.ID_san_pham_chi_tiet = ID_san_pham_chi_tiet;
    }

    public int getID_san_pham() {
        return ID_san_pham;
    }

    public void setID_san_pham(int ID_san_pham) {
        this.ID_san_pham = ID_san_pham;
    }

    public String getTen_san_pham() {
        return ten_san_pham;
    }

    public void setTen_san_pham(String ten_san_pham) {
        this.ten_san_pham = ten_san_pham;
    }

    public String getMa_san_pham_chi_tiet() {
        return ma_san_pham_chi_tiet;
    }

    public void setMa_san_pham_chi_tiet(String ma_san_pham_chi_tiet) {
        this.ma_san_pham_chi_tiet = ma_san_pham_chi_tiet;
    }

    public int getID_size() {
        return ID_size;
    }

    public void setID_size(int ID_size) {
        this.ID_size = ID_size;
    }

    public int getID_mau_sac() {
        return ID_mau_sac;
    }

    public void setID_mau_sac(int ID_mau_sac) {
        this.ID_mau_sac = ID_mau_sac;
    }

    public int getSo_luong_ton() {
        return so_luong_ton;
    }

    public void setSo_luong_ton(int so_luong_ton) {
        this.so_luong_ton = so_luong_ton;
    }

    public BigDecimal getDon_gia() {
        return don_gia;
    }

    public void setDon_gia(BigDecimal don_gia) {
        this.don_gia = don_gia;
    }

    public boolean isTrang_thai() {
        return Trang_thai;
    }

    public void setTrang_thai(boolean Trang_thai) {
        this.Trang_thai = Trang_thai;
    }

    public LocalDateTime getNgay_tao() {
        return Ngay_tao;
    }

    public void setNgay_tao(LocalDateTime Ngay_tao) {
        this.Ngay_tao = Ngay_tao;
    }

    public String getMa_nguoi_tao() {
        return Ma_nguoi_tao;
    }

    public void setMa_nguoi_tao(String Ma_nguoi_tao) {
        this.Ma_nguoi_tao = Ma_nguoi_tao;
    }

    public LocalDateTime getNgay_cap_nhat() {
        return Ngay_cap_nhat;
    }

    public void setNgay_cap_nhat(LocalDateTime Ngay_cap_nhat) {
        this.Ngay_cap_nhat = Ngay_cap_nhat;
    }

    public String getMa_nguoi_cap_nhat() {
        return Ma_nguoi_cap_nhat;
    }

    public void setMa_nguoi_cap_nhat(String Ma_nguoi_cap_nhat) {
        this.Ma_nguoi_cap_nhat = Ma_nguoi_cap_nhat;
    }

    public String getTen_thuong_hieu() {
        return ten_thuong_hieu;
    }

    public void setTen_thuong_hieu(String ten_thuong_hieu) {
        this.ten_thuong_hieu = ten_thuong_hieu;
    }

    public String getTen_co_ao() {
        return ten_co_ao;
    }

    public void setTen_co_ao(String ten_co_ao) {
        this.ten_co_ao = ten_co_ao;
    }

    public String getTen_size() {
        return ten_size;
    }

    public void setTen_size(String ten_size) {
        this.ten_size = ten_size;
    }

    public String getTen_mau() {
        return ten_mau;
    }

    public void setTen_mau(String ten_mau) {
        this.ten_mau = ten_mau;
    }

    public String getTen_chat_lieu() {
        return ten_chat_lieu;
    }

    public void setTen_chat_lieu(String ten_chat_lieu) {
        this.ten_chat_lieu = ten_chat_lieu;
    }

    public String getMa_san_pham() {
        return ma_san_pham;
    }

    public void setMa_san_pham(String ma_san_pham) {
        this.ma_san_pham = ma_san_pham;
    }
    

    public String hoatdong(boolean Trang_thai) {
        return Trang_thai ? "Đang bán" : "Ngừng bán";
    }
}
