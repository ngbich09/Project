/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.math.BigDecimal;
import java.sql.Date;

/**
 *
 * @author manhh
 */
public class Voucher {
    private String ten_chuong_trinh_giam_gia;
    private int ID_voucher;
    private String ma_code_voucher;
    private String loai_giam_gia;
    private BigDecimal gia_tri_giam;
    private BigDecimal dieu_kien;
    private BigDecimal muc_giam_toi_da;
    private int so_luong;
    private Date ngay_bat_dau;
    private Date ngay_ket_thuc;
    private boolean Trang_thai;

    public Voucher() {
    }

    public Voucher(String ten_chuong_trinh_giam_gia, int ID_voucher, String ma_code_voucher, String loai_giam_gia, BigDecimal gia_tri_giam, BigDecimal dieu_kien, BigDecimal muc_giam_toi_da, int so_luong, Date ngay_bat_dau, Date ngay_ket_thuc, boolean Trang_thai) {
        this.ten_chuong_trinh_giam_gia = ten_chuong_trinh_giam_gia;
        this.ID_voucher = ID_voucher;
        this.ma_code_voucher = ma_code_voucher;
        this.loai_giam_gia = loai_giam_gia;
        this.gia_tri_giam = gia_tri_giam;
        this.dieu_kien = dieu_kien;
        this.muc_giam_toi_da = muc_giam_toi_da;
        this.so_luong = so_luong;
        this.ngay_bat_dau = ngay_bat_dau;
        this.ngay_ket_thuc = ngay_ket_thuc;
        this.Trang_thai = Trang_thai;
    }

    public String getTen_chuong_trinh_giam_gia() {
        return ten_chuong_trinh_giam_gia;
    }

    public void setTen_chuong_trinh_giam_gia(String ten_chuong_trinh_giam_gia) {
        this.ten_chuong_trinh_giam_gia = ten_chuong_trinh_giam_gia;
    }

    public int getID_voucher() {
        return ID_voucher;
    }

    public void setID_voucher(int ID_voucher) {
        this.ID_voucher = ID_voucher;
    }

    public String getMa_code_voucher() {
        return ma_code_voucher;
    }

    public void setMa_code_voucher(String ma_code_voucher) {
        this.ma_code_voucher = ma_code_voucher;
    }

    public String getLoai_giam_gia() {
        return loai_giam_gia;
    }

    public void setLoai_giam_gia(String loai_giam_gia) {
        this.loai_giam_gia = loai_giam_gia;
    }

    public BigDecimal getGia_tri_giam() {
        return gia_tri_giam;
    }

    public void setGia_tri_giam(BigDecimal gia_tri_giam) {
        this.gia_tri_giam = gia_tri_giam;
    }

    public BigDecimal getDieu_kien() {
        return dieu_kien;
    }

    public void setDieu_kien(BigDecimal dieu_kien) {
        this.dieu_kien = dieu_kien;
    }

    public BigDecimal getMuc_giam_toi_da() {
        return muc_giam_toi_da;
    }

    public void setMuc_giam_toi_da(BigDecimal muc_giam_toi_da) {
        this.muc_giam_toi_da = muc_giam_toi_da;
    }

    public int getSo_luong() {
        return so_luong;
    }

    public void setSo_luong(int so_luong) {
        this.so_luong = so_luong;
    }

    public Date getNgay_bat_dau() {
        return ngay_bat_dau;
    }

    public void setNgay_bat_dau(Date ngay_bat_dau) {
        this.ngay_bat_dau = ngay_bat_dau;
    }

    public Date getNgay_ket_thuc() {
        return ngay_ket_thuc;
    }

    public void setNgay_ket_thuc(Date ngay_ket_thuc) {
        this.ngay_ket_thuc = ngay_ket_thuc;
    }

    public boolean isTrang_thai() {
        return Trang_thai;
    }

    public void setTrang_thai(boolean Trang_thai) {
        this.Trang_thai = Trang_thai;
    }

    public String hoatdong(boolean Trang_thai) {
        return Trang_thai ? "Hoạt động" : "Không hoạt động";
    }
 
    public String Thongtinvoucher() {
        return ma_code_voucher + " | Giảm: " + gia_tri_giam + " | Điều kiện: " + dieu_kien;
    }
}
