/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.math.BigDecimal;
import java.time.LocalDateTime;

/**
 *
 * @author manhh
 */
public class Hoadonchitiet {

    private int ID_hdct;
    private int ID_hoa_don;
    private int ID_san_pham_chi_tiet;
    private int so_luong;
    private BigDecimal don_gia;
    private BigDecimal thanh_tien;
    private boolean Trang_thai;
    private String ten_san_pham;
    private String ten_co_ao;
    private String ten_thuong_hieu;
    private String ten_chat_lieu;
    private String ten_mau;
    private String ten_size;
    private String ma_san_pham_chi_tiet;
    private LocalDateTime ngay_lap_hoa_don;

    public Hoadonchitiet() {
    }

    public Hoadonchitiet(int ID_hdct, int ID_hoa_don, int ID_san_pham_chi_tiet, int so_luong, BigDecimal don_gia, BigDecimal thanh_tien, boolean Trang_thai) {
        this.ID_hdct = ID_hdct;
        this.ID_hoa_don = ID_hoa_don;
        this.ID_san_pham_chi_tiet = ID_san_pham_chi_tiet;
        this.so_luong = so_luong;
        this.don_gia = don_gia;
        this.thanh_tien = thanh_tien;
        this.Trang_thai = Trang_thai;
    }

    public Hoadonchitiet(int ID_hdct, int ID_hoa_don, int ID_san_pham_chi_tiet, int so_luong, BigDecimal don_gia, BigDecimal thanh_tien, boolean Trang_thai, String ten_san_pham, String ten_co_ao, String ten_thuong_hieu, String ten_chat_lieu, String ten_mau, String ten_size, String ma_san_pham_chi_tiet, LocalDateTime ngay_lap_hoa_don) {
        this.ID_hdct = ID_hdct;
        this.ID_hoa_don = ID_hoa_don;
        this.ID_san_pham_chi_tiet = ID_san_pham_chi_tiet;
        this.so_luong = so_luong;
        this.don_gia = don_gia;
        this.thanh_tien = thanh_tien;
        this.Trang_thai = Trang_thai;
        this.ten_san_pham = ten_san_pham;
        this.ten_co_ao = ten_co_ao;
        this.ten_thuong_hieu = ten_thuong_hieu;
        this.ten_chat_lieu = ten_chat_lieu;
        this.ten_mau = ten_mau;
        this.ten_size = ten_size;
        this.ma_san_pham_chi_tiet = ma_san_pham_chi_tiet;
        this.ngay_lap_hoa_don = ngay_lap_hoa_don;
    }

    public int getID_hdct() {
        return ID_hdct;
    }

    public void setID_hdct(int ID_hdct) {
        this.ID_hdct = ID_hdct;
    }

    public int getID_hoa_don() {
        return ID_hoa_don;
    }

    public void setID_hoa_don(int ID_hoa_don) {
        this.ID_hoa_don = ID_hoa_don;
    }

    public int getID_san_pham_chi_tiet() {
        return ID_san_pham_chi_tiet;
    }

    public void setID_san_pham_chi_tiet(int ID_san_pham_chi_tiet) {
        this.ID_san_pham_chi_tiet = ID_san_pham_chi_tiet;
    }

    public int getSo_luong() {
        return so_luong;
    }

    public void setSo_luong(int so_luong) {
        this.so_luong = so_luong;
    }

    public BigDecimal getDon_gia() {
        return don_gia;
    }

    public void setDon_gia(BigDecimal don_gia) {
        this.don_gia = don_gia;
    }

    public BigDecimal getThanh_tien() {
        return thanh_tien;
    }

    public void setThanh_tien(BigDecimal thanh_tien) {
        this.thanh_tien = thanh_tien;
    }

    public boolean isTrang_thai() {
        return Trang_thai;
    }

    public void setTrang_thai(boolean Trang_thai) {
        this.Trang_thai = Trang_thai;
    }

    public String getTen_san_pham() {
        return ten_san_pham;
    }

    public void setTen_san_pham(String ten_san_pham) {
        this.ten_san_pham = ten_san_pham;
    }

    public String getTen_co_ao() {
        return ten_co_ao;
    }

    public void setTen_co_ao(String ten_co_ao) {
        this.ten_co_ao = ten_co_ao;
    }

    public String getTen_thuong_hieu() {
        return ten_thuong_hieu;
    }

    public void setTen_thuong_hieu(String ten_thuong_hieu) {
        this.ten_thuong_hieu = ten_thuong_hieu;
    }

    public String getTen_chat_lieu() {
        return ten_chat_lieu;
    }

    public void setTen_chat_lieu(String ten_chat_lieu) {
        this.ten_chat_lieu = ten_chat_lieu;
    }

    public String getTen_mau() {
        return ten_mau;
    }

    public void setTen_mau(String ten_mau) {
        this.ten_mau = ten_mau;
    }

    public String getTen_size() {
        return ten_size;
    }

    public void setTen_size(String ten_size) {
        this.ten_size = ten_size;
    }

    public String getMa_san_pham_chi_tiet() {
        return ma_san_pham_chi_tiet;
    }

    public void setMa_san_pham_chi_tiet(String ma_san_pham_chi_tiet) {
        this.ma_san_pham_chi_tiet = ma_san_pham_chi_tiet;
    }

    public LocalDateTime getNgay_lap_hoa_don() {
        return ngay_lap_hoa_don;
    }

    public void setNgay_lap_hoa_don(LocalDateTime ngay_lap_hoa_don) {
        this.ngay_lap_hoa_don = ngay_lap_hoa_don;
    }

    public String hoatdong(boolean Trang_thai) {
        return Trang_thai ? "Đã thanh toán" : "Chưa thanh toán";
    }
}
