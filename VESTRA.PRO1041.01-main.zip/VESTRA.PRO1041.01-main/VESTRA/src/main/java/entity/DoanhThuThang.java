/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package entity;

import java.math.BigDecimal;

/**
 *
 * @author manhh
 */
public class DoanhThuThang {

    private int Nam;
    private int Thang;
    private int SanPhamDaBan;
    
    // --- MỚI THÊM: Để đếm số đơn hàng (dùng tính AOV) ---
    private int SoDonHang; 
    // ----------------------------------------------------

    private BigDecimal TongGiaBan;
    private BigDecimal TongGiamGia;
    private BigDecimal DoanhThu;

    public DoanhThuThang() {
    }

    public DoanhThuThang(int Nam, int Thang, int SanPhamDaBan, int SoDonHang, BigDecimal TongGiaBan, BigDecimal TongGiamGia, BigDecimal DoanhThu) {
        this.Nam = Nam;
        this.Thang = Thang;
        this.SanPhamDaBan = SanPhamDaBan;
        this.SoDonHang = SoDonHang; // Thêm vào constructor
        this.TongGiaBan = TongGiaBan;
        this.TongGiamGia = TongGiamGia;
        this.DoanhThu = DoanhThu;
    }

    public int getNam() {
        return Nam;
    }

    public void setNam(int Nam) {
        this.Nam = Nam;
    }

    public int getThang() {
        return Thang;
    }

    public void setThang(int Thang) {
        this.Thang = Thang;
    }

    public int getSanPhamDaBan() {
        return SanPhamDaBan;
    }

    public void setSanPhamDaBan(int SanPhamDaBan) {
        this.SanPhamDaBan = SanPhamDaBan;
    }

    // --- MỚI THÊM: Getter và Setter cho SoDonHang ---
    public int getSoDonHang() {
        return SoDonHang;
    }

    public void setSoDonHang(int SoDonHang) {
        this.SoDonHang = SoDonHang;
    }
    // -----------------------------------------------

    public BigDecimal getTongGiaBan() {
        return TongGiaBan;
    }

    public void setTongGiaBan(BigDecimal TongGiaBan) {
        this.TongGiaBan = TongGiaBan;
    }

    public BigDecimal getTongGiamGia() {
        return TongGiamGia;
    }

    public void setTongGiamGia(BigDecimal TongGiamGia) {
        this.TongGiamGia = TongGiamGia;
    }

    public BigDecimal getDoanhThu() {
        return DoanhThu;
    }

    public void setDoanhThu(BigDecimal DoanhThu) {
        this.DoanhThu = DoanhThu;
    }
}