/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package controller;

import entity.Size;

/**
 *
 * @author manhh
 */
public interface Size_CRUD extends CrudController<Size>{
    
}
