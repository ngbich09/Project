/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package controller;

import entity.Thuonghieu;

/**
 *
 * @author manhh
 */
public interface Thuonghieu_CRUD extends CrudController<Thuonghieu>{
    
}
