/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package controller;

import entity.Chatlieu;

/**
 *
 * @author manhh
 */
public interface Chatlieu_CRUD extends CrudController<Chatlieu>{
    
}
