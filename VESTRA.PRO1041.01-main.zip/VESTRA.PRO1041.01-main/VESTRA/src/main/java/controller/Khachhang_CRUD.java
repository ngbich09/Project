/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package controller;

import entity.Khachhang;



/**
 *
 * @author manhh
 */
public interface Khachhang_CRUD extends CrudController<Khachhang>{
    
}
