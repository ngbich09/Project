/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import controller.Hoadonchitiet_CRUD;
import entity.Hoadonchitiet;
import java.util.List;

/**
 *
 * @author manhh
 */
public interface Hoadonchitiet_DAO extends CrudDAO<Hoadonchitiet, Integer> {

    List<Hoadonchitiet> ListHDCT(int id_hoa_don);

    Hoadonchitiet IDHDCT(int id_hoa_don, int id_san_pham_chi_tiet);

    List<Hoadonchitiet> LISTHDCTINPDF(int ID_hoa_don);

    Hoadonchitiet SoLuongCu(int ID_san_pham_chi_tiet, int id_hoa_don);

    List<Hoadonchitiet> LISTHOADONCT(int ID_HOA_DON);
}
