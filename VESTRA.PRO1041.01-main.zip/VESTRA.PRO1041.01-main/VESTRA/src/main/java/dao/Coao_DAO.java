/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import entity.Coao;
import java.util.List;

/**
 *
 * @author manhh
 */
public interface Coao_DAO extends CrudDAO<Coao, Integer> {

    Coao IDCOAO(String ten_co_ao);

    List<Coao> TENCOAO();

    Coao ID(String ma_co_ao);

    Coao capNhatTrangThai(String ma_co_ao, boolean TrangThaiMS);
}
