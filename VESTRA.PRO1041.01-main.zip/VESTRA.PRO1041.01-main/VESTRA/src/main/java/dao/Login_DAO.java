/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import controller.Login_CRUD;
import entity.Login;
import java.util.List;

/**
 *
 * @author manhh
 */
public interface Login_DAO extends CrudDAO<Login_CRUD, String>{
   Login MaNhanVien(String taikhoan,String makhau); 
}
