/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import entity.Hoadon;
import java.util.List;

/**
 *
 * @author manhh
 */
public interface Hoadon_DAO extends CrudDAO<Hoadon, Integer>{
    List<Hoadon> LISTHD();
    Hoadon       TongTienTT(int ID_hoa_don);
    Hoadon       SDTKH(int ID_hoa_don);
    Hoadon       INHOADON(int ID_hoa_don);
}
