/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import entity.Khachhang;
import java.util.List;

/**
 *
 * @author manhh
 */
public interface Khachhang_DAO extends CrudDAO<Khachhang, Integer> {

    Khachhang KH(String SDT);

    Khachhang IDNHANVIEN(String ma_khach_hang);

    List<Khachhang> search(String keyword);

    List<Khachhang> trangthai(int Trang_thai);
}
