/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import entity.Thuonghieu;
import java.util.List;

/**
 *
 * @author manhh
 */
public interface Thuonghieu_DAO extends CrudDAO<Thuonghieu, Integer> {

    Thuonghieu IDTH(String ten_thuong_hieu);

    List<Thuonghieu> TENTHUONGHIEU();

    Thuonghieu ID(String ma_thuong_hieu);

    Thuonghieu capNhatTrangThai(String ma_thuong_hieu, boolean TrangThaiMS);
}
