/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import entity.Sanpham;
import java.util.List;

/**
 *
 * @author manhh
 */
public interface Sanpham_DAO extends CrudDAO<Sanpham, Integer> {

    Sanpham IDSP(String ma_san_pham);

    List<Sanpham> TimkiemSP(String TKSP);

    List<Sanpham> CBOSP(String thuonghieu);

    List<Sanpham> CBOHD(int HD);

    List<Sanpham> UDSP(String ma_san_pham);

    Sanpham capNhatTrangThai(int ID_san_pham, boolean TrangThaiMoi);
}
