/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import entity.Size;
import java.util.List;

/**
 *
 * @author manhh
 */
public interface Size_DAO extends CrudDAO<Size, Integer> {

    Size IDSize(String ten_size);

    List<Size> TENSIZE();

    Size ID(String ma_size);

    Size capNhatTrangThai(String ma_size, boolean TrangThaiMS);
}
