/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import entity.Sanphamchitiet;
import java.util.List;

/**
 *
 * @author manhh
 */
public interface Sanphamchitiet_DAO extends CrudDAO<Sanphamchitiet, Integer> {

    Sanphamchitiet SPQRCODE(String ma_san_pham_chi_tiet);

    List<Sanphamchitiet> TIMKIEM(String keyword1);

    Sanphamchitiet IDSPCT(String ma_san_pham_chi_tiet);

    Sanphamchitiet IDSPCTUPDATE(String ma_san_pham_chi_tiet);

    List<Sanphamchitiet> TimkiemSPCT(String TKSPCT);

    List<Sanphamchitiet> TimCL(String chatLieu);

    List<Sanphamchitiet> TimCA(String coao);

    List<Sanphamchitiet> TimMS(String mausac);

    List<Sanphamchitiet> TimSZ(String size);

    List<Sanphamchitiet> TimTH(String thuonghieu);

    List<Sanphamchitiet> theoSP(String SP);

    List<Sanphamchitiet> timSP(String SP);

    Sanphamchitiet capNhatTrangThaiSPCT(int ID_san_pham_chi_tiet, boolean TrangThaiMoi);
}
