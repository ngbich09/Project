/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import entity.Mausac;
import java.util.List;

/**
 *
 * @author manhh
 */
public interface Mausac_DAO extends CrudDAO<Mausac, Integer> {

    Mausac IDMau(String ten_mausac);

    List<Mausac> TENMAUSAC();

    Mausac ID(String ma_mau_sac);

    Mausac capNhatTrangThai(String ma_mau_sac, boolean TrangThaiMS);
}
