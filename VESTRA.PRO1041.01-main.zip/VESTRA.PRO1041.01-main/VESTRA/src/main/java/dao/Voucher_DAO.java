/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import entity.Voucher;
import java.util.List;



/**
 *
 * @author manhh
 */
public interface Voucher_DAO extends CrudDAO<Voucher,Integer>{
    List<Voucher> ListLoaiGiam();
    List<Voucher> ListVoucher();
    Voucher IDvoucher(String mavoucher);
    Voucher VoucherBANHANG(String ma_code_voucher);
    List<Voucher> Tim(String ten_chuong_trinh);
}
