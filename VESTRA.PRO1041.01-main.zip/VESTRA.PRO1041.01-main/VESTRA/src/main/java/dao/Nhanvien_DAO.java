/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import entity.Nhanvien;
import java.util.List;

/**
 *
 * @author manhh
 */
public interface Nhanvien_DAO extends CrudDAO<Nhanvien, Integer>{
     Nhanvien IDNHANVIEN(String ma_nhan_vien);
    void updateTrangThai(String ma_nhan_vien, boolean trangThai);
    List<Nhanvien> Tatca (int Trang_thai );
    List<Nhanvien>TimKiem(String keyword);
}
