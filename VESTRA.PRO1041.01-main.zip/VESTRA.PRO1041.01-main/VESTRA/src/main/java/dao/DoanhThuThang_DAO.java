/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import entity.DoanhThuThang;
import entity.Sanphambanchay;
import java.util.List;

/**
 *
 * @author manhh
 */
public interface DoanhThuThang_DAO extends CrudDAO<DoanhThuThang, Iterable>{
      public List<Integer> getListNam();

    // 2. Hàm lấy doanh thu theo Năm (để lọc bảng và biểu đồ)
    public List<DoanhThuThang> getDoanhThuByNam(int nam);

    // 3. Hàm tìm kiếm theo khoảng thời gian
    public List<DoanhThuThang> getDoanhThuByDateRange(String start, String end);

    // 4. Hàm lấy tất cả doanh thu (cũ)
    public List<DoanhThuThang> getDoanhThu();

    // 5. Hàm lấy top sản phẩm bán chạy
    public List<Sanphambanchay> getSanPhamBanChay();
}
