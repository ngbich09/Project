/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package dao;

import entity.Chatlieu;
import java.util.List;

/**
 *
 * @author manhh
 */
public interface Chatlieu_DAO extends CrudDAO<Chatlieu, Integer> {

    Chatlieu IDCHATLIEU(String ten_chat_lieu);

    List<Chatlieu> TENCHATLIEU();

    Chatlieu ID(String ma_chat_lieu);

    Chatlieu capNhatTrangThai(String ma_chat_lieu, boolean TrangThaiMS);
}
