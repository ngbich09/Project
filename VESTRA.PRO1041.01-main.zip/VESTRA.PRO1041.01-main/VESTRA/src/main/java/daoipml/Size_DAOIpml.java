/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daoipml;

import dao.Size_DAO;
import entity.Size;
import java.util.List;
import util.XJdbc;
import util.XQuery;

/**
 *
 * @author manhh
 */
public class Size_DAOIpml implements Size_DAO{
private String sql_all="SELECT ID_size,ma_size,ten_size,Trang_thai  from Size";
private String SQLIDSZ = "SELECT * from Size where ten_size = ?";
private String SQLSize = "SELECT DISTINCT ten_size FROM Size WHERE Trang_thai=1;";
private String sql_sql=" INSERT INTO Size (ma_size,ten_size ) Values (?,?)";
private String sql_update = " UPDATE Size SET ma_size =?, ten_size =? , Trang_thai =? where  ID_size = ? ";
private String SQLIDSZTC = "SELECT * from Size where ma_size = ?";
// chuyển trạng thái ( btn xóa )
private String SQL_UDSZ ="UPDATE Size set Trang_thai = ? WHERE ma_size = ?";
    @Override
    public Size create(Size entity) {
           Object[] data = new Object[]{
            entity.getMa_size(),entity.getTen_size()
        };
        XJdbc.executeUpdate(sql_sql, data);
        return entity;
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void update(Size entity) {
         Object[] data = new Object[]{
            entity.getMa_size(),entity.getTen_size(),entity.isTrang_thai(),entity.getID_size()
        };
        XJdbc.executeUpdate(sql_update, data);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deleteById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Size> findAll() {
return XQuery.getBeanList(Size.class, sql_all);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Size findById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Size IDSize(String ten_size) {
          return XQuery.getSingleBean(Size.class, SQLIDSZ,ten_size);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Size> TENSIZE() {
        return XQuery.getBeanList(Size.class, SQLSize);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Size ID(String ma_size) {
        return XQuery.getSingleBean(Size.class, SQLIDSZTC,ma_size);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Size capNhatTrangThai(String ma_size, boolean TrangThaiMS) {
       int trangThaiInt = TrangThaiMS ? 1 : 0; 
        XJdbc.executeUpdate(SQL_UDSZ, trangThaiInt, ma_size);
        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    return null;
    }
}
