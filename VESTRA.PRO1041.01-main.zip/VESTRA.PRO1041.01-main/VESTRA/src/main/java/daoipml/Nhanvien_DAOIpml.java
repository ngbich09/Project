/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daoipml;

import dao.Nhanvien_DAO;
import entity.Nhanvien;
import java.util.List;
import util.XJdbc;
import util.XQuery;

/**
 *
 * @author manhh
 */
public class Nhanvien_DAOIpml implements Nhanvien_DAO {
    private String sqlUpdateStatus = "UPDATE Nhan_vien SET Trang_thai=?, Ma_nguoi_cap_nhat=? WHERE ma_nhan_vien=?";
// lấy tất cả thông tin của nhân viên
//    phần mới sửa
    String sqlAll = "SELECT \n"
            + "nv.CCCD,    \n"
            + "nv.ma_nhan_vien,\n"
            + "nv.ten_nhan_vien,\n"
            + "nv.ten_dang_nhap,"
            + "nv.ngay_sinh,"
            + "nv.mat_khau,\n"
            + "nv.dia_chi,\n"
            + "nv.email,\n"
            + "nv.gioi_tinh,\n"
            + "nv.SDT,\n"
            + "cv.ten_chuc_vu,\n"
            + "nv.Trang_thai\n"
            + "FROM Nhan_vien nv\n"
            + "JOIN Chuc_vu cv ON nv.ID_chuc_vu = cv.ID_chuc_vu";
//    lấy duy nhất 1 mã nhân viên
    private String SQLIDNV = "select * from Nhan_vien where ma_nhan_vien = ?";
//    Thêm nhân viên mới
    //    phần mới sửa
     private String sqladd = "INSERT INTO Nhan_vien "
            + "(ID_chuc_vu, ma_nhan_vien, ten_nhan_vien, ten_dang_nhap, mat_khau, gioi_tinh,"
            + "CCCD, ngay_sinh, dia_chi, SDT, email, Ma_nguoi_tao, Trang_thai) "
            + "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
          //    phần mới sửa  
    //    Sửa nhân viên dựa vào mã nhân viên
      private String sqlUpdate = "UPDATE Nhan_vien SET ten_nhan_vien=?, ten_dang_nhap=?, mat_khau=?, gioi_tinh=?, "
            + "CCCD=?, ngay_sinh=?, dia_chi=?, SDT=?, email=?, Ma_nguoi_cap_nhat=?, Trang_thai=? "
            + "WHERE ma_nhan_vien=?";
//    phần mới sửa
    private String sqlDelete = "DELETE FROM Nhan_vien WHERE ma_nhan_vien=?";
    //    cập nhật trạng thái
    private String sqltrangthai = "SELECT \n"
            + "    nv.CCCD,\n"
            + "    nv.ma_nhan_vien,\n"
            + "    nv.ten_nhan_vien,\n"
            + "    nv.ten_dang_nhap,\n"
            + "    nv.ngay_sinh,\n"
            + "    nv.mat_khau,\n"
            + "    nv.dia_chi,\n"
            + "    nv.email,\n"
            + "    nv.gioi_tinh,\n"
            + "    nv.SDT,\n"
            + "    cv.ten_chuc_vu,\n"
            + "    nv.Trang_thai\n"
            + "FROM Nhan_vien nv\n"
            + "JOIN Chuc_vu cv ON nv.ID_chuc_vu = cv.ID_chuc_vu\n"
            + "WHERE nv.Trang_thai = ?;";
//    tìm kiếm nhân viên theo mã và tên tương đối
 private String sqlsreach = "SELECT \n"
            + "    nv.CCCD,\n"
            + "    nv.ma_nhan_vien,\n"
            + "    nv.ten_nhan_vien,\n"
            + "    nv.ten_dang_nhap,\n"
            + "    nv.ngay_sinh,\n"
            + "    nv.mat_khau,\n"
            + "    nv.dia_chi,\n"
            + "    nv.email,\n"
            + "    nv.gioi_tinh,\n"
            + "    nv.SDT,\n"
            + "    cv.ten_chuc_vu,\n"
            + "    nv.Trang_thai\n"
            + "FROM Nhan_vien nv\n"
            + "JOIN Chuc_vu cv ON nv.ID_chuc_vu = cv.ID_chuc_vu\n"
            + "WHERE \n"
            + "    nv.ma_nhan_vien LIKE ?\n"
            + "    OR nv.ten_nhan_vien LIKE ?;";
    @Override
//    thêm nhân viên
    public Nhanvien create(Nhanvien entity) {
      //    phần mới sửa
        Object[] data = new Object[]{
            entity.getID_chuc_vu(),      
            entity.getMa_nhan_vien(),    
            entity.getTen_nhan_vien(),  
            entity.getTen_dang_nhap(),   
            entity.getMat_khau(),        
            entity.getGioi_tinh(),       
            entity.getCCCD(),           
            entity.getNgay_sinh(),       
            entity.getDia_chi(),        
            entity.getSDT(),             
            entity.getEmail(),          
            entity.getMa_nguoi_tao(),    
            entity.isTrang_thai()       
        };
        XJdbc.executeUpdate(sqladd, data);
        return entity;
    }
 @Override
    public void update(Nhanvien entity) {
        //    phần mới sửa
        Object[] data = new Object[]{
            entity.getTen_nhan_vien(),
            entity.getTen_dang_nhap(),
            entity.getMat_khau(),
            entity.getGioi_tinh(),
            entity.getCCCD(),
            entity.getNgay_sinh(),
            entity.getDia_chi(),
            entity.getSDT(),
            entity.getEmail(),
            entity.getMa_nguoi_cap_nhat(),
            entity.isTrang_thai(),
            entity.getMa_nhan_vien() 
        };
        XJdbc.executeUpdate(sqlUpdate, data);
    }
    @Override
    public void deleteById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Nhanvien> findAll() {
        return XQuery.getBeanList(Nhanvien.class, sqlAll);
//        trả về danh sách tất cả các nhân viên
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Nhanvien findById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Nhanvien IDNHANVIEN(String ma_nhan_vien) {
        return XQuery.getSingleBean(Nhanvien.class, SQLIDNV, ma_nhan_vien);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void updateTrangThai(String ma_nhan_vien, boolean trangThai) {
        XJdbc.executeUpdate(sqlUpdateStatus, trangThai, "ADMIN", ma_nhan_vien);
// chỉ cập nhật phân ftrạng thái
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Nhanvien> Tatca(int Trang_thai) {
        return XQuery.getBeanList(Nhanvien.class, sqltrangthai, Trang_thai);
// lọc danh sách nhân viên theo trạng thái
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Nhanvien> TimKiem(String keyword) {
        return XQuery.getBeanList(Nhanvien.class, sqlsreach, "%" + keyword + "%", "%" + keyword + "%");
// tìm kiếm nhân viên theo mã và tên
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

}
