/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daoipml;

import dao.Sanphamchitiet_DAO;
import entity.Sanphamchitiet;
import java.util.List;
import util.XJdbc;
import util.XQuery;

/**
 *
 * @author manhh
 */
public class Sanphamchitiet_DAOIpml implements Sanphamchitiet_DAO {

    private String sql_all = "SELECT spct.ma_san_pham_chi_tiet, sp.ma_san_pham, sp.ten_san_pham, spct.so_luong_ton, spct.don_gia, spct.trang_thai, th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao, sz.ten_size, ms.ten_mau FROM San_pham_chi_tiet spct JOIN San_pham sp ON spct.ID_san_pham = sp.ID_san_pham JOIN Size sz ON spct.ID_size = sz.ID_size JOIN Mau_sac ms ON spct.ID_mau_sac = ms.ID_mau_sac JOIN Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu JOIN Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu JOIN Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao ORDER BY spct.ID_san_pham_chi_tiet";
    private String SQLQRCODE = "SELECT spct.*, sp.ma_san_pham, sp.ten_san_pham, th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao, sz.ten_size, ms.ten_mau \n"
            + "FROM San_pham_chi_tiet spct JOIN San_pham sp ON spct.ID_san_pham = sp.ID_san_pham JOIN Size sz ON spct.ID_size = sz.ID_size JOIN Mau_sac ms ON spct.ID_mau_sac = ms.ID_mau_sac JOIN Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu JOIN Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu JOIN Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao WHERE spct.ma_san_pham_chi_tiet = ? ORDER BY spct.ID_san_pham_chi_tiet;";
    private String sql_all_search = "SELECT spct.ma_san_pham_chi_tiet, sp.ma_san_pham, sp.ten_san_pham, spct.so_luong_ton, spct.don_gia, spct.trang_thai, th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao, sz.ten_size, ms.ten_mau "
            + "FROM San_pham_chi_tiet spct JOIN San_pham sp ON spct.ID_san_pham = sp.ID_san_pham JOIN Size sz ON spct.ID_size = sz.ID_size JOIN Mau_sac ms ON spct.ID_mau_sac = ms.ID_mau_sac JOIN Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu JOIN Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu JOIN Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao "
            + "WHERE sp.ten_san_pham LIKE ? OR th.ten_thuong_hieu LIKE ? ORDER BY spct.ID_san_pham_chi_tiet";
    private String SQLIDSPCT = "SELECT * from San_pham_chi_tiet where ma_san_pham_chi_tiet = ?";
    private String SQL_add = "INSERT INTO San_pham_chi_tiet ( ID_san_pham,ma_san_pham_chi_tiet,ID_size,ID_mau_sac,so_luong_ton,don_gia,Ma_nguoi_tao) VALUES (?,?,?,?,?,?,?)";
    private String SQL_update = " UPDATE San_pham_chi_tiet SET ID_san_pham =? ,ma_san_pham_chi_tiet =?,ID_size =?,ID_mau_sac =?,so_luong_ton =?,don_gia =?,Ma_nguoi_cap_nhat=?,Trang_thai=? where ID_san_pham_chi_tiet = ? ";
    private String SQLIDSPCTUPDATE = "SELECT * FROM San_pham_chi_tiet where ma_san_pham_chi_tiet = ? ";
    private String SQL_tim
            = "SELECT spct.ma_san_pham_chi_tiet, sp.ma_san_pham, sp.ten_san_pham, spct.so_luong_ton, spct.don_gia, spct.trang_thai, th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao, sz.ten_size, ms.ten_mau "
            + "FROM San_pham_chi_tiet spct JOIN San_pham sp ON spct.ID_san_pham = sp.ID_san_pham JOIN Size sz ON spct.ID_size = sz.ID_size JOIN Mau_sac ms ON spct.ID_mau_sac = ms.ID_mau_sac JOIN Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu JOIN Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu JOIN Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao "
            + "WHERE spct.ma_san_pham_chi_tiet LIKE ? OR sp.ten_san_pham LIKE ? ORDER BY spct.ID_san_pham_chi_tiet";
    private String SQL_TCL = " SELECT spct.ma_san_pham_chi_tiet, sp.ma_san_pham, sp.ten_san_pham, \n"
            + "       spct.so_luong_ton, spct.don_gia, spct.trang_thai, \n"
            + "       th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao, \n"
            + "       sz.ten_size, ms.ten_mau\n"
            + "FROM San_pham_chi_tiet spct\n"
            + "JOIN San_pham sp ON spct.ID_san_pham = sp.ID_san_pham\n"
            + "JOIN Size sz ON spct.ID_size = sz.ID_size\n"
            + "JOIN Mau_sac ms ON spct.ID_mau_sac = ms.ID_mau_sac\n"
            + "JOIN Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu\n"
            + "JOIN Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu\n"
            + "JOIN Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao\n"
            + "WHERE cl.ten_chat_lieu LIKE ?\n"
            + "ORDER BY spct.ID_san_pham_chi_tiet";
    private String SQL_TCA = " SELECT spct.ma_san_pham_chi_tiet, sp.ma_san_pham, sp.ten_san_pham, \n"
            + "       spct.so_luong_ton, spct.don_gia, spct.trang_thai, \n"
            + "       th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao, \n"
            + "       sz.ten_size, ms.ten_mau\n"
            + "FROM San_pham_chi_tiet spct\n"
            + "JOIN San_pham sp ON spct.ID_san_pham = sp.ID_san_pham\n"
            + "JOIN Size sz ON spct.ID_size = sz.ID_size\n"
            + "JOIN Mau_sac ms ON spct.ID_mau_sac = ms.ID_mau_sac\n"
            + "JOIN Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu\n"
            + "JOIN Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu\n"
            + "JOIN Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao\n"
            + "WHERE ca.ten_co_ao LIKE ?\n"
            + "ORDER BY spct.ID_san_pham_chi_tiet";
    private String SQL_MS = " SELECT spct.ma_san_pham_chi_tiet, sp.ma_san_pham, sp.ten_san_pham, \n"
            + "       spct.so_luong_ton, spct.don_gia, spct.trang_thai, \n"
            + "       th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao, \n"
            + "       sz.ten_size, ms.ten_mau\n"
            + "FROM San_pham_chi_tiet spct\n"
            + "JOIN San_pham sp ON spct.ID_san_pham = sp.ID_san_pham\n"
            + "JOIN Size sz ON spct.ID_size = sz.ID_size\n"
            + "JOIN Mau_sac ms ON spct.ID_mau_sac = ms.ID_mau_sac\n"
            + "JOIN Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu\n"
            + "JOIN Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu\n"
            + "JOIN Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao\n"
            + "WHERE ms.ten_mau LIKE ?\n"
            + "ORDER BY spct.ID_san_pham_chi_tiet";
    private String SQL_SZ = " SELECT spct.ma_san_pham_chi_tiet, sp.ma_san_pham, sp.ten_san_pham, \n"
            + "       spct.so_luong_ton, spct.don_gia, spct.trang_thai, \n"
            + "       th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao, \n"
            + "       sz.ten_size, ms.ten_mau\n"
            + "FROM San_pham_chi_tiet spct\n"
            + "JOIN San_pham sp ON spct.ID_san_pham = sp.ID_san_pham\n"
            + "JOIN Size sz ON spct.ID_size = sz.ID_size\n"
            + "JOIN Mau_sac ms ON spct.ID_mau_sac = ms.ID_mau_sac\n"
            + "JOIN Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu\n"
            + "JOIN Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu\n"
            + "JOIN Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao\n"
            + "WHERE sz.ten_size LIKE ?\n"
            + "ORDER BY spct.ID_san_pham_chi_tiet";
    private String SQL_TH = " SELECT spct.ma_san_pham_chi_tiet, sp.ma_san_pham, sp.ten_san_pham, \n"
            + "       spct.so_luong_ton, spct.don_gia, spct.trang_thai, \n"
            + "       th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao, \n"
            + "       sz.ten_size, ms.ten_mau\n"
            + "FROM San_pham_chi_tiet spct\n"
            + "JOIN San_pham sp ON spct.ID_san_pham = sp.ID_san_pham\n"
            + "JOIN Size sz ON spct.ID_size = sz.ID_size\n"
            + "JOIN Mau_sac ms ON spct.ID_mau_sac = ms.ID_mau_sac\n"
            + "JOIN Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu\n"
            + "JOIN Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu\n"
            + "JOIN Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao\n"
            + "WHERE  th.ten_thuong_hieu LIKE ?\n"
            + "ORDER BY spct.ID_san_pham_chi_tiet";
// lấy tên từ bảng sp sang bảng spct
    private String sql_Tensp = "SELECT\n"
            + "    spct.ID_san_pham_chi_tiet, \n"
            + "    spct.ma_san_pham_chi_tiet, \n"
            + "    sp.ma_san_pham, \n"
            + "    sp.ten_san_pham, \n"
            + "    spct.so_luong_ton, \n"
            + "    spct.don_gia, \n"
            + "    spct.trang_thai, \n"
            + "    th.ten_thuong_hieu, \n"
            + "    cl.ten_chat_lieu, \n"
            + "    ca.ten_co_ao, \n"
            + "    sz.ten_size, \n"
            + "    ms.ten_mau \n"
            + "FROM\n"
            + "    San_pham_chi_tiet spct\n"
            + "INNER JOIN\n"
            + "    San_pham sp ON spct.ID_san_pham = sp.ID_san_pham\n"
            + "INNER JOIN\n"
            + "    Size sz ON spct.ID_size = sz.ID_size\n"
            + "INNER JOIN\n"
            + "    Mau_sac ms ON spct.ID_mau_sac = ms.ID_mau_sac\n"
            + "INNER JOIN\n"
            + "    Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu\n"
            + "INNER JOIN\n"
            + "    Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu\n"
            + "INNER JOIN\n"
            + "    Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao\n"
            + "WHERE \n"
            + "    sp.ten_san_pham LIKE ? \n"
            + "ORDER BY\n"
            + "    spct.ID_san_pham_chi_tiet;";
    // phần click 2 lần chuyển tab
    private String sql_timSP = "SELECT\n"
            + "    spct.ID_san_pham_chi_tiet, \n"
            + "    spct.ma_san_pham_chi_tiet, \n"
            + "    sp.ma_san_pham, \n"
            + "    sp.ten_san_pham, \n"
            + "    spct.so_luong_ton, \n"
            + "    spct.don_gia, \n"
            + "    spct.trang_thai, \n"
            + "    th.ten_thuong_hieu, \n"
            + "    cl.ten_chat_lieu, \n"
            + "    ca.ten_co_ao, \n"
            + "    sz.ten_size, \n"
            + "    ms.ten_mau \n"
            + "FROM\n"
            + "    San_pham_chi_tiet spct\n"
            + "INNER JOIN\n"
            + "    San_pham sp ON spct.ID_san_pham = sp.ID_san_pham\n"
            + "INNER JOIN\n"
            + "    Size sz ON spct.ID_size = sz.ID_size\n"
            + "INNER JOIN\n"
            + "    Mau_sac ms ON spct.ID_mau_sac = ms.ID_mau_sac\n"
            + "INNER JOIN\n"
            + "    Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu\n"
            + "INNER JOIN\n"
            + "    Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu\n"
            + "INNER JOIN\n"
            + "    Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao\n"
            + "WHERE \n"
            + "    sp.ma_san_pham = ? \n" // <-- ĐÃ SỬA: Lọc chính xác theo Mã Sản phẩm
            + "ORDER BY\n"
            + "    spct.ID_san_pham_chi_tiet;";

    // up date trạng thái
    private String sql_UDTT_SPCT = "UPDATE San_pham_chi_tiet set Trang_thai = ? WHERE ID_san_pham_chi_tiet = ?";

    @Override
    public Sanphamchitiet create(Sanphamchitiet entity) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Object[] data = new Object[]{
            entity.getID_san_pham(), entity.getMa_san_pham_chi_tiet(), entity.getID_size(), entity.getID_mau_sac(), entity.getSo_luong_ton(), entity.getDon_gia(), entity.getMa_nguoi_tao()
        };

        XJdbc.executeUpdate(SQL_add, data);
        return entity;
    }

    @Override
    public void update(Sanphamchitiet entity) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Object[] data = new Object[]{
            entity.getID_san_pham(), entity.getMa_san_pham_chi_tiet(), entity.getID_size(), entity.getID_mau_sac(), entity.getSo_luong_ton(), entity.getDon_gia(), entity.getMa_nguoi_cap_nhat(), entity.isTrang_thai(), entity.getID_san_pham_chi_tiet()
        };
        XJdbc.executeUpdate(SQL_update, data);
    }

    @Override
    public void deleteById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Sanphamchitiet> findAll() {
        return XQuery.getBeanList(Sanphamchitiet.class, sql_all);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Sanphamchitiet findById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Sanphamchitiet SPQRCODE(String ma_san_pham_chi_tiet) {
        return XQuery.getSingleBean(Sanphamchitiet.class, SQLQRCODE, ma_san_pham_chi_tiet);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Sanphamchitiet> TIMKIEM(String keyword1) {
        return XQuery.getBeanList(Sanphamchitiet.class, sql_all_search, "%" + keyword1 + "%", "%" + keyword1 + "%");
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Sanphamchitiet IDSPCT(String ma_san_pham_chi_tiet) {
        return XQuery.getSingleBean(Sanphamchitiet.class, SQLIDSPCT, ma_san_pham_chi_tiet);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Sanphamchitiet IDSPCTUPDATE(String ma_san_pham_chi_tiet) {
        return XQuery.getSingleBean(Sanphamchitiet.class, SQLIDSPCTUPDATE, ma_san_pham_chi_tiet);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Sanphamchitiet> TimkiemSPCT(String TKSPCT) {
        return XQuery.getBeanList(Sanphamchitiet.class, SQL_tim, "%" + TKSPCT + "%", "%" + TKSPCT + "%");
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Sanphamchitiet> TimCL(String chatLieu) {
        return XQuery.getBeanList(Sanphamchitiet.class, SQL_TCL, "%" + chatLieu + "%");
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Sanphamchitiet> TimCA(String coao) {
        return XQuery.getBeanList(Sanphamchitiet.class, SQL_TCA, "%" + coao + "%");
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Sanphamchitiet> TimMS(String mausac) {
        return XQuery.getBeanList(Sanphamchitiet.class, SQL_MS, "%" + mausac + "%");
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Sanphamchitiet> TimSZ(String size) {
        return XQuery.getBeanList(Sanphamchitiet.class, SQL_SZ, "%" + size + "%");
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Sanphamchitiet> TimTH(String thuonghieu) {
        return XQuery.getBeanList(Sanphamchitiet.class, SQL_TH, "%" + thuonghieu + "%");
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Sanphamchitiet> theoSP(String SP) {
        return XQuery.getBeanList(Sanphamchitiet.class, sql_Tensp, SP);

        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Sanphamchitiet> timSP(String SP) {
        return XQuery.getBeanList(Sanphamchitiet.class, sql_timSP, SP);

        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Sanphamchitiet capNhatTrangThaiSPCT(int ID_san_pham_chi_tiet, boolean TrangThaiMoi) {
        int trangThaiInt = TrangThaiMoi ? 1 : 0;
        XJdbc.executeUpdate(sql_UDTT_SPCT, trangThaiInt, ID_san_pham_chi_tiet);
        return null;
    }
}
