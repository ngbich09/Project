/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daoipml;

import dao.Hoadon_DAO;
import entity.Hoadon;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import org.bouncycastle.jcajce.provider.symmetric.IDEA;
import util.XJdbc;
import util.XQuery;

/**
 *
 * @author manhh
 */
public class Hoadon_DAOIpml implements Hoadon_DAO {

    private String sqladd = "insert into Hoa_don (ID_nhan_vien,ten_nguoi_nhan,SDT_nguoi_nhan,ID_khach_hang) values(?,?,?,?)";
    private String sqltrangthai = "SELECT hd.ID_hoa_don, nv.ten_nhan_vien, kh.ten_khach_hang, hd.ten_nguoi_nhan, hd.trang_thai_thanh_toan, hd.ngay_lap_hoa_don\n"
            + "FROM Hoa_don hd JOIN Nhan_vien nv ON hd.ID_nhan_vien = nv.ID_nhan_vien JOIN Khach_hang kh ON hd.ID_khach_hang = kh.ID_khach_hang WHERE hd.trang_thai_thanh_toan = 0;";
    private String SQLSDT = "Select * from Hoa_don where ID_hoa_don=?";
    private String SQLHDNOW = "SELECT TOP 1 hd.ID_hoa_don, nv.ten_nhan_vien, kh.ten_khach_hang, kh.SDT, hd.ten_nguoi_nhan, hd.trang_thai_thanh_toan, hd.ngay_lap_hoa_don\n"
            + "FROM Hoa_don hd JOIN Nhan_vien nv ON hd.ID_nhan_vien = nv.ID_nhan_vien JOIN Khach_hang kh ON hd.ID_khach_hang = kh.ID_khach_hang WHERE hd.trang_thai_thanh_toan = 0 ORDER BY hd.ID_hoa_don DESC;";
    private String SQLTONGTIENTT = "SELECT SUM(so_luong * don_gia) AS tong_tien_tam_tinh FROM Hoa_don_chi_tiet WHERE ID_hoa_don = ?";
    private String SQLDELETE = "Delete from Hoa_don WHERE ID_hoa_don = ?";
    private final String sqlFindAll = """
        SELECT hd.ID_hoa_don, hd.ID_khach_hang, nv.ten_nhan_vien, kh.ten_khach_hang, kh.ma_khach_hang, kh.SDT, hd.ghi_chu, hd.tong_tien_tam_tinh, hd.tien_giam_voucher, hd.tong_tien_thanh_toan, hd.ngay_lap_hoa_don, hd.phuong_thuc_thanh_toan, hd.trang_thai_thanh_toan
        FROM Hoa_don hd JOIN Nhan_vien nv ON hd.ID_nhan_vien = nv.ID_nhan_vien LEFT JOIN Khach_hang kh ON hd.ID_khach_hang = kh.ID_khach_hang
    """;
    private String SQLINPDF = "SELECT k.ten_khach_hang, n.ten_nhan_vien, h.ngay_lap_hoa_don, h.tong_tien_tam_tinh\n"
            + "FROM Hoa_don h JOIN Khach_hang k ON h.ID_khach_hang = k.ID_khach_hang\n"
            + "JOIN Nhan_vien n ON h.ID_nhan_vien = n.ID_nhan_vien\n"
            + "WHERE h.ID_hoa_don = ?";
    private String SQLUPDATEYESVOUCHER = "update Hoa_don set ID_voucher=?, ghi_chu = ?,tien_giam_voucher = ?,tong_tien_tam_tinh=?,tong_tien_thanh_toan=?,trang_thai_thanh_toan=? ,phuong_thuc_thanh_toan=? where ID_hoa_don =?";
    private String SQLUPDATENOVOUCHER = "update Hoa_don set ghi_chu = ?,tien_giam_voucher = ?,tong_tien_tam_tinh=?,tong_tien_thanh_toan=?,trang_thai_thanh_toan=? ,phuong_thuc_thanh_toan=? where ID_hoa_don =?";
   private final String sqlTimKiem = sqlFindAll + """
WHERE CAST(hd.ID_hoa_don AS NVARCHAR(50)) LIKE ? OR kh.ten_khach_hang LIKE ? OR CONVERT(VARCHAR, hd.ngay_lap_hoa_don, 105) = ? 
        OR (CASE WHEN hd.trang_thai_thanh_toan = 1 THEN N'Đã thanh toán' ELSE N'Chưa thanh toán' END) LIKE ? OR kh.SDT = ?  
    """;
    @Override
    public Hoadon create(Hoadon entity) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Object[] date = new Object[]{
            entity.getID_nhan_vien(), entity.getTen_nguoi_nhan(), entity.getSDT_nguoi_nhan(), entity.getID_khach_hang()
        };
        XJdbc.executeUpdate(sqladd, date);
        return entity;
    }

    @Override
    public void update(Hoadon entity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody

    }

    public void UPDATEYESVOUCHER(Hoadon entity) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Object[] date = new Object[]{
            entity.getID_voucher(), entity.getGhi_chu(), entity.getTien_giam_voucher(), entity.getTong_tien_tam_tinh(), entity.getTong_tien_thanh_toan(), entity.isTrang_thai_thanh_toan(), entity.isPhuong_thuc_thanh_toan(), entity.getID_hoa_don()
        };
        XJdbc.executeUpdate(SQLUPDATEYESVOUCHER, date);
    }

    public void UPDATENOVOUCHER(Hoadon entity) {
        Object[] date = new Object[]{
            entity.getGhi_chu(), entity.getTien_giam_voucher(), entity.getTong_tien_tam_tinh(), entity.getTong_tien_thanh_toan(), entity.isTrang_thai_thanh_toan(), entity.isPhuong_thuc_thanh_toan(), entity.getID_hoa_don()
        };
        XJdbc.executeUpdate(SQLUPDATENOVOUCHER, date);
    }

    @Override
    public void deleteById(Integer id) {
        XJdbc.executeUpdate(SQLDELETE, id);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Hoadon> findAll() {
        return getListBySql(sqlFindAll);
    }

    @Override
    public Hoadon findById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Hoadon> LISTHD() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        return XQuery.getBeanList(Hoadon.class, sqltrangthai);
    }

//     hàm lấy ngày chuẩn nay
    public List<Hoadon> LISTHDD() {
        List<Hoadon> list = new ArrayList<>();
        try {
            ResultSet rs = XJdbc.executeQuery(sqltrangthai);
while (rs.next()) {
                Hoadon hd = new Hoadon();
                hd.setID_hoa_don(rs.getInt("ID_hoa_don"));
                hd.setTen_nhan_vien(rs.getString("ten_nhan_vien"));
                hd.setTen_nguoi_nhan(rs.getString("ten_nguoi_nhan"));
                hd.setTen_khach_hang(rs.getString("ten_khach_hang"));
                hd.setTrang_thai_thanh_toan(rs.getBoolean("trang_thai_thanh_toan"));
                Timestamp ts = rs.getTimestamp("ngay_lap_hoa_don");
                LocalDateTime date = (ts == null ? null : ts.toLocalDateTime());
                hd.setNgay_lap_hoa_don(date);
                list.add(hd);
            }
            rs.getStatement().getConnection().close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    public Hoadon HOADONMOINHAT() {
        Hoadon hd = null;
        try {
            ResultSet rs = XJdbc.executeQuery(SQLHDNOW);
            if (rs.next()) {
                hd = new Hoadon();
                hd.setID_hoa_don(rs.getInt("ID_hoa_don"));
                hd.setTen_nhan_vien(rs.getString("ten_nhan_vien"));
                hd.setTen_nguoi_nhan(rs.getString("ten_nguoi_nhan"));
                hd.setTen_khach_hang(rs.getString("ten_khach_hang"));
                hd.setTrang_thai_thanh_toan(rs.getBoolean("trang_thai_thanh_toan"));

                Timestamp ts = rs.getTimestamp("ngay_lap_hoa_don");
                LocalDateTime date = (ts == null ? null : ts.toLocalDateTime());
                hd.setNgay_lap_hoa_don(date);
            }
            rs.getStatement().getConnection().close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return hd;
    }

    public Hoadon INHOADONA(int id_hoa_don) {
        Hoadon hd = null;
        try {
            ResultSet rs = XJdbc.executeQuery(SQLINPDF, id_hoa_don);
            if (rs.next()) {
                hd = new Hoadon();
                hd.setTen_khach_hang(rs.getString("ten_khach_hang"));
                hd.setTen_nhan_vien(rs.getString("ten_nhan_vien"));
                hd.setTong_tien_tam_tinh(rs.getBigDecimal("tong_tien_tam_tinh"));
                Timestamp ts = rs.getTimestamp("ngay_lap_hoa_don");
                hd.setNgay_lap_hoa_don(ts == null ? null : ts.toLocalDateTime());
            }
            rs.getStatement().getConnection().close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return hd;
    }

    @Override
    public Hoadon SDTKH(int ID_hoa_don) {
        return XQuery.getSingleBean(Hoadon.class, SQLSDT, ID_hoa_don);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Hoadon TongTienTT(int ID_hoa_don) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        return XQuery.getSingleBean(Hoadon.class, SQLTONGTIENTT, ID_hoa_don);
    }

   public List<Hoadon> timKiem(String keyword) {
        String keyLike = "%" + keyword + "%"; 
        String keyExact = keyword;            
        return getListBySql(sqlTimKiem, keyLike, keyLike, keyExact, keyLike, keyExact);
    }

    private List<Hoadon> getListBySql(String sql, Object... args) {
        List<Hoadon> list = new ArrayList<>();
        try {
            ResultSet rs = XJdbc.executeQuery(sql, args);
            while (rs.next()) {
                Hoadon hd = new Hoadon();
                hd.setID_hoa_don(rs.getInt("ID_hoa_don"));
                hd.setID_khach_hang(rs.getInt("ID_khach_hang"));
                hd.setMa_khach_hang(rs.getString("ma_khach_hang"));
                hd.setTen_nhan_vien(rs.getString("ten_nhan_vien"));
                hd.setTen_khach_hang(rs.getString("ten_khach_hang"));
                hd.setSDT_nguoi_nhan(rs.getString("SDT"));
                hd.setGhi_chu(rs.getString("ghi_chu"));
                hd.setTong_tien_tam_tinh(rs.getBigDecimal("tong_tien_tam_tinh"));
                hd.setTien_giam_voucher(rs.getBigDecimal("tien_giam_voucher"));
                hd.setTong_tien_thanh_toan(rs.getBigDecimal("tong_tien_thanh_toan"));
                Timestamp ts = rs.getTimestamp("ngay_lap_hoa_don");
                if (ts != null) {
                    hd.setNgay_lap_hoa_don(ts.toLocalDateTime());
                }
                hd.setPhuong_thuc_thanh_toan(rs.getBoolean("phuong_thuc_thanh_toan"));
                hd.setTrang_thai_thanh_toan(rs.getBoolean("trang_thai_thanh_toan"));
                list.add(hd);
            }
            rs.getStatement().getConnection().close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public Hoadon INHOADON(int ID_hoa_don) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        return XQuery.getSingleBean(Hoadon.class, SQLINPDF, ID_hoa_don);
    }
}
