/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daoipml;

import entity.DoanhThuThang;
import entity.Sanphambanchay;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;
import util.XJdbc;
import util.XQuery;

/**
 *
 * @author manhh
 */
public class DoanhThuThang_DAOipml implements dao.DoanhThuThang_DAO {
// 1. Cập nhật SQL theo Ngày
    private final String sqlDoanhThuTheoNgay = """
            SELECT T_Ban.Nam, T_Ban.Thang, T_Ban.SanPhamDaBan, T_Ban.SoDonHang, T_Ban.TongGiaBan, ISNULL(T_Giam.TongGiamGia, 0) AS TongGiamGia, (T_Ban.TongGiaBan - ISNULL(T_Giam.TongGiamGia, 0)) AS DoanhThu 
            FROM (SELECT YEAR(hd.ngay_lap_hoa_don) AS Nam, MONTH(hd.ngay_lap_hoa_don) AS Thang, SUM(hdct.so_luong) AS SanPhamDaBan, COUNT(DISTINCT hd.ID_hoa_don) AS SoDonHang, SUM(hdct.don_gia * hdct.so_luong) AS TongGiaBan FROM Hoa_don hd JOIN Hoa_don_chi_tiet hdct ON hd.ID_hoa_don = hdct.ID_hoa_don WHERE CAST(hd.ngay_lap_hoa_don AS DATE) BETWEEN ? AND ? GROUP BY YEAR(hd.ngay_lap_hoa_don), MONTH(hd.ngay_lap_hoa_don)) AS T_Ban 
            LEFT JOIN (SELECT YEAR(ngay_lap_hoa_don) AS Nam, MONTH(ngay_lap_hoa_don) AS Thang, SUM(tien_giam_voucher) AS TongGiamGia FROM Hoa_don WHERE CAST(ngay_lap_hoa_don AS DATE) BETWEEN ? AND ? GROUP BY YEAR(ngay_lap_hoa_don), MONTH(ngay_lap_hoa_don)) AS T_Giam ON T_Ban.Nam = T_Giam.Nam AND T_Ban.Thang = T_Giam.Thang 
            ORDER BY T_Ban.Nam, T_Ban.Thang
            """;

    // 2. Cập nhật SQL theo Năm
    private final String sqlDoanhThuTheoNam = """
            SELECT T_Ban.Nam, T_Ban.Thang, T_Ban.SanPhamDaBan, T_Ban.SoDonHang, T_Ban.TongGiaBan, ISNULL(T_Giam.TongGiamGia, 0) AS TongGiamGia, (T_Ban.TongGiaBan - ISNULL(T_Giam.TongGiamGia, 0)) AS DoanhThu
            FROM (SELECT YEAR(hd.ngay_lap_hoa_don) AS Nam, MONTH(hd.ngay_lap_hoa_don) AS Thang, SUM(hdct.so_luong) AS SanPhamDaBan, COUNT(DISTINCT hd.ID_hoa_don) AS SoDonHang, SUM(hdct.don_gia * hdct.so_luong) AS TongGiaBan FROM Hoa_don hd JOIN Hoa_don_chi_tiet hdct ON hd.ID_hoa_don = hdct.ID_hoa_don GROUP BY YEAR(hd.ngay_lap_hoa_don), MONTH(hd.ngay_lap_hoa_don)) AS T_Ban
            LEFT JOIN (SELECT YEAR(ngay_lap_hoa_don) AS Nam, MONTH(ngay_lap_hoa_don) AS Thang, SUM(tien_giam_voucher) AS TongGiamGia FROM Hoa_don GROUP BY YEAR(ngay_lap_hoa_don), MONTH(ngay_lap_hoa_don)) AS T_Giam ON T_Ban.Nam = T_Giam.Nam AND T_Ban.Thang = T_Giam.Thang
            WHERE T_Ban.Nam = ? ORDER BY T_Ban.Nam, T_Ban.Thang
            """;
    // Doanh thu all 
    private final String sqlDoanhThu = """
        SELECT YEAR(hd.ngay_lap_hoa_don) AS Nam, MONTH(hd.ngay_lap_hoa_don) AS Thang, SUM(hdct.so_luong) AS SanPhamDaBan, SUM(hdct.don_gia * hdct.so_luong) AS TongGiaBan, 0 AS TongGiamGia, SUM(hdct.don_gia * hdct.so_luong) AS DoanhThu
        FROM Hoa_don hd JOIN Hoa_don_chi_tiet hdct ON hd.ID_hoa_don = hdct.ID_hoa_don
        GROUP BY YEAR(hd.ngay_lap_hoa_don), MONTH(hd.ngay_lap_hoa_don) ORDER BY Nam, Thang
    """;
    // Lay nam 
    private final String sqlGetNam = "SELECT DISTINCT YEAR(ngay_lap_hoa_don) AS Nam FROM Hoa_don ORDER BY Nam DESC";
    
    // Top 10 san pham (Mặc định - Toàn thời gian)
    private final String sqlSanPhamBanChay = """
        SELECT TOP 10 spct.ID_san_pham_chi_tiet AS Ma_san_pham_chi_tiet, sp.ma_san_pham AS Ma_san_pham, sp.ten_san_pham AS Ten_san_pham, th.ten_thuong_hieu AS Ten_thuong_hieu, sz.ten_size AS Ten_size, ca.ten_co_ao AS Ten_co_ao, cl.ten_chat_lieu AS Ten_chat_lieu, ms.ten_mau AS Ten_mau, SUM(hdct.so_luong) AS So_Luot_Ban, spct.don_gia AS Gia_ban, (SUM(hdct.so_luong) * spct.don_gia) AS Thanh_tien
        FROM Hoa_don_chi_tiet hdct JOIN San_pham_chi_tiet spct ON hdct.ID_san_pham_chi_tiet = spct.ID_san_pham_chi_tiet JOIN San_pham sp ON spct.ID_san_pham = sp.ID_san_pham JOIN Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu JOIN Size sz ON spct.ID_size = sz.ID_size JOIN Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao JOIN Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu JOIN Mau_sac ms ON spct.ID_mau_sac = ms.ID_mau_sac
        GROUP BY spct.ID_san_pham_chi_tiet, sp.ma_san_pham, sp.ten_san_pham, th.ten_thuong_hieu, sz.ten_size, ca.ten_co_ao, cl.ten_chat_lieu, ms.ten_mau, spct.don_gia ORDER BY So_Luot_Ban DESC
    """;

 //MỚI THÊM: SQL Lấy Top 10 sản phẩm THEO KHOẢNG NGÀY
 private final String sqlSanPhamBanChayTheoNgay = """
        SELECT TOP 10 spct.ID_san_pham_chi_tiet AS Ma_san_pham_chi_tiet, sp.ma_san_pham AS Ma_san_pham, sp.ten_san_pham AS Ten_san_pham, th.ten_thuong_hieu AS Ten_thuong_hieu, sz.ten_size AS Ten_size, ca.ten_co_ao AS Ten_co_ao, cl.ten_chat_lieu AS Ten_chat_lieu, ms.ten_mau AS Ten_mau, SUM(hdct.so_luong) AS So_Luot_Ban, spct.don_gia AS Gia_ban, (SUM(hdct.so_luong) * spct.don_gia) AS Thanh_tien
        FROM Hoa_don_chi_tiet hdct JOIN Hoa_don hd ON hdct.ID_hoa_don = hd.ID_hoa_don JOIN San_pham_chi_tiet spct ON hdct.ID_san_pham_chi_tiet = spct.ID_san_pham_chi_tiet JOIN San_pham sp ON spct.ID_san_pham = sp.ID_san_pham JOIN Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu JOIN Size sz ON spct.ID_size = sz.ID_size JOIN Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao JOIN Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu JOIN Mau_sac ms ON spct.ID_mau_sac = ms.ID_mau_sac
        WHERE CAST(hd.ngay_lap_hoa_don AS DATE) BETWEEN ? AND ? GROUP BY spct.ID_san_pham_chi_tiet, sp.ma_san_pham, sp.ten_san_pham, th.ten_thuong_hieu, sz.ten_size, ca.ten_co_ao, cl.ten_chat_lieu, ms.ten_mau, spct.don_gia ORDER BY So_Luot_Ban DESC
    """;

    @Override
    public List<DoanhThuThang> getDoanhThuByDateRange(String ngayBatDau, String ngayKetThuc) {
        // Truyền 4 tham số: start, end (cho bảng bán) và start, end (cho bảng giảm giá)
        return XQuery.getBeanList(DoanhThuThang.class, sqlDoanhThuTheoNgay, ngayBatDau, ngayKetThuc, ngayBatDau, ngayKetThuc);
    }

    @Override
    public List<DoanhThuThang> getDoanhThu() {
        return XQuery.getBeanList(DoanhThuThang.class, sqlDoanhThu);
    }

    @Override
    public List<DoanhThuThang> getDoanhThuByNam(int nam) {
        return XQuery.getBeanList(DoanhThuThang.class, sqlDoanhThuTheoNam, nam);
    }

    @Override
    public List<Sanphambanchay> getSanPhamBanChay() {
        return XQuery.getBeanList(Sanphambanchay.class, sqlSanPhamBanChay);
    }

    // MỚI THÊM: Hàm thực thi lấy sản phẩm bán chạy theo ngày 
    
    public List<Sanphambanchay> getSanPhamBanChayByDate(String start, String end) {
        return XQuery.getBeanList(Sanphambanchay.class, sqlSanPhamBanChayTheoNgay, start, end);
    }

    @Override
    public List<Integer> getListNam() {
        List<Integer> list = new ArrayList<>();
        try {
            ResultSet rs = XJdbc.executeQuery(sqlGetNam);
            while (rs.next()) {
                list.add(rs.getInt("Nam"));
            }
            rs.getStatement().getConnection().close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    @Override
    public DoanhThuThang create(DoanhThuThang entity) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void update(DoanhThuThang entity) {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public List<DoanhThuThang> findAll() {
        throw new UnsupportedOperationException("Not supported yet.");
    }

    @Override
    public void deleteById(Iterable id) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }

    @Override
    public DoanhThuThang findById(Iterable id) {
        throw new UnsupportedOperationException("Not supported yet."); 
    }
}