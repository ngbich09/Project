/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daoipml;

import dao.Coao_DAO;
import entity.Coao;
import java.util.List;
import util.XJdbc;
import util.XQuery;

/**
 *
 * @author manhh
 */
public class Coao_DAOIpml implements Coao_DAO {

    private String sql_full = "SELECT ID_co_ao,ma_co_ao,ten_co_ao,Trang_thai  from Co_ao";
    private String SQLID = "SELECT * from Co_ao where ten_co_ao = ?";
    private String SQLTenCoAo = "SELECT DISTINCT ten_co_ao FROM Co_ao WHERE Trang_thai=1";
    private String sql_add = "INSERT INTO Co_ao (ma_co_ao,ten_co_ao ) Values (?,?)";
    private String sql_update = "UPDATE  Co_ao set ma_co_ao = ?, ten_co_ao = ? , Trang_thai =? where ID_co_ao = ?";
    private String SQLIDCA = "SELECT * from Co_ao where ma_co_ao = ?";
    private String SQL_UDCA = "UPDATE Co_ao set Trang_thai = ? WHERE ma_co_ao = ?";

    @Override
    public Coao create(Coao entity) {
        Object[] data = new Object[]{
            entity.getMa_co_ao(), entity.getTen_co_ao()

        };
        XJdbc.executeUpdate(sql_add, data);
        return entity;
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void update(Coao entity) {
        Object[] data = new Object[]{
            entity.getMa_co_ao(), entity.getTen_co_ao(), entity.isTrang_thai(), entity.getID_co_ao()

        };
        XJdbc.executeUpdate(sql_update, data);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deleteById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Coao> findAll() {
        return XQuery.getBeanList(Coao.class, sql_full);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Coao findById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Coao IDCOAO(String ten_co_ao) {
        return XQuery.getSingleBean(Coao.class, SQLID, ten_co_ao);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Coao> TENCOAO() {
        return XQuery.getBeanList(Coao.class, SQLTenCoAo);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Coao ID(String ma_co_ao) {
        return XQuery.getSingleBean(Coao.class, SQLIDCA, ma_co_ao);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Coao capNhatTrangThai(String ma_co_ao, boolean TrangThaiMS) {
        int trangThaiInt = TrangThaiMS ? 1 : 0;
        XJdbc.executeUpdate(SQL_UDCA, trangThaiInt, ma_co_ao);
        // hàm này là hàm trả về gtri nên để trả về null tóm lại nó báo lỗi click nhảy về null return null

        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        return null;
    }
    //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
}
