/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daoipml;

import dao.Mausac_DAO;
import entity.Mausac;
import java.util.List;
import util.XJdbc;
import util.XQuery;

/**
 *
 * @author manhh
 */
public class Mausac_DAOIpml implements Mausac_DAO{
private String sql_all = "SELECT ID_mau_sac,ma_mau_sac,ten_mau,Trang_thai  from Mau_sac";
private String SQLIDMau = "SELECT * from Mau_sac where ten_mau = ?";
private String SQLMAUSAC = "SELECT DISTINCT ten_mau FROM Mau_sac WHERE Trang_thai=1;";
private String sql_add =" INSERT INTO Mau_sac(ma_mau_sac,ten_mau ) Values (?,?) ";
private String sql_update =" UPDATE Mau_sac SET  ten_mau = ?,Trang_thai = ? WHERE ID_mau_sac = ? ";
private String SQLID = "SELECT * from Mau_sac where ma_mau_sac = ?";
// đổi trạng thái btn ( xóa )
private String SQL_UDMS="UPDATE Mau_sac set Trang_thai = ? WHERE ma_mau_sac = ?";
    @Override
    public Mausac create(Mausac entity) {
 Object[] data = new Object[]{
            entity.getMa_mau_sac(),entity.getTen_mau()
        };
         XJdbc.executeUpdate(sql_add, data);
        return entity;
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void update(Mausac entity) {
  Object [] data = new Object[]{
            entity.getTen_mau(),entity.isTrang_thai(),entity.getID_mau_sac()
        };
        XJdbc.executeUpdate(sql_update, data);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deleteById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Mausac> findAll() {
        return XQuery.getBeanList(Mausac.class, sql_all);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Mausac findById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Mausac IDMau(String ten_mausac) {
return XQuery.getSingleBean(Mausac.class, SQLIDMau,ten_mausac);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Mausac> TENMAUSAC() {
  return XQuery.getBeanList(Mausac.class, SQLMAUSAC);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Mausac ID(String ma_mau_sac) {
   return XQuery.getSingleBean(Mausac.class, SQLID,ma_mau_sac);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Mausac capNhatTrangThai(String ma_mau_sac, boolean TrangThaiMS) {
          int trangThaiInt = TrangThaiMS ? 1 : 0; 
        XJdbc.executeUpdate(SQL_UDMS, trangThaiInt, ma_mau_sac);
             // hàm này là hàm trả về gtri nên để trả về null tóm lại nó báo lỗi click nhảy về null return null

        //throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        return null;
    }
}
