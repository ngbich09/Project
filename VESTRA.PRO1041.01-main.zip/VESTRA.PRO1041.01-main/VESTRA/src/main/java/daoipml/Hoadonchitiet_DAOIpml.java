/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daoipml;

import dao.Hoadonchitiet_DAO;
import entity.Hoadonchitiet;
import java.util.List;
import util.XJdbc;
import util.XQuery;

/**
 *
 * @author manhh
 */
public class Hoadonchitiet_DAOIpml implements Hoadonchitiet_DAO {

    private String SQLHDCT = "SELECT hdct.ID_san_pham_chi_tiet, spct.ma_san_pham_chi_tiet, sp.ten_san_pham, ca.ten_co_ao, th.ten_thuong_hieu, cl.ten_chat_lieu, ms.ten_mau, sz.ten_size, hdct.so_luong, hdct.don_gia, hdct.thanh_tien "
            + "FROM Hoa_don_chi_tiet hdct JOIN San_pham_chi_tiet spct ON hdct.ID_san_pham_chi_tiet = spct.ID_san_pham_chi_tiet JOIN San_pham sp ON spct.ID_san_pham = sp.ID_san_pham JOIN Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao JOIN Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu JOIN Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu JOIN Mau_sac ms ON spct.ID_mau_sac = ms.ID_mau_sac JOIN Size sz ON spct.ID_size = sz.ID_size "
            + "WHERE hdct.ID_hoa_don = ?;";
    private String SQLADD = "insert into Hoa_don_chi_tiet (ID_hoa_don,ID_san_pham_chi_tiet,so_luong,don_gia) VALUES (?,?,?,?)";
    private String SQLUPDATE = "update Hoa_don_chi_tiet set so_luong = ? where ID_hdct = ?";
    private String IDHDCT = "SELECT *  FROM Hoa_don_chi_tiet  WHERE ID_hoa_don = ? AND ID_san_pham_chi_tiet = ?";
    private String SQLDELETE = "delete Hoa_don_chi_tiet where ID_hdct=?";
    private String SQLFINDALL = "SELECT HDCT.ID_hoa_don, HDCT.ID_hdct, SP.ten_san_pham, HDCT.so_luong, HDCT.don_gia, HDCT.Trang_thai "
            + "FROM Hoa_don_chi_tiet HDCT JOIN San_pham_chi_tiet SPCT ON HDCT.ID_san_pham_chi_tiet = SPCT.ID_san_pham_chi_tiet JOIN San_pham SP ON SPCT.ID_san_pham = SP.ID_san_pham;";
    private String SQLINPDF = "SELECT KH.ten_khach_hang, NV.ten_nhan_vien, HD.ngay_lap_hoa_don, HD.tong_tien_tam_tinh, SP.ten_san_pham, HDCT.so_luong, HDCT.don_gia, HDCT.thanh_tien\n"
            + "FROM Hoa_don HD JOIN Khach_hang KH ON HD.ID_khach_hang=KH.ID_khach_hang JOIN Nhan_vien NV ON HD.ID_nhan_vien=NV.ID_nhan_vien JOIN Hoa_don_chi_tiet HDCT ON HD.ID_hoa_don=HDCT.ID_hoa_don JOIN San_pham_chi_tiet SPCT ON HDCT.ID_san_pham_chi_tiet=SPCT.ID_san_pham_chi_tiet JOIN San_pham SP ON SPCT.ID_san_pham=SP.ID_san_pham WHERE HD.ID_hoa_don=?";
    private String SQLDELETEHDCT = "DELETE FROM Hoa_don_chi_tiet WHERE ID_hdct = ?";
    private String SQLFINDBYMASPCT = "SELECT *  FROM Hoa_don_chi_tiet  WHERE ID_san_pham_chi_tiet = ? AND ID_hoa_don = ?";
    private String SQLHDCTBYID = "SELECT hdct.ID_hoa_don, hdct.ID_hdct, sp.ten_san_pham, hdct.so_luong, hdct.don_gia FROM Hoa_don_chi_tiet hdct JOIN San_pham_chi_tiet spct ON hdct.ID_san_pham_chi_tiet=spct.ID_san_pham_chi_tiet JOIN San_pham sp ON spct.ID_san_pham=sp.ID_san_pham WHERE hdct.ID_hoa_don=?;";

    private final String SQL_FIND_BY_HOADON = "SELECT * FROM Hoa_don_chi_tiet WHERE ID_hoa_don = ?";

    @Override
    public Hoadonchitiet create(Hoadonchitiet entity) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Object[] date = new Object[]{
            entity.getID_hoa_don(), entity.getID_san_pham_chi_tiet(), entity.getSo_luong(), entity.getDon_gia()
        };
        XJdbc.executeUpdate(SQLADD, date);
        return entity;
    }

    @Override
    public void update(Hoadonchitiet entity) {
        Object[] date = new Object[]{
            entity.getSo_luong(), entity.getID_hdct()
        };
        XJdbc.executeUpdate(SQLUPDATE, date);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deleteById(Integer id) {
        XJdbc.executeUpdate(SQLDELETEHDCT, id);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Hoadonchitiet> findAll() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        return XQuery.getBeanList(Hoadonchitiet.class, SQLFINDALL);
    }

    @Override
    public Hoadonchitiet findById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    public List<Hoadonchitiet> findByHoaDonId(int idHoaDon) {
        return XQuery.getBeanList(Hoadonchitiet.class, SQL_FIND_BY_HOADON, idHoaDon);
    }

    public List<Hoadonchitiet> LISTHOADONCT(int ID_HOA_DON) {
        return XQuery.getBeanList(Hoadonchitiet.class, SQLHDCTBYID, ID_HOA_DON);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Hoadonchitiet> ListHDCT(int id_hoa_don) {
        return XQuery.getBeanList(Hoadonchitiet.class, SQLHDCT, id_hoa_don);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Hoadonchitiet IDHDCT(int id_hoa_don, int id_san_pham_chi_tiet) {
        return XQuery.getSingleBean(Hoadonchitiet.class, IDHDCT, id_hoa_don, id_san_pham_chi_tiet);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Hoadonchitiet> LISTHDCTINPDF(int ID_hoa_don) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        return XQuery.getBeanList(Hoadonchitiet.class, SQLINPDF, ID_hoa_don);
    }

    @Override
    public Hoadonchitiet SoLuongCu(int ID_san_pham_chi_tiet, int id_hoa_don) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        return XQuery.getSingleBean(Hoadonchitiet.class, SQLFINDBYMASPCT, ID_san_pham_chi_tiet, id_hoa_don);
    }
}
