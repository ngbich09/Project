/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daoipml;

import dao.Voucher_DAO;
import entity.Voucher;
import java.util.List;
import util.XJdbc;
import util.XQuery;

/**
 *
 * @author manhh
 */
public class Voucher_DAOIpml implements Voucher_DAO {

    private String SQLFINDLOAIGIAMGIA = "SELECT DISTINCT loai_giam_gia FROM Voucher where Trang_thai=1";
    private String SQLFINDALL = "select ten_chuong_trinh_giam_gia,ID_voucher,ma_code_voucher,loai_giam_gia,gia_tri_giam,muc_giam_toi_da,dieu_kien,so_luong,ngay_bat_dau,ngay_ket_thuc,Trang_thai from Voucher";
    private String SQLADD = "insert into Voucher(ten_chuong_trinh_giam_gia,ma_code_voucher,loai_giam_gia,gia_tri_giam,muc_giam_toi_da,dieu_kien,so_luong,ngay_bat_dau,ngay_ket_thuc) values(?,?,?,?,?,?,?,?,?)";
    private String SQLFINDBYID = "select ID_voucher from Voucher where ma_code_voucher= ?";
    private String SQLUPDATE = "update Voucher set ten_chuong_trinh_giam_gia=?,ma_code_voucher =?,loai_giam_gia=?,gia_tri_giam=?,muc_giam_toi_da=?,dieu_kien=?,so_luong=?,ngay_bat_dau=?,ngay_ket_thuc=?,Trang_thai=? where ID_voucher=?";
    private String SQLMAVOUCHER = "SELECT DISTINCT * FROM Voucher WHERE Trang_thai=1";
    private String SQLBANHANG = "SELECT * FROM Voucher WHERE ma_code_voucher=?";
    private String SQLUPDATETRANGTHAI = "UPDATE Voucher SET Trang_thai = 0 WHERE ngay_ket_thuc < CAST(GETDATE() AS DATE);";
    private String SQLDELET = "UPDATE Voucher SET Trang_thai = 0 WHERE ma_code_voucher=?";
    private String SQLFIND = "SELECT * FROM Voucher WHERE ten_chuong_trinh_giam_gia LIKE ? OR ma_code_voucher LIKE ?";
    @Override
    public Voucher create(Voucher entity) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Object[] Date = new Object[]{
            entity.getTen_chuong_trinh_giam_gia(), entity.getMa_code_voucher(), entity.getLoai_giam_gia(), entity.getGia_tri_giam(), entity.getMuc_giam_toi_da(), entity.getDieu_kien(), entity.getSo_luong(), entity.getNgay_bat_dau(), entity.getNgay_ket_thuc()
        };
        XJdbc.executeUpdate(SQLADD, Date);
        return entity;
    }

    @Override
    public void update(Voucher entity) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Object[] date = new Object[]{
           entity.getTen_chuong_trinh_giam_gia(), entity.getMa_code_voucher(), entity.getLoai_giam_gia(), entity.getGia_tri_giam(), entity.getMuc_giam_toi_da(), entity.getDieu_kien(), entity.getSo_luong(), entity.getNgay_bat_dau(), entity.getNgay_ket_thuc(), entity.isTrang_thai(), entity.getID_voucher()
        };
        XJdbc.executeUpdate(SQLUPDATE, date);

    }
    public void Xoa(Voucher entity) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Object[] date = new Object[]{
           entity.getMa_code_voucher()
        };
        XJdbc.executeUpdate(SQLDELET, date);

    }
    @Override
    public void deleteById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Voucher> findAll() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        return XQuery.getBeanList(Voucher.class,SQLFINDALL);
    }

    @Override
    public Voucher findById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Voucher> ListLoaiGiam() {
        return XQuery.getBeanList(Voucher.class,SQLFINDLOAIGIAMGIA);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Voucher
            IDvoucher(String mavoucher) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        return XQuery.getSingleBean(Voucher.class,SQLFINDBYID, mavoucher);
    }

    @Override
    public List<Voucher> ListVoucher() {
        return XQuery.getBeanList(Voucher.class,SQLMAVOUCHER);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Voucher VoucherBANHANG(String ma_code_voucher) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    return XQuery.getSingleBean(Voucher.class, SQLBANHANG,ma_code_voucher);
    }

    
    public void UPDATETRANGTHAI() {
        XJdbc.executeUpdate(SQLUPDATETRANGTHAI);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Voucher> Tim(String ten_chuong_trinh) {
        return XQuery.getBeanList(Voucher.class, SQLFIND, "%" + ten_chuong_trinh + "%", "%" + ten_chuong_trinh + "%");
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
