/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daoipml;

import dao.Sanpham_DAO;
import entity.Sanpham;
import java.util.List;
import util.XJdbc;
import util.XQuery;

/**
 *
 * @author manhh
 */
public class Sanpham_DAOIpml implements Sanpham_DAO {
 private String sql_full = "SELECT \n"
            + "    sp.ID_san_pham, sp.ma_san_pham, sp.ten_san_pham, sp.trang_thai,\n"
            + "    sp.ID_thuong_hieu, sp.ID_chat_lieu, sp.ID_co_ao, sp.Mo_ta_san_pham, \n"
            + "    th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao,\n"
            + "    ISNULL(SUM(spct.so_luong_ton), 0) AS So_luong\n" // 
            + "FROM San_pham sp\n"
            + "LEFT JOIN Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu\n"
            + "LEFT JOIN Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu\n"
            + "LEFT JOIN Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao\n"
            + "LEFT JOIN San_pham_chi_tiet spct ON sp.ID_san_pham = spct.ID_san_pham\n"
            + "GROUP BY sp.ID_san_pham, sp.ma_san_pham, sp.ten_san_pham, sp.trang_thai, \n"
            + "         sp.ID_thuong_hieu, sp.ID_chat_lieu, sp.ID_co_ao, sp.Mo_ta_san_pham, \n"
            + "         th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao\n"
            + "ORDER BY sp.ID_san_pham;";
    private String SQLADD = "INSERT INTO San_pham (ma_san_pham, ten_san_pham, Mo_ta_san_pham, ID_co_ao, ID_thuong_hieu, ID_chat_lieu) VALUES ( ?, ?, ?, ?, ?,?)";
    private String SQLIDSP = "SELECT * FROM San_pham where ma_san_pham = ? ";
    private String SQLUPDATE = "UPDATE San_pham set ma_san_pham = ?, ten_san_pham= ?, Mo_ta_san_pham= ?, ID_co_ao= ?, ID_thuong_hieu= ?, ID_chat_lieu= ?,Trang_thai=? where ID_san_pham=?";
   // tìm kiếm nhiều trường
    private String sql_timkiem = "SELECT \n"
            + "    sp.ID_san_pham, sp.ma_san_pham, sp.ten_san_pham, sp.trang_thai,\n"
            + "    sp.ID_thuong_hieu, sp.ID_chat_lieu, sp.ID_co_ao, sp.Mo_ta_san_pham, \n"
            + "    th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao,\n"
            + "    ISNULL(SUM(spct.so_luong_ton), 0) AS So_luong\n"
            + "FROM San_pham sp\n"
            + "LEFT JOIN Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu\n"
            + "LEFT JOIN Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu\n"
            + "LEFT JOIN Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao\n"
            + "LEFT JOIN San_pham_chi_tiet spct ON sp.ID_san_pham = spct.ID_san_pham\n"
            + "WHERE sp.ten_san_pham LIKE ? OR sp.ma_san_pham LIKE ? \n"
            + "GROUP BY sp.ID_san_pham, sp.ma_san_pham, sp.ten_san_pham, sp.trang_thai, sp.ID_thuong_hieu, sp.ID_chat_lieu, sp.ID_co_ao, sp.Mo_ta_san_pham, th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao \n"
            + "ORDER BY sp.ID_san_pham;";

// cbo thuộc tính
    private String sql_TT = "SELECT \n"
            + "    sp.ID_san_pham, sp.ma_san_pham, sp.ten_san_pham, sp.trang_thai,\n"
            + "    sp.ID_thuong_hieu, sp.ID_chat_lieu, sp.ID_co_ao, sp.Mo_ta_san_pham, \n"
            + "    th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao,\n"
            + "    ISNULL(SUM(spct.so_luong_ton), 0) AS So_luong\n" // <-- SỬA: Tong_so_luong_ton -> So_luong
            + "FROM San_pham sp\n"
            + "LEFT JOIN Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu\n"
            + "LEFT JOIN Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu\n"
            + "LEFT JOIN Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao\n"
            + "LEFT JOIN San_pham_chi_tiet spct ON sp.ID_san_pham = spct.ID_san_pham\n"
            + "WHERE sp.trang_thai = ? \n"
            + "GROUP BY sp.ID_san_pham, sp.ma_san_pham, sp.ten_san_pham, sp.trang_thai, sp.ID_thuong_hieu, sp.ID_chat_lieu, sp.ID_co_ao, sp.Mo_ta_san_pham, th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao \n"
            + "ORDER BY sp.ID_san_pham";
// cbo thuộc tính
    private String sql_TH = "SELECT \n"
            + "    sp.ID_san_pham, sp.ma_san_pham, sp.ten_san_pham, sp.trang_thai,\n"
            + "    sp.ID_thuong_hieu, sp.ID_chat_lieu, sp.ID_co_ao, sp.Mo_ta_san_pham, \n"
            + "    th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao,\n"
            + "    ISNULL(SUM(spct.so_luong_ton), 0) AS So_luong\n" // <-- SỬA: Tong_so_luong_ton -> So_luong
            + "FROM San_pham sp\n"
            + "LEFT JOIN Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu\n"
            + "LEFT JOIN Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu\n"
            + "LEFT JOIN Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao\n"
            + "LEFT JOIN San_pham_chi_tiet spct ON sp.ID_san_pham = spct.ID_san_pham\n"
            + "WHERE th.ten_thuong_hieu LIKE ? \n"
            + "GROUP BY sp.ID_san_pham, sp.ma_san_pham, sp.ten_san_pham, sp.trang_thai, sp.ID_thuong_hieu, sp.ID_chat_lieu, sp.ID_co_ao, sp.Mo_ta_san_pham, th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao \n"
            + "ORDER BY sp.ID_san_pham";

    // update trạng thái ( xóa )
    private String sql_UDTT = "UPDATE San_pham set Trang_thai = ? WHERE ID_san_pham = ?";

    // lấy số lượng từ bảng SPCT thông qua dấu ?
    private String sql_SLT = "SELECT\n"
            + "    sp.ID_san_pham,\n"
            + "    sp.ma_san_pham,\n"
            + "    sp.ten_san_pham,\n"
            + "    ISNULL(SUM(spct.so_luong_ton), 0) AS So_luong\n"
            + "FROM San_pham sp\n"
            + "LEFT JOIN San_pham_chi_tiet spct \n"
            + "    ON sp.ID_san_pham = spct.ID_san_pham\n"
            + "GROUP BY sp.ID_san_pham, sp.ma_san_pham, sp.ten_san_pham\n"
            + "ORDER BY sp.ID_san_pham";

    // update trạng thái ( xóa )
    private String SQLUDSP = "SELECT \n"
            + "    + \"    sp.ID_san_pham, sp.ma_san_pham, sp.ten_san_pham, sp.trang_thai,\\n\"\n"
            + "    + \"    sp.ID_thuong_hieu, sp.ID_chat_lieu, sp.ID_co_ao, sp.Mo_ta_san_pham, \\n\"\n"
            + "    + \"    th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao,\\n\"\n"
            + "    + \"    ISNULL(SUM(spct.so_luong_ton), 0) AS So_luong\\n\" \n"
            + "    + \"FROM San_pham sp\\n\"\n"
            + "    + \"LEFT JOIN Thuong_hieu th ON sp.ID_thuong_hieu = th.ID_thuong_hieu\\n\"\n"
            + "    + \"LEFT JOIN Chat_lieu cl ON sp.ID_chat_lieu = cl.ID_chat_lieu\\n\"\n"
            + "    + \"LEFT JOIN Co_ao ca ON sp.ID_co_ao = ca.ID_co_ao\\n\"\n"
            + "    + \"LEFT JOIN San_pham_chi_tiet spct ON sp.ID_san_pham = spct.ID_san_pham\\n\"\n"
            + "    + \"WHERE sp.ma_san_pham = ? \\n\" // <-- Điều kiện lọc DUY NHẤT sản phẩm vừa sửa\n"
            + "    + \"GROUP BY sp.ID_san_pham, sp.ma_san_pham, sp.ten_san_pham, sp.trang_thai, \\n\"\n"
            + "    + \"         sp.ID_thuong_hieu, sp.ID_chat_lieu, sp.ID_co_ao, sp.Mo_ta_san_pham, \\n\"\n"
            + "    + \"         th.ten_thuong_hieu, cl.ten_chat_lieu, ca.ten_co_ao\\n\"\n"
            + "    + \"ORDER BY sp.ID_san_pham;\";";

   @Override
    public Sanpham create(Sanpham entity) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Object[] date = new Object[]{
            entity.getMa_san_pham(), entity.getTen_san_pham(), entity.getMo_ta_san_pham(), entity.getID_co_ao(), entity.getID_thuong_hieu(), entity.getID_chat_lieu()
        };
        XJdbc.executeUpdate(SQLADD, date);
        return entity;
    }

    @Override
    public void update(Sanpham entity) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        Object[] date = new Object[]{
            entity.getMa_san_pham(), entity.getTen_san_pham(), entity.getMo_ta_san_pham(), entity.getID_co_ao(), entity.getID_thuong_hieu(), entity.getID_chat_lieu(), entity.isTrang_thai(), entity.getID_san_pham()
        };
        XJdbc.executeUpdate(SQLUPDATE, date);
    }

    @Override
    public void deleteById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Sanpham> findAll() {
        return XQuery.getBeanList(Sanpham.class, sql_full);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Sanpham findById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Sanpham IDSP(String ma_san_pham) {
        return XQuery.getSingleBean(Sanpham.class, SQLIDSP, ma_san_pham);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Sanpham> TimkiemSP(String TKSP) {
        return XQuery.getBeanList(Sanpham.class, sql_timkiem, "%" + TKSP + "%", "%" + TKSP + "%");
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Sanpham> CBOSP(String thuonghieu) {
        return XQuery.getBeanList(Sanpham.class, sql_TH, thuonghieu);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Sanpham> CBOHD(int HD) {
        return XQuery.getBeanList(Sanpham.class, sql_TT, HD);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Sanpham> UDSP(String ma_san_pham) {
        return XQuery.getBeanList(Sanpham.class, SQLUDSP, ma_san_pham);

        //  throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Sanpham capNhatTrangThai(int ID_san_pham, boolean TrangThaiMoi) {
        // đoạn code mới
        int trangThaiInt = TrangThaiMoi ? 1 : 0;
        XJdbc.executeUpdate(sql_UDTT, trangThaiInt, ID_san_pham);
        return null;
        // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }


}
