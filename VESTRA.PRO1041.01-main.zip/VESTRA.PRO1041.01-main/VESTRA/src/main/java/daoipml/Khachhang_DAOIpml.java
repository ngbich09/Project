/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daoipml;

import dao.Khachhang_DAO;
import entity.Khachhang;
import java.util.List;
import util.XJdbc;
import util.XQuery;

/**
 *
 * @author manhh
 */
public class Khachhang_DAOIpml implements Khachhang_DAO {
   String sqldl = "DELETE FROM Khach_hang WHERE ma_khach_hang = ?";
    String SQLbySDT = "SELECT ID_khach_hang,ma_khach_hang, ten_khach_hang, SDT, email, dia_chi, ngay_sinh, gioi_tinh from  Khach_hang where SDT = ?";
    String sqlAll = "SELECT \n"
            + "kh.ID_khach_hang,    \n"
            + "kh.ma_khach_hang,\n"
            + "kh.ten_khach_hang,\n"
            + "kh.SDT,\n"
            + "kh.email,\n"
            + "kh.dia_chi,\n"
            + "kh.ngay_sinh,\n"
            + "kh.gioi_tinh,\n"
            + "kh.Trang_thai,\n"
            + "kh.Ngay_tao,\n"
            + "kh.Ma_nguoi_tao,\n"
            + "kh.Ngay_cap_nhat,\n"
            + "kh.Ma_nguoi_cap_nhat\n"
            + "FROM Khach_hang kh";
    private String SQLKh = " select*from Khach_hang where ma_khach_hang =?";
    String sqladd = "INSERT INTO Khach_hang (ma_khach_hang, ten_khach_hang, SDT, email, dia_chi, ngay_sinh, gioi_tinh, Ma_nguoi_tao) " + "VALUES ( ?, ?, ?, ?, ?, ?, ?, ?)";
    String sqlup = " UPDATE Khach_hang set ma_khach_hang=? ,ten_khach_hang=?, SDT=?, email=?, dia_chi=?, ngay_sinh=?, gioi_tinh=?, Trang_thai=?, Ma_nguoi_cap_nhat = ? where ID_khach_hang=?";
    String sqlSearch = "SELECT * FROM Khach_hang WHERE ma_khach_hang LIKE ? OR ten_khach_hang LIKE ?";
    private String sqlTrangThai = "SELECT \n"
            + " kh.ID_khach_hang, \n"
            + " kh.ma_khach_hang, \n"
            + " kh.ten_khach_hang, \n"
            + " kh.SDT, \n"
            + " kh.email, \n"
            + " kh.dia_chi, \n"
            + " kh.ngay_sinh, \n"
            + " kh.gioi_tinh, \n"
            + " kh.Trang_thai \n"
            + "FROM Khach_hang kh \n"
            + "WHERE kh.Trang_thai = ?;";

    @Override
    public Khachhang create(Khachhang entity) {
        Object[] data = new Object[]{
            entity.getMa_khach_hang(),
            entity.getTen_khach_hang(),
            entity.getSDT(),
            entity.getEmail(),
            entity.getDia_chi(),
            entity.getNgay_sinh(),
            entity.getGioi_tinh(),
            entity.getMa_nguoi_tao()
        };
        XJdbc.executeUpdate(sqladd, data);
        return entity;
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void update(Khachhang entity) {
        Object[] data = new Object[]{
            entity.getMa_khach_hang(),
            entity.getTen_khach_hang(),
            entity.getSDT(),
            entity.getEmail(),
            entity.getDia_chi(),
            entity.getNgay_sinh(),
            entity.getGioi_tinh(),
            entity.isTrang_thai(),
            entity.getMa_nguoi_cap_nhat(),
            entity.getID_khach_hang()
        };
        XJdbc.executeUpdate(sqlup, data);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deleteById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Khachhang> findAll() {
        return XQuery.getBeanList(Khachhang.class, sqlAll);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Khachhang findById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Khachhang KH(String SDT) {
        return XQuery.getSingleBean(Khachhang.class, SQLbySDT, SDT);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Khachhang IDNHANVIEN(String ma_khach_hang) {
        return XQuery.getSingleBean(Khachhang.class, SQLKh, ma_khach_hang);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Khachhang> search(String keyword) {
        String key = "%" + keyword + "%";
        return XQuery.getBeanList(Khachhang.class, sqlSearch, key, key);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Khachhang> trangthai(int Trang_thai) {
        return XQuery.getBeanList(Khachhang.class, sqlTrangThai, Trang_thai);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}
