/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daoipml;

import controller.Login_CRUD;
import dao.Login_DAO;
import entity.Login;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.List;
import util.XJdbc;
import util.XQuery;

/**
 *
 * @author manhh
 */
public class Login_DAOIpml implements Login_DAO{
 String SQLfindbyma = "SELECT ma_nhan_vien from Nhan_vien where ten_dang_nhap = ? AND mat_khau = ?";
    @Override
    public Login_CRUD create(Login_CRUD entity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void update(Login_CRUD entity) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deleteById(String id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Login_CRUD> findAll() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Login_CRUD findById(String id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Login MaNhanVien(String taikhoan, String makhau) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
//    return XQuery.getSingleBean(Login.class, SQLfindbyma, taikhoan,makhau);
    }
    
    public String kiemTraDN(String taiKhoan, String matKhau) {
    try {
        String maNhanVien = XJdbc.getValue(SQLfindbyma, taiKhoan, matKhau);
        return maNhanVien;
    } catch (RuntimeException e) {
        return null; 
    }
}
   
}
