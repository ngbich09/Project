/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daoipml;

import dao.Chatlieu_DAO;
import entity.Chatlieu;
import java.util.List;
import util.XJdbc;
import util.XQuery;

/**
 *
 * @author manhh
 */
public class Chatlieu_DAOIpml implements Chatlieu_DAO{
private String sql_all ="SELECT ID_chat_lieu,ma_chat_lieu,ten_chat_lieu,Trang_thai  from Chat_lieu";
private String SQLID = "SELECT * from Chat_lieu where ten_chat_lieu = ?";
private String SQLCHATLIEU = "SELECT DISTINCT ten_chat_lieu FROM Chat_lieu WHERE Trang_thai=1;";
private String  sql_add=" INSERT INTO Chat_lieu (ma_chat_lieu,ten_chat_lieu ) Values (?,?) ";
private String sql_update = "UPDATE Chat_lieu set ma_chat_lieu = ?, ten_chat_lieu = ? , Trang_thai =? where ID_chat_lieu = ?";
private String SQLIDCL = "SELECT * from Chat_lieu where ma_chat_lieu = ?";
// cập nhật trạng thái ( xóa)
private String SQL_UDCL ="UPDATE Chat_lieu set Trang_thai = ? WHERE ma_chat_lieu = ?";
    @Override
    public Chatlieu create(Chatlieu entity) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
     Object[] data = new Object[]{
            entity.getMa_chat_lieu(),entity.getTen_chat_lieu()
        };
        XJdbc.executeUpdate(sql_add, data);
        return  entity;
    }

    @Override
    public void update(Chatlieu entity) {
        Object[] data = new Object[]{
            entity.getMa_chat_lieu(),entity.getTen_chat_lieu(),entity.isTrang_thai(),entity.getID_chat_lieu()
        };
        XJdbc.executeUpdate(sql_update, data);
    }

    @Override
    public void deleteById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Chatlieu> findAll() {
        return XQuery.getBeanList(Chatlieu.class, sql_all);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Chatlieu findById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Chatlieu IDCHATLIEU(String ten_chat_lieu) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    return XQuery.getSingleBean(Chatlieu.class, SQLID, ten_chat_lieu);
    }

    @Override
    public List<Chatlieu> TENCHATLIEU() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    return XQuery.getBeanList(Chatlieu.class,SQLCHATLIEU);
    }

    @Override
    public Chatlieu ID(String ma_chat_lieu) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
      return XQuery.getSingleBean(Chatlieu.class, SQLIDCL, ma_chat_lieu);
    }

    @Override
    public Chatlieu capNhatTrangThai(String ma_chat_lieu, boolean TrangThaiMS) {
         int trangThaiInt = TrangThaiMS ? 1 : 0; 
        XJdbc.executeUpdate(SQL_UDCL, trangThaiInt, ma_chat_lieu);
        // hàm này là hàm trả về gtri nên để trả về null tóm lại nó báo lỗi click nhảy về null return null
         return null;
    }
       // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }