/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package daoipml;

import dao.Thuonghieu_DAO;
import entity.Thuonghieu;
import java.util.List;
import util.XJdbc;
import util.XQuery;

/**
 *
 * @author manhh
 */
public class Thuonghieu_DAOIpml implements Thuonghieu_DAO {

    private String sql_all = "SELECT ID_thuong_hieu,ma_thuong_hieu,ten_thuong_hieu,Trang_thai  from Thuong_hieu";
    private String SQLID = "SELECT * from Thuong_hieu where ten_thuong_hieu=?";
    private String SQLTHUONGHIEU = "SELECT DISTINCT ten_thuong_hieu FROM Thuong_hieu WHERE Trang_thai=1;";
    private String sql_add = "INSERT INTO Thuong_hieu (ma_thuong_hieu,ten_thuong_hieu ) Values (?,?)";
    private String sql_update = " UPDATE Thuong_hieu SET ma_thuong_hieu =?, ten_thuong_hieu =? , Trang_thai =? where ID_thuong_hieu = ? ";
    private String SQLIDTC = "SELECT * from Thuong_hieu where ma_thuong_hieu=?";
    // chuyển trạng thái sang kh hoạt động ( btn xóa )
    private String SQL_UDTH = "UPDATE Thuong_hieu set Trang_thai = ? WHERE ma_thuong_hieu = ?";

    @Override
    public Thuonghieu create(Thuonghieu entity) {
        Object[] data = new Object[]{
            entity.getMa_thuong_hieu(), entity.getTen_thuong_hieu()
        };
        XJdbc.executeUpdate(sql_add, data);
        return entity;
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void update(Thuonghieu entity) {
        Object[] data = new Object[]{
            entity.getMa_thuong_hieu(), entity.getTen_thuong_hieu(), entity.isTrang_thai(), entity.getID_thuong_hieu()
        };
        XJdbc.executeUpdate(sql_update, data);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public void deleteById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public List<Thuonghieu> findAll() {
        return XQuery.getBeanList(Thuonghieu.class, sql_all);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Thuonghieu findById(Integer id) {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Thuonghieu IDTH(String ten_thuong_hieu) {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        return XQuery.getSingleBean(Thuonghieu.class, SQLID, ten_thuong_hieu);
    }

    @Override
    public List<Thuonghieu> TENTHUONGHIEU() {
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        return XQuery.getBeanList(Thuonghieu.class, SQLTHUONGHIEU);
    }

    @Override
    public Thuonghieu ID(String ma_thuong_hieu) {
        return XQuery.getSingleBean(Thuonghieu.class, SQLIDTC, ma_thuong_hieu);
//        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    @Override
    public Thuonghieu capNhatTrangThai(String ma_thuong_hieu, boolean TrangThaiMS) {
        int trangThaiInt = TrangThaiMS ? 1 : 0;
        XJdbc.executeUpdate(SQL_UDTH, trangThaiInt, ma_thuong_hieu);
        // hàm này là hàm trả về gtri nên để trả về null tóm lại nó báo lỗi click nhảy về null return null

        // throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
        return null;
    }
}
